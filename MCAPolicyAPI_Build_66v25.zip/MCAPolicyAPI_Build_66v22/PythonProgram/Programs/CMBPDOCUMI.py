# ************************************************************
# *    MCA RATING - CALCULATE DOC UNINSURED MOTORISTS        *
# *    PROGRAM-ID. CMBPDOCUMI.py                             *
# ************************************************************


from settings import config, cursor, connection, get_round, get_round_3
from decimal import Decimal

def run(DWXP110PY, DMBPRATPY, DMBP130P, DMBPSTATPY, STAT_END):

    for i in range(len(DMBP130P)):
        if DMBP130P[i]['UMBLMD'].strip() == "": 
            continue

        if DMBP130P[i]['CLASX'].strip() != "902000":
            continue

        query = f"SELECT UMIPR1 FROM {config['library']}.DMBF22101 WHERE CO = '{DWXP110PY['CO']}' AND PROD = '{DWXP110PY['PROD']}' AND PRMSTE = '{DMBPRATPY['MCA_PRMSTE']}' AND PROGRM = '{DMBPRATPY['MCA_PROGRM']}' AND TERR = 'ALL' AND INTCOV = 'UMB' AND UMNLIM = '{DMBP130P[i]['UMBLMD']}' AND ((EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE = 0) OR (EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE >= {DWXP110PY['RATE_DATE']}))"

        cursor.execute(query)
        data = cursor.fetchone()
        if not data:
            DMBPRATPY['RATING_ERROR_DESC'] = "CMBPDOCUMI - FAILED TO FETCH HOLD_PERMIUM."
            DMBPRATPY['RATING_STATUS'] = "E"
            return
        else:
            DMBF22101 = dict(zip([col[0] for col in cursor.description], data))
            HOLD_PREMIUM = DMBF22101['UMIPR1']

        BASE_PREMIUM = get_round(HOLD_PREMIUM * DMBP130P[i]["NINDIV"])

        # COMPUTE-PREMIUM.
        if DMBPRATPY['ACCOUNT'] == "Y":
            BASE_PREMIUM = get_round_3(BASE_PREMIUM * Decimal(0.95))

        BASE_PREMIUM_CAL = get_round(BASE_PREMIUM)
        for s in range(int(DMBP130P[i]['MCA_STAT_CTR']), STAT_END):
            if DMBPSTATPY[s]['INTCOV'] == "UMB" and DMBPSTATPY[s]['LOCNUM'] == DMBP130P[i]['LOCNUM']:
                DMBPSTATPY[s]['PREMO'] = BASE_PREMIUM_CAL
                DMBPSTATPY[s]['PROCLS'] = ''
                DMBPSTATPY[s]['CURR_STATUS'] = 'Y'
                break



            