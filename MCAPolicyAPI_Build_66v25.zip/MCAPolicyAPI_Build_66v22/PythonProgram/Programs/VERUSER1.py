import sys
from settings import cursor, config

def get_user_status(MODE1, USER, PROGRM, SEQNUM):
    try:
        query = f"SELECT * FROM {config['library']}.DQUA001 WHERE PROGRM = '{PROGRM}' AND ENDDTE = 0 AND SEQNUM = '{SEQNUM}' and USERID = '{USER}' ORDER BY SEQNUM ASC"
        cursor.execute(query)
        data = cursor.fetchall()

        if not data:
            MODE1 = "I"
        else:
            MODE1 = "V"

        user_status = f"{MODE1}{USER}{PROGRM}{SEQNUM}"
        print(user_status)
    except Exception as e:
        print(f"Database error: {e}")
        return None


def CLST010(MODE1, USER, PROGRM, SEQNUM):
    try:
        query = f"SELECT USERID, ADDLID1, ADDLID2, ADDLID3, ADDLID4 FROM {config['library']}.DQUA002 WHERE PROGRM = '{PROGRM}' AND ENDDTE = 0 AND SEQNUM = '{SEQNUM}' and USERID = '{USER}' ORDER BY SEQNUM ASC"
        cursor.execute(query)
        data = cursor.fetchall()
        if not data:
            MODE1 = "I"
            user_status = f"{MODE1}{USER}{PROGRM}{'   '}{SEQNUM}"
        else:
            CLST = dict(zip([col[0] for col in cursor.description], data[0]))
            MODE1 = "V"
            ADDLID1 = CLST['ADDLID1']
            ADDLID2 = CLST['ADDLID2']
            ADDLID3 = CLST['ADDLID3']
            ADDLID4 = CLST['ADDLID4']

            user_status = f"{MODE1}{USER}{PROGRM}{'   '}{SEQNUM}{ADDLID1}{ADDLID2}{ADDLID3}{ADDLID4}"

        print(user_status)

    except Exception as e:
        print(f"Database error: {e}")
        return None


if __name__ == '__main__':

    arg = sys.argv[1]

    MODE1 = arg[0]
    USER = arg[1:5]
    PROGRM = arg[5:-3]
    SEQNUM = arg[-3:]


    if PROGRM.strip() == 'CLST010':
        PROGRM = 'CLST010'
        CLST010(MODE1, USER, PROGRM, SEQNUM)
    else:
        get_user_status(MODE1, USER, PROGRM, SEQNUM)
