# ****************************************************************************
# * MCA RATING - Write Stat                                                  *
# * PROGRAM-ID. CMBPWST01                                                    *
# *                                                                          *
# * Read a Dummy stat record to initialize the stat fields                   *
# * Create the current stat record (CURR_STATUS = 'Y')                       *
# *                                                                          *
# * ORIG_STATUS = 'Y' (Set on Endorsements Only)                             *
# * Always write 2/3 record for change in cov, or 2 records for deleted cov  *
# *                                                                          *
# * ORIG_STATUS = 'N'                                                        *
# * Always write a 3 record when CURR_STATUS = 'Y'                           *
# ****************************************************************************

from settings import config, cursor, connection, get_round, get_round_3
from decimal import Decimal
from datetime import datetime

def run(DWXP110PY, DMBPRATPY, DMBP130P, DMBPSTATPY, STAT_END):

    if DWXP110PY['FINAUD'] == "Y" or DWXP110PY['FACTOR'] == 0:
        HOLD_FACTOR = 1
    else:
        HOLD_FACTOR = DWXP110PY['FACTOR']

    OLDDTE = datetime.strptime(str(DWXP110PY['EDSDTE']), "%Y%m%d")
    NEWDTE = datetime.strptime(str(DWXP110PY['EXPDTE']), "%Y%m%d")
    DAYS_DIFF = (NEWDTE - OLDDTE).days
    if DAYS_DIFF == 1:
        HOLD_FACTOR = 1

    # Retrieve Commissions
    if DWXP110PY['CMOVFG'] == "Y":
        HOLD_COMPER = DWXP110PY['CMOVPC']
    else:
        if DWXP110PY['PRVPOL'].strip() == "":
            query = f"SELECT AGYCOM, RNWCOM, ASLOB FROM {config['library1']}.DWXF107 WHERE CDKEY1 = '{DWXP110PY['CO']}' AND CDKEY2 = '{DWXP110PY['AGENT']}' AND PROD = 'MCA' AND ((FRMDTE <= {DWXP110PY['RATE_DATE']} AND TODTE = 0) OR (EFFDTE <= {DWXP110PY['RATE_DATE']} AND TODTE >= {DWXP110PY['RATE_DATE']}))"
        else:
            query = f"SELECT AGYCOM, RNWCOM, ASLOB FROM {config['library1']}.DWXF107 WHERE CDKEY1 = '{DWXP110PY['CO']}' AND CDKEY2 = '{DWXP110PY['AGENT']}' AND PROD = 'MCA' AND ((RNWDTE <= {DWXP110PY['RATE_DATE']} AND TODTE = 0) OR (RNWDTE <= {DWXP110PY['RATE_DATE']} AND TODTE >= {DWXP110PY['RATE_DATE']}))"
        cursor.execute(query)
        data = cursor.fetchall()
        if not data:
            DMBPRATPY['RATING_ERROR_DESC'] = "Rating Error On Agent Line File"
            DMBPRATPY['RATING_STATUS'] = "E"
            return
        else:
            DWXF107 = [dict(zip([col[0] for col in cursor.description], row)) for row in data]
            for i in range(len(DWXF107)):
                if DWXP110PY['PRVPOL'].strip() != "" and DWXF107[i]['RNWCOM'] > 0:
                    HOLD_COMPER = DWXF107[i]['RNWCOM']
                else:
                    HOLD_COMPER = DWXF107[i]['AGYCOM']

    # Load Dummy Stat record
    query = f"SELECT * FROM {config['library']}.DWXP150P WHERE POLICY= 'DUMMY'"
    cursor.execute(query)
    data = cursor.fetchone()
    DWXP150_DUMMY = dict(zip([col[0] for col in cursor.description], data[0]))

    # Review Vehicles - Total the Number Of Vehicles and Total by SDSTEP
    for i in range(len(DMBP130P)):
        if DWXP110PY['PRVPOL'].strip() == "":
            query = f"SELECT AGYCOM, RNWCOM, ASLOB FROM {config['library1']}.DWXF107 WHERE CDKEY1 = '{DWXP110PY['CO']}' AND CDKEY2 = '{DWXP110PY['AGENT']}' AND PROD = 'MCA' AND ((FRMDTE <= {DWXP110PY['RATE_DATE']} AND TODTE = 0) OR (EFFDTE <= {DWXP110PY['RATE_DATE']} AND TODTE >= {DWXP110PY['RATE_DATE']}))"
        else:
            query = f"SELECT AGYCOM, RNWCOM, ASLOB FROM {config['library1']}.DWXF107 WHERE CDKEY1 = '{DWXP110PY['CO']}' AND CDKEY2 = '{DWXP110PY['AGENT']}' AND PROD = 'MCA' AND ((RNWDTE <= {DWXP110PY['RATE_DATE']} AND TODTE = 0) OR (RNWDTE <= {DWXP110PY['RATE_DATE']} AND TODTE >= {DWXP110PY['RATE_DATE']}))"

        cursor.execute(query)
        data = cursor.fetchall()
        if not data:
            DMBPRATPY['RATING_ERROR_DESC'] = "Rating Error On Agent Line File"
            DMBPRATPY['RATING_STATUS'] = "E"
            return
        else:
            DWXF107 = [dict(zip([col[0] for col in cursor.description], row)) for row in data]
            for r in range(len(DWXF107)):
                if DWXP110PY['PRVPOL'].strip() != "" and DWXF107[r]['RNWCOM'] > 0:
                    HOLD_COMPER = DWXF107[r]['RNWCOM']

        for s in range(int(DMBP130P[i]['MCA_STAT_CTR']), STAT_END):
            if DMBPSTATPY[s]['LOCNUM'] != DMBP130P[i]['LOCNUM'] or DMBPSTATPY[s]['BLDNUM'] != DMBP130P[i]['BLDNUM']:
                continue
             # Setup_Current_Stat record
            if DMBPSTATPY[s]['CURR_STATUS'].strip() == "Y":
                # DWXP150P           = DWXP150_DUMMY # This approach won't reset the DWXP150P to dummy original state. AO
                DWXP150P           = DWXP150_DUMMY.copy()
                DWXP150P['TRANS']  = DWXP110PY['TRANS']
                DWXP150P['POLICY'] = DWXP110PY['POLICY']
                DWXP150P['EFFDTE'] = DWXP110PY['EFFDTE']
                DWXP150P['ORGEFF'] = DWXP110PY['ORGEFF']
                DWXP150P['EDSDTE'] = DWXP110PY['EDSDTE']
                DWXP150P['POLTYP'] = DWXP110PY['POLTYP']
                DWXP150P['REINFL'] = DWXP110PY['REINFL']
                DWXP150P['FUTF12'] = DWXP110PY['FUTF12']

                DWXP150P['LOCNUM'] = DMBP130P[i]['LOCNUM']
                DWXP150P['BLDNUM'] = DMBP130P[i]['BLDNUM']
                DWXP150P['PRMSTE'] = DMBP130P[i]['PRMSTE']
                DWXP150P['TERR']   = DMBP130P[i]['TERR']
                DWXP150P['TAXTER'] = DMBP130P[i]['TAXTER']
                DWXP150P['ANTTFT'] = DMBP130P[i]['ANTTFT']
                DWXP150P['STAADM'] = DMBP130P[i]['ANTTFT']
                DWXP150P['CLASX']  = DMBP130P[i]['CLASX']
                DWXP150P['INSZIP'] = DMBP130P[i]['LOCZIP']
                DWXP150P['MODLYR'] = DMBP130P[i]['MODLYR']
                DWXP150P['PASRST'] = DMBP130P[i]['PASRST']
                DWXP150P['THEFT']  = DMBP130P[i]['THEFT']
                DWXP150P['VEHID']  = DMBP130P[i]['VEHID']
                DWXP150P['RETDTE'] = DMBP130P[i]['RETDTE']
                DWXP150P['VEHNAM'] = DMBP130P[i]['VEHNAM']

                DWXP150P['POLPGM'] = DMBPRATPY['POLPGM']
                DWXP150P['RISKID'] = DMBPRATPY['RISKID']
                DWXP150P['SINLIM'] = DMBPRATPY['SINLIM']

                DWXP150P['COMPER'] = HOLD_COMPER
                DWXP150P['ASSRSK'] = 'N'
                DWXP150P['SLDED']  = "A"
                DWXP150P['ZNERTE'] = '000'

                if DMBPSTATPY[s]['INTCOV'] == "TOW":
                    DWXP150P['EXPOSE'] = 0
                else:
                    DWXP150P['EXPOSE'] = DWXP110PY['POLTRM']

                if DMBPSTATPY[s]['INTCOV'] not in ("CMP", "COL", "PIP"):
                    DWXP150P['LIMID'] = "2"
                    if DMBP130P[i]['OBILMD'].count('/') > 0:
                        DWXP150P['LIMID'] = "3"

                if DMBPSTATPY[s]['INTCOV'] == "COL":
                    DWXP150P['COLCOV'] = DMBPSTATPY[s]['COLCOV']
                    DWXP150P['DEDUCT'] = DMBP130P[i]['COLDED']
                    DWXP150P['SYMBOL'] = DMBP130P[i]['SYMBOL']

                if DMBPSTATPY[s]['INTCOV'] == "UMB":
                    DWXP150P['PROCLS'] = DMBPSTATPY[s]['PROCLS']

                if DMBPSTATPY[s]['INTCOV'] == "CMP":
                    DWXP150P['COMCOV'] = DMBPSTATPY[s]['COMCOV']
                    DWXP150P['DEDUCT'] = DMBP130P[i]['CMPDED']
                    DWXP150P['SYMBOL'] = DMBP130P[i]['SYMBOL']

                if DMBPSTATPY[s]['INTCOV'] not in ("CMP", "COL") or DMBP130P[i]['LOCNUM'] > "499":
                    DWXP150P['TAIDTE'] = 0
                else:
                    DWXP150P['TAIDTE'] = DMBP130P[i]['TAIDTE']

                if DMBPSTATPY[s]['INTCOV'] == "PIP":
                    DWXP150P['PIPLIM'] = DMBPSTATPY[s]['PIPLIM']

                if DMBPSTATPY[s]['INTCOV'] in ("BIL", "OBI", "CSL"):
                    DWXP150P['BILIM'] = DMBPSTATPY[s]['BILIM']

                if DMBPSTATPY[s]['INTCOV'] == "PDL":
                        DWXP150P['PDLIM'] = DMBPSTATPY[s]['PDLIM']

                if DMBPSTATPY[s]['INTCOV'] == "MED":
                    DWXP150P['DEDSIZ'] = DMBPSTATPY[s]['DEDSIZ']

                if DMBP130P[i]['LOCNUM'] > "499":
                    DWXP150P['AGE'] = ' '
                    DWXP150P['TERR'] = 999
                    DWXP150P['EXPOSE'] = 0
                else:
                    DWXP150P['AGE'] = DMBP130P[i]['AGE']

                if DMBP130P[i]['FUTPCT3'] != 0:
                    DWXP150P['SPRINK'] = "1"
                if DMBP130P[i]['FUTPCT2'] != 0:
                    DWXP150P['COVRG'] = "1"

                # Retrieve_Coverage_Definition
                query = f"SELECT ASLOB, SUBLN, CLMDSP, FLERND, CDDESC, INRWID, PREMID FROM {config['library1']}.DWXF025 WHERE CDKEY1 = '{DWXP110PY['PROD']}' AND CDKEY2 = '{DMBPRATPY['MCA_PRMSTE']}' AND CDKEY3 = '{DMBPSTATPY[s]['INTCOV']}' AND ((EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE = 0) OR (EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE >= {DWXP110PY['RATE_DATE']}))"
                cursor.execute(query)
                data = cursor.fetchall()
                if not data:
                    DMBPRATPY['RATING_ERROR_DESC'] = "Rating Error - Coverage Definition Not Found"
                    DMBPRATPY['RATING_STATUS'] = "E"
                    return
                else:
                    DWXF025 = dict(zip([col[0] for col in cursor.description], data[0]))
                    DWXP150P['ASLOB'] = DWXF025['ASLOB']
                    DWXP150P['BURLIN'] = DWXF025['ASLOB']
                    DWXP150P['SUBLN'] = DWXF025['SUBLN']
                    if DWXP150P['SUBLN'] == "   ":
                        DWXP150P['SUBLNP'] = "999"
                    DWXP150P['CLMDSP'] = DWXF025['CLMDSP']
                    DWXP150P['FLERND'] = DWXF025['FLERND']
                    DWXP150P['CDDESC'] = DWXF025['CDDESC']
                    DWXP150P['INRWID'] = DWXF025['INRWID']
                    DWXP150P['PREMID'] = DWXF025['PREMID']

                # Calculate RTEMOD/RTEDEP
                DWXP150P['RTEMOD'] = "100"
                DWXP150P['RTEDEP'] = "100"
                HOLD_EXPMD1 = DMBPRATPY['EXPMD1'] * Decimal(100)
                HOLD_EXPMD2 = DMBPRATPY['EXPMD2'] * Decimal(100)
                HOLD_IRPM1 = DMBPRATPY['IRPM1'] * Decimal(100)
                HOLD_IRPM2 = DMBPRATPY['IRPM2'] * Decimal(100)

                if DMBPSTATPY[s]['INTCOV'] == "UNB" and DMBP130P[i]['LOCNUM'] < '499':
                    DWXP150P['EARTHQ'] = DMBPSTATPY[s]['COLCOV']

                if DWXP150P['ASLOB'] in ("193", "194"):
                    # DWXP150P['RTEMOD'] = str(get_round(HOLD_EXPMD1))
                    # DWXP150P['RTEDEP'] = str(get_round(HOLD_IRPM1))
                    DWXP150P['RTEMOD'] = f"{get_round(HOLD_EXPMD1):03}"
                    DWXP150P['RTEDEP'] = f"{get_round(HOLD_IRPM1):03}"

                    if HOLD_EXPMD1 == 100 and HOLD_IRPM1 != 100:
                        DWXP150P['RATEID'] = "9"
                    elif HOLD_EXPMD1 != 100 and HOLD_IRPM1 == 100:
                        DWXP150P['RATEID'] = "1"
                    elif HOLD_EXPMD1 != 100 and HOLD_IRPM1 != 100:
                        DWXP150P['RATEID'] = "7"
                    elif HOLD_EXPMD1 == 100 and HOLD_IRPM1 == 100:
                        DWXP150P['RATEID'] = "0"

                if DMBPSTATPY[s]['INTCOV'] in ("UMB", "UNB", "MED"):
                    DWXP150P['RTEMOD'] = "100"
                    DWXP150P['RTEDEP'] = "100"

                if DWXP150P['ASLOB'] == "212":
                    # DWXP150P['RTEMOD'] = str(get_round(HOLD_EXPMD2))
                    # DWXP150P['RTEDEP'] = str(get_round(HOLD_IRPM2))
                    DWXP150P['RTEMOD'] = f"{get_round(HOLD_EXPMD2):03}"
                    DWXP150P['RTEDEP'] = f"{get_round(HOLD_IRPM2):03}"

                    if HOLD_EXPMD2 != 100 and HOLD_IRPM2 != 100:
                        DWXP150P['RATEID'] = "7"
                    elif HOLD_EXPMD2 == 100 and HOLD_IRPM2 != 100:
                        DWXP150P['RATEID'] = "9"
                    elif HOLD_EXPMD2 != 100 and HOLD_IRPM2 == 100:
                        DWXP150P['RATEID'] = "1"
                    elif HOLD_EXPMD2 == 100 and HOLD_IRPM2 == 100:
                        DWXP150P['RATEID'] = "0"

                DWXP150P['ISOPLN'] = "M"

                DWXP150P['PREMO'] = DMBPSTATPY[s]['PREMO']
                if DWXP150P['FLERND'] in ('X', 'Y'):
                    DWXP150P['PREMP'] = DWXP150P['PREMO']
                else:
                    DWXP150P['PREMP'] = get_round(DWXP150P['PREMO'] * HOLD_FACTOR)

                DMBP130P[i]['APRP'] = DMBP130P[i]['APRP'] + DWXP150P['PREMO']

                # If CURR_STATUS = 'Y' write '3' record
                DWXP150P['RCDTYP'] = 3
                DWXP150P['INTCOV'] = DMBPSTATPY[s]['INTCOV']

                query = f"INSERT INTO {config['library']}.DWXP150P (" + ','.join('{}'.format(k) for k in DWXP150P.keys()) + ') Values (' + ','.join("'{}'".format(v) for v in DWXP150P.values()) + ')'
                cursor.execute(query)

                # If ORIG_STATUS = 'Y' write '2' record
                if DMBPSTATPY[s]['ORIG_STATUS'].strip() == "Y":
                    query = f"SELECT * FROM {config['library1']}.DWXP150 WHERE TRANS = '{DWXP110PY['TRANS']}' AND POLICY = '{DWXP110PY['POLICY']}' AND EFFDTE = '{DWXP110PY['EFFDTE']}' AND LOCNUM = '{DMBP130P[i]['LOCNUM']}' AND BLDNUM = '{DMBP130P[i]['BLDNUM']}' AND INTCOV = '{DMBPSTATPY[s]['INTCOV']}' AND RCDTYP = 1"
                    cursor.execute(query)
                    data = cursor.fetchall()
                    if data:
                        DWXP150P = dict(zip([col[0] for col in cursor.description], data[0]))

                        DWXP150P['PREMO'] = DWXP150P['PREMO'] * -1
                        DWXP150P['EXPOSE'] = DWXP150P['EXPOSE'] * -1
                        if DWXP150P['FLERND'] == "Y":
                            if DWXP110PY['EFFDTE'] == DWXP110PY['EDSDTE']:
                                HOLD_PREMP = DMBPSTATPY[s]['PREMO']
                            else:
                                DWXP150P['PREMO'] = 0
                                DWXP150P['PREMP'] = 0
                                HOLD_PREMP1 = 0
                                HOLD_EXPOSE = 0

                        if DWXP150P['FLERND'] in ('X', 'Y'):
                            HOLD_PREMP1 = DMBPSTATPY[s]['PREMO']
                            HOLD_PREMP = DWXP150P['PREMO']
                            HOLD_EXPOSE = DMBPSTATPY[s]['EXPOSE']
                        elif DMBPSTATPY[s]['TFS'] in ('T', 'F', 'S'):
                            HOLD_PREMP1 = get_round(DWXP150P['PREMO'] * HOLD_FACTOR)
                            HOLD_EXPOSE = DMBPSTATPY[s]['EXPOSE']
                        else:
                            HOLD_PREMP = get_round(DWXP150P['PREMO'] * HOLD_FACTOR)
                            HOLD_EXPOSE = DMBPSTATPY[s]['EXPOSE']

                        if DMBPSTATPY[s]['TFS'] in ('T', 'F', 'S'):
                            DWXP150P['PREMP'] = HOLD_PREMP1
                        else:
                            DWXP150P['PREMP'] = HOLD_PREMP

                        DWXP150P['EXPOSE'] = HOLD_EXPOSE
                        DWXP150P['RCDTYP'] = 2
                        query = f"INSERT INTO {config['library']}.DWXP150P (" + ','.join('{}'.format(k) for k in DWXP150P.keys()) + ') Values (' + ','.join("'{}'".format(v) for v in DWXP150P.values()) + ')'
                        cursor.execute(query)
