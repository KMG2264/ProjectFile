from settings import config, cursor, connection
import json
from datetime import datetime
import httpx

def post_call(POLICY,EFFDTE,REQID,clyde_list,ACTN,SESSNID,INSTNCEID):
    '''
    Payload format:
    payload = "args={'action': 'score','sessionId':'session19445431587619444a4f760b','instanceId':'instance71c67e04957','argsData':{'NODRV':[2,2],'TIER':['4A','4A'],'SDSTEP':[99,99],'PAYPLN':['TR','TR'],'NBRCAN':[0,0],'NOVEH':[2,2],'TENURE':[0,0],'MODLYR':[2010,2013],'HOME_FLAG':['N','N'],'YRSLIC':[42,42]}}"
    '''
    try:
        url = "https://qmintr01.qmfi.com/test_db.php"
        headers = {'Content-Type': 'application/json; charset=utf-8'}
        if clyde_list:
            args_dict = {}
            argsData_dict = {}
            FLDVAL_dict = {}
            FLDNAM_LIST = []
            args_dict['action'] = ACTN
            args_dict['sessionId'] = SESSNID
            args_dict['instanceId'] = INSTNCEID
            for each_dict in clyde_list:   
                UPDATED_FLDVALUE_LIST = []
                FLDVALUE_LIST = each_dict.get('FLDVALUE').strip().split(",") 
                num_str_no_decimal = [num_str.replace('.', '', 1) for num_str in FLDVALUE_LIST] 
                for i in range(len(num_str_no_decimal)):
                    if num_str_no_decimal[i].isdigit():
                        if "." in FLDVALUE_LIST[i]:
                            UPDATED_FLDVALUE_LIST.append(float(FLDVALUE_LIST[i]))
                        else:
                            UPDATED_FLDVALUE_LIST.append(int(FLDVALUE_LIST[i]))
                    else:
                        UPDATED_FLDVALUE_LIST.append(FLDVALUE_LIST[i])
                FLDNAM_LIST.append(each_dict.get('FLDNAM').strip())
                if each_dict.get('FLDNAM').strip() in ('TIERNEW','PAYPLN', 'PROCLS'):
                    argsData_dict[each_dict.get('FLDNAM').strip()] = [str(x).rjust(2,'0') for x in UPDATED_FLDVALUE_LIST]
                else:
                    argsData_dict[each_dict.get('FLDNAM').strip()] = UPDATED_FLDVALUE_LIST
                FLDVAL_dict[each_dict.get('FLDNAM').strip()] = each_dict.get('FLDVALUE').strip()

            args_dict['argsData'] = argsData_dict
            payload = f'\'args = {args_dict}\''
            api_response = httpx.post(url=url,data=payload,headers=headers)
            dict_response = json.loads(json.loads(api_response.text).replace('\'','"'))
            now = datetime.now()
            date_string = now.strftime("%Y%m%d")
            time_string = now.strftime("%H%M%S")

            if "errorCode" in dict_response.keys():
                return clyde_list,str(dict_response.get('errorMessage')),'N','CCERR'

            if 'score' in dict_response:
                if api_response.status_code == 200:
                    SUCCESS_FLG = "Y"
                    SCORE = dict_response.get('score')
                    ERROR_MSG = ''
                else:
                    SUCCESS_FLG = "N"
                    SCORE = 'CCERR'
                    ERROR_MSG = 'SCORE NOT FOUND'
                return clyde_list,ERROR_MSG,SUCCESS_FLG,SCORE
        else:
            return [],"No data in request",'N','CCERR'
    except Exception as e:
        return clyde_list,str(e),'N','CCERR'