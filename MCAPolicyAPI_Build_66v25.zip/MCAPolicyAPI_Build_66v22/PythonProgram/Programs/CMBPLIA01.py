# ************************************************************
# *    MCA rating - Calculate Liability                      *
# *    PROGRAM-ID - CMBPLIA01.py                             *
# ************************************************************

from settings import config, cursor, connection, get_round, get_round_3, truncate, get_round_2, get_round_x
from decimal import Decimal


def run(DWXP110PY, DMBPRATPY, DMBP130P, DMBPSTATPY, STAT_END):

    experience_mod = {}

    for i in range(len(DMBP130P)):

        INTCOV_BASE = []

        def c100(DWXP110PY, DMBPRATPY, DMBP130P, DMBPSTATPY, STAT_END, HOLD_INTCOV, HOLD_COVLIM, HOLD_TERR, HOLD_SIZCLS, HOLD_VHTYPE, HOLD_FLEET, HOLD_VEHCLS, SPLIT_LIAB, CSL_LIAB, PROCESS_BIL, PDLLMD, OBILMD, PROCESS_OBI, PROCESS_PDL, PROCESS_CSL):
            query = f"SELECT BASPRM FROM {config['library']}.DMBF21701 WHERE CO = '{DWXP110PY['CO']}' AND PROD = '{DWXP110PY['PROD']}' AND PRMSTE = '{DMBPRATPY['MCA_PRMSTE']}' AND PROGRM = '{DMBPRATPY['MCA_PROGRM']}' AND INTCOV = '{HOLD_INTCOV}' AND TERR = '{HOLD_TERR}' AND FLEET = '{HOLD_FLEET}' AND VHTYPE = '{HOLD_VHTYPE}' AND SIZCLS = '{HOLD_SIZCLS}' AND ((EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE = 0) OR (EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE >= {DWXP110PY['RATE_DATE']}))"
            cursor.execute(query)
            data = cursor.fetchone()
            if not data:
                DMBPRATPY['RATING_ERROR_DESC'] = "DMBPLIA01 - BIL BASEPREM Failed"
                DMBPRATPY['RATING_STATUS'] = "E"
                return
            else:
                DMBF21701_BIL = dict(zip([col[0] for col in cursor.description],data))
                BASE_PREM = DMBF21701_BIL['BASPRM']
                INTCOV_BASE.append(BASE_PREM)

            if PROCESS_BIL:
                HOLD_COVLIM = "20/40"
                HOLD_SIZCLS = ' '
                HOLD_VHTYPE = ' '

            if PROCESS_OBI or PROCESS_CSL:
                HOLD_COVLIM = HOLD_COVLIM
                HOLD_SIZCLS = ' '
                HOLD_VHTYPE = ' '
                BASE_PREM = BASE_PREM + INTCOV_BASE[0]

            query = f"SELECT INCRT1, INCCD1, INCCD2 FROM {config['library']}.DMBF22501 WHERE CO = '{DWXP110PY['CO']}' AND PROD = '{DWXP110PY['PROD']}' AND PRMSTE = '{DMBPRATPY['MCA_PRMSTE']}' AND PROGRM = '{DMBPRATPY['MCA_PROGRM']}' AND INTCOV = '{HOLD_INTCOV}' AND TRIM(SIZCLS) = '{HOLD_SIZCLS}' AND TRIM(VHTYPE) = '{HOLD_VHTYPE}' AND COVLIM = '{HOLD_COVLIM}' AND ((EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE = 0) OR (EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE >= {DWXP110PY['RATE_DATE']}))"
            cursor.execute(query)
            data = cursor.fetchone()
            if not data:
                DMBPRATPY['RATING_ERROR_DESC'] = "DMBPLIA01 - ISO CODE Failed"
                DMBPRATPY['RATING_STATUS'] = "E"
                return
            else:
                DQNF23401 = dict(zip([col[0] for col in cursor.description], data))
                INCR_FACTOR = DQNF23401['INCRT1']
                ISO_CODE = DQNF23401['INCCD1']

                if CSL_LIAB:
                    ISO_CODE = DQNF23401['INCCD2']

            if PROCESS_BIL and CSL_LIAB or PROCESS_BIL and SPLIT_LIAB:
                if SPLIT_LIAB:
                    HOLD_COVLIM = OBILMD
                else:
                    WORK_CSL_LMT = OBILMD.strip()
                    HOLD_COVLIM = WORK_CSL_LMT + "/" + WORK_CSL_LMT

                query = f"SELECT INCRT1, INCCD1, INCCD2 FROM {config['library']}.DMBF22501 WHERE CO = '{DWXP110PY['CO']}' AND PROD = '{DWXP110PY['PROD']}' AND PRMSTE = '{DMBPRATPY['MCA_PRMSTE']}' AND PROGRM = '{DMBPRATPY['MCA_PROGRM']}' AND INTCOV = 'OBI' AND TRIM(SIZCLS) = '{HOLD_SIZCLS}' AND TRIM(VHTYPE) = '{HOLD_VHTYPE}' AND COVLIM = '{HOLD_COVLIM}' AND ((EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE = 0) OR (EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE >= {DWXP110PY['RATE_DATE']}))"
                cursor.execute(query)
                data = cursor.fetchone()
                if not data:
                    DMBPRATPY['RATING_ERROR_DESC'] = "CMBPLIA01A - ISO CODE Failed"
                    DMBPRATPY['RATING_STATUS'] = "E"
                    return
                else:
                    DMBF22501 = dict(zip([col[0] for col in cursor.description], data))
                    if PROCESS_BIL and SPLIT_LIAB:
                        ISO_CODE = DMBF22501['INCCD1']
                    else:
                        ISO_CODE = DMBF22501['INCCD2']

            if PROCESS_BIL or PROCESS_OBI or PROCESS_CSL:
                HOLD_SIZCLS = HOLD_VEHCLS[0]
                HOLD_VHTYPE = DMBP130P[i]['TYPE_OF_VEH']

            if PROCESS_BIL:
                HOLD_COVLIM = ' '

            if PROCESS_PDL and CSL_LIAB:

                HOLD_MISID = 'CSL'
                HOLD_MISVR1 = 'ALL'
                HOLD_MISVR2 = ''
                HOLD_MISVR3 = ''
                query = f"SELECT MISRT1 FROM {config['library']}.DWAF22801 WHERE CO = '{DWXP110PY['CO']}' AND PROD = '{DWXP110PY['PROD']}' AND PRMSTE = '{DMBPRATPY['MCA_PRMSTE']}' AND PROGRM = '{DMBPRATPY['MCA_PROGRM']}'  AND MISID = '{HOLD_MISID}' AND MISVR1 = '{HOLD_MISVR1}' AND ((EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE = 0) OR (EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE >= {DWXP110PY['RATE_DATE']}))"
                cursor.execute(query)
                data = cursor.fetchone()
                if not data:
                    DMBPRATPY['RATING_ERROR_DESC'] = "DMBPLIA01 - WORK LIMITS Failed"
                    DMBPRATPY['RATING_STATUS'] = "E"
                    return
                else:
                    DWAF22801 = dict(zip([col[0] for col in cursor.description], data))
                    WORK_LIMIT_H = HOLD_MISVR3
                    WORK_FAC_H = DWAF22801["MISRT1"]
                    SING_LMT_DSC = DWAF22801['MISRT1']

                    if HOLD_MISID == 'CSL' and HOLD_MISVR1 == 'ALL':
                        WORK_LIMIT_G = OBILMD
                        WORK_LIMIT_L = HOLD_MISVR2
                        WORK_LIMIT_U = HOLD_MISVR3

                    if WORK_LIMIT_G < WORK_LIMIT_L:
                        SING_LMT_DSC = DWAF22801['MISRT1']

                    if WORK_LIMIT_G >= WORK_LIMIT_L and WORK_LIMIT_G <= WORK_LIMIT_U:
                        SING_LMT_DSC = DWAF22801['MISRT1']

                    if WORK_LIMIT_H != 0 and WORK_LIMIT_G >= WORK_LIMIT_H and WORK_LIMIT_G <= WORK_LIMIT_L:
                        HIGH_LMT_FAC = DWAF22801['MISRT1']
                        HIGH_LIMIT = WORK_LIMIT_L
                        LOW_LMT_FAC = WORK_FAC_H
                        LOW_LIMIT = WORK_LIMIT_H

            if HOLD_VHTYPE == "TT":
                HOLD_BUSCLS = HOLD_VEHCLS[1]
                HOLD_RADCLS = HOLD_VEHCLS[2]
                query = f"SELECT PBIFAC, PPDFAC FROM {config['library']}.DMBF21501 WHERE CO = '{DWXP110PY['CO']}' AND PROD = '{DWXP110PY['PROD']}' AND PRMSTE = '{DMBPRATPY['MCA_PRMSTE']}' AND PROGRM = '{DMBPRATPY['MCA_PROGRM']}' AND SIZCLS = '{HOLD_SIZCLS}' AND BUSCLS = '{HOLD_BUSCLS}' AND RADCLS = '{HOLD_RADCLS}' AND ((EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE = 0) OR (EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE >= {DWXP110PY['RATE_DATE']}))"
                cursor.execute(query)
                data = cursor.fetchone()
                if not data:
                    DMBPRATPY['RATING_ERROR_DESC'] = "DMBPLIA01 - PPD PRI FACTOR Failed"
                    DMBPRATPY['RATING_STATUS'] = "E"
                    return
                else:
                    DQNF23401 = dict(zip([col[0] for col in cursor.description], data))
                    PBI_PRI_FACTOR = DQNF23401['PBIFAC']
                    if PROCESS_PDL:
                        PPD_PRI_FACTOR = DQNF23401['PPDFAC']

            HOLD_MISID = "TERR DEV"
            HOLD_MISVR1 = HOLD_TERR
            HOLD_MISVR3 = HOLD_VHTYPE
            if PROCESS_BIL:
                HOLD_MISVR2 = "BIL"
            if PROCESS_OBI or PROCESS_CSL:
                HOLD_MISVR2 = "OBI"
            if PROCESS_PDL:
                HOLD_MISVR2 = "PDL"
            query = f"SELECT MISRT1 FROM {config['library']}.DWAF22801 WHERE CO = '{DWXP110PY['CO']}' AND PROD = '{DWXP110PY['PROD']}' AND PRMSTE = '{DMBPRATPY['MCA_PRMSTE']}' AND PROGRM = '{DMBPRATPY['MCA_PROGRM']}'  AND MISID = '{HOLD_MISID}' AND MISVR1 = '{HOLD_MISVR1}' AND MISVR2 = '{HOLD_MISVR2}' AND MISVR3 = '{HOLD_MISVR3}' AND ((EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE = 0) OR (EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE >= {DWXP110PY['RATE_DATE']}))"
            cursor.execute(query)
            data = cursor.fetchone()
            if not data:
                DMBPRATPY['RATING_ERROR_DESC'] = "DMBPLIA01 - TERR DEV Factor Failed"
                DMBPRATPY['RATING_STATUS'] = "E"
                return
            else:
                DWAF22801 = dict(zip([col[0] for col in cursor.description], data))
                TERR_DEV_FAC = truncate(DWAF22801['MISRT1'], 3)

            AUTOPLUS_FACTOR = 1.010
            if HOLD_FLEET == "N":
                AUTOPLUS_FACTOR = 1.030

            if '1' < HOLD_VEHCLS[0] < '7':
                HOLD_SECCLS = HOLD_VEHCLS[3:5]

                if "21" > HOLD_SECCLS > "29":
                    HOLD_RADCLS = HOLD_VEHCLS[2]
                else:
                    HOLD_RADCLS = ""

                if HOLD_VEHCLS[3] == "7":
                    HOLD_DMPFLG = "Y"
                else:
                    HOLD_DMPFLG = "N"

                query = f"SELECT LIAFTR, PDFTR FROM {config['library']}.DMBF21601 WHERE CO = '{DWXP110PY['CO']}' AND PROD = '{DWXP110PY['PROD']}' AND PRMSTE = '{DMBPRATPY['MCA_PRMSTE']}' AND PROGRM = '{DMBPRATPY['MCA_PROGRM']}' AND SECCLS = '{HOLD_SECCLS}' AND TRIM(RADCLS) = '{HOLD_RADCLS}' AND DMPFLG = '{HOLD_DMPFLG}' AND ((EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE = 0) OR (EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE >= {DWXP110PY['RATE_DATE']}))"
                cursor.execute(query)
                data = cursor.fetchone()
                if not data:
                    DMBPRATPY['RATING_ERROR_DESC'] = "DMBPLIA01 - PBI SEC Factor Failed"
                    DMBPRATPY['RATING_STATUS'] = "E"
                    return
                else:
                    DQNF23401 = dict(zip([col[0] for col in cursor.description], data))
                    PBI_SEC_FACTOR = DQNF23401['LIAFTR']
                    PPD_SEC_FACTOR = DQNF23401['PDFTR']

            else:
                PBI_SEC_FACTOR = PPD_SEC_FACTOR = 0

            # EXPERIENCE MOD SECTION
            if not experience_mod:
                if DWXP110PY['LOCZIP'] == "BASLIMPRM":
                    COMBINED_FACTOR1 = 1
                else:
                    COMBINED_FACTOR1 = DMBPRATPY['EXPMD1']
                COMBINED_FACTOR = get_round_2(COMBINED_FACTOR1)

                # Extract whole number and remainder
                WHOLE_NUMBER = int(str(COMBINED_FACTOR).split('.')[0])
                REMAINDER_NUMBER = int(str(COMBINED_FACTOR).split('.')[1])

                if WHOLE_NUMBER >= 1:
                    RTEMOD_NUMERIC = str(WHOLE_NUMBER)[-1]
                    RTEMOD_NUMERIC += str(REMAINDER_NUMBER).zfill(2)
                else:
                    RTEMOD_NUMERIC = str(WHOLE_NUMBER)[-1]
                    RTEMOD_NUMERIC += str(REMAINDER_NUMBER).zfill(2)

                COMBINED_FACTOR1 = DMBPRATPY['IRPM1']
                COMBINED_FACTOR = get_round_2(COMBINED_FACTOR1)

                WHOLE_NUMBER = int(str(COMBINED_FACTOR).split('.')[0])
                REMAINDER_NUMBER = int(str(COMBINED_FACTOR).split('.')[1])

                if WHOLE_NUMBER >= 1:
                    RTEDEP_NUMERIC = str(WHOLE_NUMBER)[-1]
                    RTEDEP_NUMERIC += str(REMAINDER_NUMBER).zfill(2)
                else:
                    RTEDEP_NUMERIC = str(WHOLE_NUMBER)[-1]
                    RTEDEP_NUMERIC += str(REMAINDER_NUMBER).zfill(2)

                # Insert into experience_mod values dictionary
                experience_mod["RTEMOD_CODE"] = RTEMOD_NUMERIC
                experience_mod["RTEDEP_CODE"] = RTEDEP_NUMERIC

            BASE_PREMIUM = get_round_3(BASE_PREM * INCR_FACTOR)

            if PROCESS_OBI or PROCESS_CSL:
                BASE_PREMIUM = BASE_PREMIUM - INTCOV_BASE[0]

            if PROCESS_PDL and CSL_LIAB:
                BASE_PREMIUM = get_round_3(BASE_PREMIUM * SING_LMT_DSC)

            if HOLD_VHTYPE == "TT":
                if PROCESS_BIL or PROCESS_OBI or PROCESS_CSL:
                    BASE_PREMIUM = get_round_3(BASE_PREMIUM * (PBI_PRI_FACTOR + PBI_SEC_FACTOR))
                if PROCESS_PDL:
                    BASE_PREMIUM = get_round_3(BASE_PREMIUM * (PPD_PRI_FACTOR + PPD_SEC_FACTOR))

            BASE_PREMIUM = get_round_3(BASE_PREMIUM * TERR_DEV_FAC)

            if DMBP130P[i]['LNLSCOV'] == "Y":
                BASE_PREMIUM = get_round_3(BASE_PREMIUM * Decimal(1.04))

            if DMBPRATPY['ACCOUNT'] == "Y":
                BASE_PREMIUM = get_round_3(BASE_PREMIUM * Decimal('0.95'))
                # BASE_PREMIUM = get_round_3(BASE_PREMIUM * Decimal(0.95))

            BASE_PREMIUM = get_round_3(BASE_PREMIUM * DMBPRATPY['RMF1'])

            if DMBP130P[i]['ENHCOV'] == "Y":
                BASE_PREMIUM = get_round_3(BASE_PREMIUM * Decimal(AUTOPLUS_FACTOR))

            BASE_PREMIUM_CAL = get_round(BASE_PREMIUM)

            if PROCESS_CSL:
                INTCOV = "CSL"

            if HOLD_INTCOV == "BIL":
                BILIM = ISO_CODE

            if HOLD_INTCOV == "OBI":
                BILIM = ISO_CODE

            if HOLD_INTCOV == "PDL":
                PDLIM = ISO_CODE
                if CSL_LIAB:
                    PDLIM = "00"

            return BASE_PREMIUM_CAL, ISO_CODE

        if int(DMBP130P[i]['LOCNUM']) > 499:
            return

        if DMBP130P[i]['VEHTYP'] == 'U' and str(DMBP130P[i]['CLASX'])[1] != '8':
            continue

        SPLIT_LIAB = CSL_LIAB = PROCESS_OBI = PROCESS_PDL = PROCESS_CSL = False
        PROCESS_BIL = True

        HOLD_VEHCLS = str(DMBP130P[i]['CLASX'])

        HOLD_TERR = DMBP130P[i]['TERR']
        PDLLMD = DMBP130P[i]['PDLLMD']
        OBILMD = str(DMBP130P[i]['OBILMD'])

        HOLD_SIZCLS = HOLD_VEHCLS[0]
        HOLD_VHTYPE = HOLD_MISVR3 = PPT_TTT_SWITCH = DMBP130P[i]['TYPE_OF_VEH']
        HOLD_FLEET = DMBPRATPY['FLEET']

        if OBILMD.count('/') >= 1:
            SPLIT_LIAB = True
        else:
            CSL_LIAB = True

        if PROCESS_BIL:
            HOLD_INTCOV = 'BIL'
            HOLD_COVLIM = ' '
            BASE_PREMIUM_CAL, ISO_CODE = c100(DWXP110PY, DMBPRATPY, DMBP130P, DMBPSTATPY, STAT_END, HOLD_INTCOV, HOLD_COVLIM, HOLD_TERR, HOLD_SIZCLS, HOLD_VHTYPE, HOLD_FLEET, HOLD_VEHCLS, SPLIT_LIAB, CSL_LIAB, PROCESS_BIL, PDLLMD, OBILMD, PROCESS_OBI, PROCESS_PDL, PROCESS_CSL)
            for s in range(int(DMBP130P[i]['MCA_STAT_CTR']), STAT_END):
                if DMBPSTATPY[s]['INTCOV'] == "BIL" and DMBPSTATPY[s]['LOCNUM'] == DMBP130P[i]['LOCNUM']:
                    DMBPSTATPY[s]['PREMO'] = BASE_PREMIUM_CAL
                    DMBPSTATPY[s]['CURR_STATUS'] = "Y"
                    DMBPSTATPY[s]['BILIM'] = ISO_CODE
                    DMBPSTATPY[s]['RTEMOD'] = experience_mod["RTEMOD_CODE"]
                    DMBPSTATPY[s]['RTEDEP'] = experience_mod["RTEDEP_CODE"]
                    break

        if SPLIT_LIAB and OBILMD != ' ':
            HOLD_COVLIM = OBILMD
            HOLD_INTCOV = 'OBI'
            PROCESS_OBI = True
            PROCESS_BIL = False
            BASE_PREMIUM_CAL, ISO_CODE = c100(DWXP110PY, DMBPRATPY, DMBP130P, DMBPSTATPY, STAT_END, HOLD_INTCOV, HOLD_COVLIM, HOLD_TERR, HOLD_SIZCLS, HOLD_VHTYPE, HOLD_FLEET, HOLD_VEHCLS, SPLIT_LIAB, CSL_LIAB, PROCESS_BIL, PDLLMD, OBILMD, PROCESS_OBI, PROCESS_PDL, PROCESS_CSL)
            for s in range(int(DMBP130P[i]['MCA_STAT_CTR']), STAT_END):
                if DMBPSTATPY[s]['INTCOV'] == "OBI" and DMBPSTATPY[s]['LOCNUM'] == DMBP130P[i]['LOCNUM']:
                    DMBPSTATPY[s]['INTCOV'] = HOLD_INTCOV
                    DMBPSTATPY[s]['PREMO'] = BASE_PREMIUM_CAL
                    DMBPSTATPY[s]['BILIM'] = ISO_CODE
                    DMBPSTATPY[s]['CURR_STATUS'] = "Y"
                    DMBPSTATPY[s]['RTEMOD'] = experience_mod["RTEMOD_CODE"]
                    DMBPSTATPY[s]['RTEDEP'] = experience_mod["RTEDEP_CODE"]
                    break

        if CSL_LIAB and OBILMD != ' ':
            WORK_CSL_LMT = OBILMD.strip()
            HOLD_COVLIM = WORK_CSL_LMT + "/" + WORK_CSL_LMT # NEED to find out
            HOLD_INTCOV = 'OBI'
            PROCESS_CSL = True
            PROCESS_BIL = False
            BASE_PREMIUM_CAL, ISO_CODE = c100(DWXP110PY, DMBPRATPY, DMBP130P, DMBPSTATPY, STAT_END, HOLD_INTCOV, HOLD_COVLIM, HOLD_TERR, HOLD_SIZCLS, HOLD_VHTYPE, HOLD_FLEET, HOLD_VEHCLS, SPLIT_LIAB, CSL_LIAB, PROCESS_BIL, PDLLMD, OBILMD, PROCESS_OBI, PROCESS_PDL, PROCESS_CSL)
            for s in range(int(DMBP130P[i]['MCA_STAT_CTR']), STAT_END):
                if DMBPSTATPY[s]['INTCOV'] == "CSL" and DMBPSTATPY[s]['LOCNUM'] == DMBP130P[i]['LOCNUM']:
                    DMBPSTATPY[s]['INTCOV'] = 'CSL'
                    DMBPSTATPY[s]['PREMO'] = BASE_PREMIUM_CAL
                    DMBPSTATPY[s]['BILIM'] = ISO_CODE
                    DMBPSTATPY[s]['CURR_STATUS'] = "Y"
                    DMBPSTATPY[s]['RTEMOD'] = experience_mod["RTEMOD_CODE"]
                    DMBPSTATPY[s]['RTEDEP'] = experience_mod["RTEDEP_CODE"]
                    break

        if PDLLMD != ' ' or OBILMD != ' ':
            if CSL_LIAB:
                HOLD_COVLIM = OBILMD
            else:
                HOLD_COVLIM = PDLLMD

            HOLD_INTCOV = 'PDL'
            PROCESS_PDL = True
            PROCESS_BIL = False
            PROCESS_OBI = False
            PROCESS_CSL = False
            BASE_PREMIUM_CAL, ISO_CODE = c100(DWXP110PY, DMBPRATPY, DMBP130P, DMBPSTATPY, STAT_END, HOLD_INTCOV, HOLD_COVLIM, HOLD_TERR, HOLD_SIZCLS, HOLD_VHTYPE, HOLD_FLEET, HOLD_VEHCLS, SPLIT_LIAB, CSL_LIAB, PROCESS_BIL, PDLLMD, OBILMD, PROCESS_OBI, PROCESS_PDL, PROCESS_CSL)
            for s in range(int(DMBP130P[i]['MCA_STAT_CTR']), STAT_END):
                if DMBPSTATPY[s]['INTCOV'] == "PDL" and DMBPSTATPY[s]['LOCNUM'] == DMBP130P[i]['LOCNUM']:
                    DMBPSTATPY[s]['INTCOV'] = HOLD_INTCOV
                    DMBPSTATPY[s]['PREMO'] = BASE_PREMIUM_CAL
                    if CSL_LIAB:
                        DMBPSTATPY[s]["PDLIM"] = "00"
                    else:
                        DMBPSTATPY[s]['PDLIM'] = ISO_CODE
                    DMBPSTATPY[s]['CURR_STATUS'] = "Y"
                    DMBPSTATPY[s]['RTEMOD'] = experience_mod["RTEMOD_CODE"]
                    DMBPSTATPY[s]['RTEDEP'] = experience_mod["RTEDEP_CODE"]
                    break
