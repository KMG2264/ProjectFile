from settings import config, cursor, connection
import json
from datetime import datetime
import httpx

def post_call(POLICY,EFFDTE,REQID,clyde_list):

    start_time = datetime.now()
    print("Start time is:",start_time)
    url = "https://qmintr01.qmfi.com/test_db.php"
    headers = {'Content-Type': 'application/json; charset=utf-8'}

    if clyde_list:
        args_dict = {}
        argsData_dict = {}
        FLDVAL_dict = {}
        FLDNAM_LIST = []
        args_dict['action'] = clyde_list[0]['ACTN'].strip()
        args_dict['sessionId'] = clyde_list[0]['SESSNID'].strip()
        args_dict['instanceId'] = clyde_list[0]['INSTNCEID'].strip()
        for each_dict in clyde_list:   
            UPDATED_FLDVALUE_LIST = []
            FLDVALUE_LIST = each_dict.get('FLDVALUE').strip().split(",") 
            num_str_no_decimal = [num_str.replace('.', '', 1) for num_str in FLDVALUE_LIST]
            for i in range(len(num_str_no_decimal)):
                if num_str_no_decimal[i].isdigit():
                    if "." in FLDVALUE_LIST[i]:
                        UPDATED_FLDVALUE_LIST.append(float(FLDVALUE_LIST[i]))
                    else:
                        UPDATED_FLDVALUE_LIST.append(int(FLDVALUE_LIST[i]))
                else:
                    UPDATED_FLDVALUE_LIST.append(FLDVALUE_LIST[i])
            FLDNAM_LIST.append(each_dict.get('FLDNAM').strip())
            argsData_dict[each_dict.get('FLDNAM').strip()] = UPDATED_FLDVALUE_LIST
            FLDVAL_dict[each_dict.get('FLDNAM').strip()] = each_dict.get('FLDVALUE').strip()

        args_dict['argsData'] = argsData_dict
        payload = f'\'args = {args_dict}\''
        api_response = httpx.post(url=url,data=payload,headers=headers)
        dict_response = json.loads(json.loads(api_response.text).replace('\'','"'))
        now = datetime.now()
        date_string = now.strftime("%Y%m%d")
        time_string = now.strftime("%H%M%S")
        end_time = datetime.now()
        print("End time is:",end_time)

        if 'score' in dict_response:
            SUCCESS_FLG = "Y" if api_response.status_code == 200 else "N"
            query = f"INSERT INTO {config['library']}.DQCLYRES (FLDNAM,FLDVAL,POLICY,EFFDTE,REQUESTID,ERRMSG,SUCFLG,TRDATE,TRTIME,INSTNCEID) Values('score','{dict_response.get('score')}','{POLICY}',{EFFDTE},'{REQID}','','{SUCCESS_FLG}','{date_string}','{time_string}','{args_dict.get('instanceId')}')"
            cursor.execute(query)
            connection.commit()
        
        total_time = (end_time-start_time).total_seconds()*10**3
        print(f"Total time taken to run POST call: {total_time:.03f}ms")