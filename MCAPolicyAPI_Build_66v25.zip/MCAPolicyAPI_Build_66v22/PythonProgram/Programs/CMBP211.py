# ***************************************************************
# *        MCA RATING - RATING DRIVER PROGRAM                   *
# ***************************************************************
# *  TRANS, POLICY AND EFFDTE ARE PASSED TO THIS PROGRAM        *
# *  RETRIEVE POLICY LINKAGE FROM DWXP110PY                     *
# *  RETRIEVE MCA RATING LINKAGE FROM DMBPRATPY                 *
# *  RETRIEVE MCA VEHICLES  FROM DMBP130P                       *
# *  RETRIEVE RATING PROGRAMS  DWXF213                          *
# *  CALL EACH RATING MODULE                                    *
# *  PROGRAM-ID. CMBP211                                        *
# ***************************************************************
# *250967|Correction "trans" reference used for updating      |10/30/25|CJS *
# *      |rating error information.                           |             *     |        |    *
# ***************************************************************************
import sys
import time
from datetime import datetime, date
from pathlib import Path
import pandas as pd
import importlib
import json
from decimal import Decimal


from settings import config, cursor, connection
# import datetime

start_time = time.perf_counter()

def querylog(query ,flag=True):


    log_file = Path("Dev/Raters/Logs/queries.log")
    log_file.parent.mkdir(parents=True, exist_ok=True)

    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    with open(log_file, "a", encoding="utf-8") as f:
        f.write(f"[{timestamp}] {query}\n")

    # print("Logged.")
    
def clean(data):
    if isinstance(data, dict):
        return {k: clean(v) for k, v in data.items()}
    elif isinstance(data, list):
        return [clean(i) for i in data]
    elif isinstance(data, Decimal):
        return float(data)   # or str(data) if you prefer precision-safe output
    elif isinstance(data, (datetime, date)):
        return data.isoformat()
    else:
        return data
        
def driver(trans, policy, effdte):
    premiumdict={}
    try:
        # message= "Delete orphan EDS records & copy MCA EDS records to temp file DMBP121P"
        # query = f"DELETE FROM {config['library']}.DMBP121P WHERE TRANS = '{trans}' AND POLICY = '{policy}' AND EFFDTE = '{effdte}'"
        # querylog(f"{message} \n{query}")
        # cursor.execute(query)
        # message="46 Insert";
        # query = f"""INSERT INTO {config['library']}.DMBP121P(SELECT * FROM {config['library']}.DMBP121 WHERE TRANS = '{trans}' AND POLICY = '{policy}' AND EFFDTE = '{effdte}')"""
        # querylog(f"{message} \n{query}")
        # cursor.execute(query)

        message= "LOAD POLICY LINKAGE RECORD"
        query = f"SELECT * FROM {config['library']}.DWXP110PY WHERE TRANS ='{trans}' AND POLICY= '{policy}' AND EFFDTE = {effdte}"
        querylog(f"{message} \n{query}")
        cursor.execute(query)
        data = cursor.fetchall()
        DWXP110PY = dict(zip([col[0] for col in cursor.description], data[0]))

        message= "LOAD MCA RATE LINKAGE RECORD"
        query = f"SELECT * FROM {config['library']}.DMBPRATPY WHERE TRANS ='{trans}' AND POLICY = '{policy}' AND EFFDTE = {effdte}"
        querylog(f"{message} \n{query}")
        cursor.execute(query)
        data = cursor.fetchall()
        DMBPRATPY = dict(zip([col[0] for col in cursor.description], data[0]))
        DMBPRATPY['RATING_ERROR_DESC'] = ""
        DMBPRATPY['RATING_STATUS'] = ""

        message="LOAD STAT LINKAGE RECORDS"
        query = f"SELECT LOCNUM,BLDNUM,INTCOV,PREMO,RTEDEP,RTEMOD,COVRG,RATEID,FORM,POLTYP,EXPOSE,TFS,CURR_CLASS,ORIG_STATUS,CURR_STATUS, DEDSIZ FROM {config['library']}.DMBPSTATPY WHERE TRANS ='{trans}' AND POLICY = '{policy}' AND EFFDTE = {effdte}"
        querylog(f"{message} \n{query}")
        cursor.execute(query)
        data = cursor.fetchall()
        DMBPSTATPY = [dict(zip([col[0] for col in cursor.description], row)) for row in data]
        STAT_END = len(DMBPSTATPY)

        message="LOAD VEHICLE RECORDS"
        query = f"SELECT * FROM {config['library']}.DMBP130P WHERE TRANS ='{trans}' AND POLICY = '{policy}' AND EFFDTE = {effdte}"
        querylog(f"{message} \n{query}")
        cursor.execute(query)
        data = cursor.fetchall()
        DMBP130P = [dict(zip([col[0] for col in cursor.description], row)) for row in data]

        message= "LOAD RATING PROGRAM RECORDS"
        query = f"SELECT CBLPGM FROM {config['library']}.DWXF213 WHERE CO = '{DWXP110PY['CO']}' AND PROD = '{DWXP110PY['PROD']}' AND PRMSTE = '{DMBPRATPY['MCA_PRMSTE']}' AND PROGRM = '{DMBPRATPY['MCA_PROGRM']}'AND CBLPGM NOT IN ('CMBPLFL01') AND RTCTL1 = '{DMBPRATPY['MCA_PPCVFM']}' AND ((EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE = 0) OR (EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE >= {DWXP110PY['RATE_DATE']}))"
        querylog(f"{message} \n{query}")
        cursor.execute(query)
        data = cursor.fetchall()
        DWXF213 = [dict(zip([col[0] for col in cursor.description], row)) for row in data]

        if not DWXF213:
            DMBPRATPY['RATING_ERROR_DESC'] = "RATE ERR: NO RATE MODULES FOR ST/PROG/FORM/DWELL TYPE"
            DMBPRATPY['RATING_STATUS'] = "E"
            sys.exit()

        message=" CALL EACH RATING MODULE UNTIL DONE OR ERROR"
        if len(DWXF213) > 0:
            for i in range(len(DWXF213)):
                PGM3 = DWXF213[i]['CBLPGM'][0:7][4:]
                #querylog(f"\t\t{DWXF213[i]['CBLPGM'].strip()}\n======= ,trans:{DWXP110PY["TRANS"]}")
                querylog(f"\t\t{DWXF213[i]['CBLPGM'].strip()}\n======= ,trans:{DWXP110PY['TRANS']}")
                if DMBPRATPY['RATING_STATUS'] != "E" and PGM3 in DMBPRATPY['CALL_PGM']:
                    try:
                        module = importlib.import_module(DWXF213[i]['CBLPGM'].strip())
                        module.run(DWXP110PY, DMBPRATPY, DMBP130P, DMBPSTATPY, STAT_END)
                    except Exception as e:
                        print(f"{DWXF213[i]['CBLPGM']}: {e}")
        #250967         query = f"UPDATE {config['library']}.DMBPRATPY SET RATERRDSC1 = '{e} -- {PGM3}', RATINGSTAT = 'E' WHERE trans = '{trans}' AND POLICY = '{policy}' AND EFFDTE = {effdte}"
                        query = f"UPDATE {config['library']}.DMBPRATPY SET RATERRDSC1 = '{e} -- {PGM3}', RATINGSTAT = 'E' WHERE TRANS = '{trans}' AND POLICY = '{policy}' AND EFFDTE = {effdte}"
                        querylog(f"{message} \n{query}")
                        cursor.execute(query)
                        connection.commit()
                        sys.exit()
                elif DMBPRATPY['RATING_STATUS'] == "E":
        #250967     query = f"UPDATE {config['library']}.DMBPRATPY SET RATERRDSC1 = '{DMBPRATPY['RATING_ERROR_DESC']}', RATINGSTAT = 'E' WHERE trans = '{trans}' AND POLICY = '{policy}' AND EFFDTE = {effdte}"
                    query = f"UPDATE {config['library']}.DMBPRATPY SET RATERRDSC1 = '{DMBPRATPY['RATING_ERROR_DESC']}', RATINGSTAT = 'E' WHERE TRANS = '{trans}' AND POLICY = '{policy}' AND EFFDTE = {effdte}"
                    querylog(f"{message} 'E' \n{query}")
                    cursor.execute(query)
                    connection.commit()
                    sys.exit()

        query = f"UPDATE {config['library']}.DMBPRATPY SET " + ', '.join("{}='{}'".format(k, v) for k, v in DMBPRATPY.items()) + f" WHERE TRANS ='{trans}' AND POLICY= '{policy}' AND EFFDTE = {effdte}"
        querylog(f"{message} \n{query}")
        cursor.execute(query)

        query = f"UPDATE {config['library']}.DWXP110PY SET " + ', '.join("{}='{}'".format(k, v) for k, v in DWXP110PY.items()) + f" WHERE TRANS ='{trans}' AND POLICY= '{policy}' AND EFFDTE = {effdte}"
        querylog(f"{message} \n{query}")
        cursor.execute(query)

    except Exception as e:
        print(e)
    finally:
        connection.commit()
        # connection.close()
        df = pd.DataFrame(DMBP130P)
        totalpre=pd.to_numeric(df['APRP'], errors='coerce').sum();
        premiumdict["RatingData"] = {
                "TOTALPREMIUM":totalpre,
                "DMBPRATPY": DMBPRATPY,
                "DWXP110PY": DWXP110PY,
                "DMBPSTATPY": DMBPSTATPY,
                "DMBP130P": DMBP130P,
            }
    return json.dumps(clean([premiumdict]), default=str)
    
        
if __name__ == '__main__':
    trans = sys.argv[1]
    policy = sys.argv[2]
    effdte = sys.argv[3]
    # trans = "10"
    # policy = "MCAQ002859"
    # effdte = "20260121"
    driver(trans, policy, effdte)
    res=driver(trans, policy, effdte)
    # print(res)
    # print([res]), default=str))
    # sys.exit(res)
