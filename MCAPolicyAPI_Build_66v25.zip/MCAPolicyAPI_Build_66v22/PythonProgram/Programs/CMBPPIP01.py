# *******************************************************************
# *    MCA RATING - CALCULATE PIP                                   *
# *    PROGRAM-ID - CMBPPIP01.py                                    *
# *******************************************************************
#* SECONDARY RATE ERROR CORRECTION                      03-03-26|KAA*
#********************************************************************
from settings import config, cursor, connection, get_round, get_round_3, truncate, get_round_2
from decimal import Decimal

def run(DWXP110PY, DMBPRATPY, DMBP130P, DMBPSTATPY, STAT_END):

    experience_mod = {}

    for i in range(len(DMBP130P)):
        if DMBP130P[i]['LOCNUM'].strip() > "499":
            continue

        if DMBP130P[i]['VEHTYP'] == 'U' and DMBP130P[i]['CLASX'][1] != "8":
            continue

        if DMBP130P[i]['PIPLM1'].strip() == "":
            continue

        if DMBP130P[i]['PIPLM1'].strip() != '8000':
            continue

        # RETRIEVE BASE PREMIUM
        query = f"SELECT BASPRM FROM {config['library']}.DMBF21701 WHERE CO = '{DWXP110PY['CO']}' AND PROD = '{DWXP110PY['PROD']}' AND PRMSTE = '{DMBPRATPY['MCA_PRMSTE']}' AND PROGRM = '{DMBPRATPY['MCA_PROGRM']}' AND INTCOV = 'PIP' AND TERR = '{DMBP130P[i]['TERR']}' AND FLEET = '{DMBPRATPY['FLEET']}' AND VHTYPE = '{DMBP130P[i]['TYPE_OF_VEH']}' AND SIZCLS = '{DMBP130P[i]['CLASX'][0]}' AND ((EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE = 0) OR (EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE >= {DWXP110PY['RATE_DATE']}))"
        cursor.execute(query)
        data = cursor.fetchone()
        if not data:
            DMBPRATPY['RATING_ERROR_DESC'] = "CMBPPIP01 - FAILED TO FETCH BASE PREMIUM."
            DMBPRATPY['RATING_STATUS'] = "E"
            return
        else:
            DMBF21701 = dict(zip([col[0] for col in cursor.description], data))
            BASE_PREMIUM = DMBF21701['BASPRM']

        # RETRIEVE-PRIMARY-RATE
        if DMBP130P[i]['TYPE_OF_VEH'] == 'TT':
            query = f"SELECT PBIFAC FROM {config['library']}.DMBF21501 WHERE CO = '{DWXP110PY['CO']}' AND PROD = '{DWXP110PY['PROD']}' AND PRMSTE = '{DMBPRATPY['MCA_PRMSTE']}' AND PROGRM = '{DMBPRATPY['MCA_PROGRM']}' AND SIZCLS = '{DMBP130P[i]['CLASX'][0]}' AND BUSCLS = '{DMBP130P[i] ['CLASX'][1]}' AND RADCLS = '{DMBP130P[i]['CLASX'][2]}' AND ((EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE = 0) OR (EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE >= {DWXP110PY['RATE_DATE']}))"
            cursor.execute(query)
            data = cursor.fetchone()
            if not data:
                DMBPRATPY['RATING_ERROR_DESC'] = "CMBPPIP01 - FAILED TO FETCH PBI_PRI_FACTOR"
                DMBPRATPY['RATING_STATUS'] = "E"
                return
            else:
                DMBF21501 = dict(zip([col[0] for col in cursor.description], data))
                PBI_PRI_FACTOR = DMBF21501['PBIFAC']

        # RETRIEVE TERR DEVIATION
        query = f"SELECT MISRT1 FROM {config['library']}.DWAF22801 WHERE CO = '{DWXP110PY['CO']}' AND PROD = '{DWXP110PY['PROD']}' AND PRMSTE = '{DMBPRATPY['MCA_PRMSTE']}' AND PROGRM = '{DMBPRATPY['MCA_PROGRM']}' AND MISID = 'TERR DEV' AND MISVR1 = '{DMBP130P[i]['TERR']}' AND MISVR2 = 'PIP' AND MISVR3 = '{DMBP130P[i]['TYPE_OF_VEH']}' AND ((EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE = 0) OR (EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE >= {DWXP110PY['RATE_DATE']}))"
        cursor.execute(query)
        data = cursor.fetchone()
        if not data:
            DMBPRATPY['RATING_ERROR_DESC'] = "CMBPPIP01 - FAILED TO FETCH TERR_DEV_FAC"
            DMBPRATPY['RATING_STATUS'] = "E"
            return
        else:
            DWAF22801 = dict(zip([col[0] for col in cursor.description], data))
            TERR_DEV_FAC = truncate(DWAF22801['MISRT1'], 3)

        AUTOPLUS_FACTOR = 1.010

        if DMBPRATPY['FLEET'] == "N":
            AUTOPLUS_FACTOR = 1.030

        # RETRIEVE Increased Limit ISO CODE
        query = f"SELECT INCCD1 FROM {config['library']}.DMBF22501 WHERE CO = '{DWXP110PY['CO']}' AND PROD = '{DWXP110PY['PROD']}' AND PRMSTE = '{DMBPRATPY['MCA_PRMSTE']}' AND PROGRM = '{DMBPRATPY['MCA_PROGRM']}' AND INTCOV = 'PIP' AND COVLIM = '{DMBP130P[i]['PIPLM1']}' AND ((EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE = 0) OR (EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE >= {DWXP110PY['RATE_DATE']}))"
        cursor.execute(query)
        data = cursor.fetchone()
        if not data:
            DMBPRATPY['RATING_ERROR_DESC'] = "CMBPPIP01 - FAILED TO FETCH ISO_CODE."
            DMBPRATPY['RATING_STATUS'] = "E"
            return
        else:
            DMBF22501 = dict(zip([col[0] for col in cursor.description], data))
            ISO_CODE = DMBF22501['INCCD1']

        PBI_SEC_FACTOR = Decimal(0)

        if "1" < DMBP130P[i]['CLASX'][0] < "7":
            HOLD_SECCLS = DMBP130P[i]['CLASX'][3:5]

#260187     if not ("21" < HOLD_SECCLS > "29"):
            if  ("21" < HOLD_SECCLS < "30"):
                HOLD_RADCLS = DMBP130P[i]['CLASX'][2]
            else:
                HOLD_RADCLS = ""

            if DMBP130P[i]['CLASX'][3] == "7":
                HOLD_DMPFLG = "Y"
            else:
                HOLD_DMPFLG = "N"

            query = f"SELECT LIAFTR FROM {config['library']}.DMBF21601 WHERE CO = '{DWXP110PY['CO']}' AND PROD = '{DWXP110PY['PROD']}' AND PRMSTE = '{DMBPRATPY['MCA_PRMSTE']}' AND PROGRM = '{DMBPRATPY['MCA_PROGRM']}' AND SECCLS = '{HOLD_SECCLS}' AND RADCLS = '{HOLD_RADCLS}' AND DMPFLG = '{HOLD_DMPFLG}' AND ((EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE = 0) OR (EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE >= {DWXP110PY['RATE_DATE']}))"
            cursor.execute(query)
            data = cursor.fetchone()
            if not data:
                DMBPRATPY['RATING_ERROR_DESC'] = "CMBPPIP01 - FAILED TO FETCH PBI_SEC_FACTOR."
                DMBPRATPY['RATING_STATUS'] = "E"
                return
            else:
                DMBF21601 = dict(zip([col[0] for col in cursor.description], data))
                PBI_SEC_FACTOR = DMBF21601['LIAFTR']

        # EXPERIENE MOD SECTION
        if not experience_mod:
            if DWXP110PY['LOCZIP'] == "BASLIMPRM":
                COMBINED_FACTOR1 = 1
            else:
                COMBINED_FACTOR1 = DMBPRATPY['EXPMD1']
            COMBINED_FACTOR = get_round_2(COMBINED_FACTOR1)

            # Extract whole number and remainder
            WHOLE_NUMBER = int(str(COMBINED_FACTOR).split('.')[0])
            REMAINDER_NUMBER = int(str(COMBINED_FACTOR).split('.')[1])

            if WHOLE_NUMBER >= 1:
                RTEMOD_NUMERIC = str(WHOLE_NUMBER)[-1]
                RTEMOD_NUMERIC += str(REMAINDER_NUMBER).zfill(2)
            else:
                RTEMOD_NUMERIC = str(WHOLE_NUMBER)[-1]
                RTEMOD_NUMERIC += str(REMAINDER_NUMBER).zfill(2)

            COMBINED_FACTOR1 = DMBPRATPY['IRPM1']
            COMBINED_FACTOR = get_round_2(COMBINED_FACTOR1)

            WHOLE_NUMBER = int(str(COMBINED_FACTOR).split('.')[0])
            REMAINDER_NUMBER = int(str(COMBINED_FACTOR).split('.')[1])

            if WHOLE_NUMBER >= 1:
                RTEDEP_NUMERIC = str(WHOLE_NUMBER)[-1]
                RTEDEP_NUMERIC += str(REMAINDER_NUMBER).zfill(2)
            else:
                RTEDEP_NUMERIC = str(WHOLE_NUMBER)[-1]
                RTEDEP_NUMERIC += str(REMAINDER_NUMBER).zfill(2)

            # Insert to experience_mod values dictionary
            experience_mod["RTEMOD_CODE"] = RTEMOD_NUMERIC
            experience_mod["RTEDEP_CODE"] = RTEDEP_NUMERIC

        # COMPUTE PREMIUM
        if DMBP130P[i]['TYPE_OF_VEH'] == 'TT':
            BASE_PREMIUM = BASE_PREMIUM * (PBI_PRI_FACTOR + PBI_SEC_FACTOR)

        BASE_PREMIUM = get_round_3(BASE_PREMIUM * TERR_DEV_FAC)

        if DMBPRATPY['ACCOUNT'] == 'Y':
            BASE_PREMIUM = get_round_3(BASE_PREMIUM * Decimal(0.95))

        BASE_PREMIUM = get_round_3(BASE_PREMIUM * DMBPRATPY['RMF1'])

        if DMBP130P[i]['ENHCOV'] == 'Y':
            BASE_PREMIUM = get_round_3(BASE_PREMIUM * Decimal(AUTOPLUS_FACTOR))

        BASE_PREMIUM_CAL = get_round(BASE_PREMIUM)
        for s in range(int(DMBP130P[i]['MCA_STAT_CTR']), STAT_END):
            if DMBPSTATPY[s]['INTCOV'] == 'PIP' and DMBPSTATPY[s]['LOCNUM'] == DMBP130P[i]['LOCNUM']:
                DMBPSTATPY[s]['PREMO'] = BASE_PREMIUM_CAL
                DMBPSTATPY[s]['PIPLIM'] = ISO_CODE
                DMBPSTATPY[s]['CURR_STATUS'] = "Y"
                DMBPSTATPY[s]['RTEMOD'] = experience_mod['RTEMOD_CODE']
                DMBPSTATPY[s]['RTEDEP'] = experience_mod['RTEDEP_CODE']
                break



        
    


            
