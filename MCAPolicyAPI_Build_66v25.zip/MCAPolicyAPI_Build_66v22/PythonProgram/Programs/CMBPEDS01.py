# *********************************************************************************************************************
# * MCA AUTOMATIC ENDORSEMENT FORM GENERATION (DMBP121)                                                               *
# * PROGRAM-ID. CMBPEDS01                                                                                             *
# *                                                                                                                   *
# * Retrieve all existing forms on DMBP121 with current RCDTYP 1 & 3(policy_edsfrms) 2 (policy_edsfrms_deleted)       *
# * Create a list of all required conditional mandatory forms (cond_mandatory_edsfrms)                                *
# * Read DWXF081 for all mandatory forms.  Compare to existing forms on DMBP121.  Update as needed.                   *
# #********************************************************************************************************************
# SIR 260095 FORM MM9917 should attach if Auto Plus is Y   | AP | 02/03/26 |
# #********************************************************************************************************************

from settings import config, cursor, connection, get_round, get_round_3
from decimal import Decimal


def run(DWXP110PY, DMBPRATPY, DMBP130P, DMBPSTATPY, STAT_END):
    cond_mandatory_edsfrms = set()
    policy_edsfrms = set()
    policy_edsfrms_deleted = set()
    INSERT_RCDTYP_3 = False
    UPDATE_RCDTYP_2 = False

    # Conditional mandatory forms not updated in this program
    cond_mand_form = ('xxxxxx')

    # Create list of all internal coverages for adding mandatories by intcov
    intcov_set = {d['INTCOV'] for d in DMBPSTATPY if d['CURR_STATUS'] == 'Y'}

    # Create list of all forms on the policy and their status (RECTYP)
    query = f"SELECT EDSFRM,EDITDT,RCDTYP,MNDFLG FROM {config['library']}.DMBP121P WHERE TRANS = '{DWXP110PY['TRANS']}' AND POLICY = '{DWXP110PY['POLICY']}' AND EFFDTE = '{DWXP110PY['EFFDTE']}'"
    cursor.execute(query)
    data = cursor.fetchall()
    if not data:
        policy_edsfrms = set()
    else:
        DMBP121_FORMS = [dict(zip([col[0] for col in cursor.description], row)) for row in data]
        for k in range(len(DMBP121_FORMS)):
            if DMBP121_FORMS[k]['EDSFRM'].strip() not in cond_mand_form and DMBP121_FORMS[k]['MNDFLG'] != 'M':
                continue
            if DMBP121_FORMS[k]['RCDTYP'] in (3, 1):
                policy_edsfrms.add(DMBP121_FORMS[k]['EDSFRM'])
            else:
                policy_edsfrms_deleted.add(DMBP121_FORMS[k]['EDSFRM'])

    # Create list of all optional mandatory forms by policy
    query = f"SELECT MRTGTP FROM {config['library']}.DWXP145 WHERE TRANS = '{DWXP110PY['TRANS']}' AND POLICY = '{DWXP110PY['POLICY']}' "
    cursor.execute(query)
    data = cursor.fetchall()
    if data:
        DWXP145 = [dict(zip([col[0] for col in cursor.description], row)) for row in data]
        for i in range(len(DWXP145)):
            if DWXP145[i]['MRTGTP'] == 'S':
                cond_mandatory_edsfrms.add('MM2025')
            if DWXP145[i]['MRTGTP'] == 'L':
                cond_mandatory_edsfrms.add('MM2026')

    # Create a dummy record for adding new records
    query = f"SELECT * FROM {config['library']}.DMBP121 WHERE POLICY = 'DUMMY' "
    cursor.execute(query)
    data = cursor.fetchone()
    DMBP121_DUMMY = dict(zip([col[0] for col in cursor.description], data))

    # Create list of all optional mandatory by location
    for i in range(len(DMBP130P)):

        if DMBPRATPY['ACCOUNT'] == "Y":
            cond_mandatory_edsfrms.add('CAQM02')

        # SIR 260095 - If AutoPlus = Y then it should attach MM9917
        if DMBP130P[i]['ENHCOV'] == "Y":
            cond_mandatory_edsfrms.add('CAQM01')
            cond_mandatory_edsfrms.add('MM9917')

        if DMBP130P[i]['FULGLS'] == "Y": # SIR 260095 If Full Glass selected then attached this form
            cond_mandatory_edsfrms.add("MM9917")

        if DMBP130P[i]['EMPADDL'] == "Y":
            cond_mandatory_edsfrms.add('MM9950')

        if DMBP130P[i]['CLASX'] == "902000":
            cond_mandatory_edsfrms.add('MM9922')

        if DMBP130P[i]['FULGLS'] == "N" and DMBP130P[i]['CMPDED'].strip() != "":
            cond_mandatory_edsfrms.add('MM9951')

        if DMBP130P[i]['LCLDED'].strip() != "":
            cond_mandatory_edsfrms.add('MM9916')

        if DMBP130P[i]['COLDWV'] == "Y" and DMBP130P[i]['COLDED'].strip() != "":
            cond_mandatory_edsfrms.add('MM9917')

        if DMBP130P[i]['UNBLMD'].strip() != "":
            cond_mandatory_edsfrms.add('MM9928')

        if DMBP130P[i]['EMPADDL'] == "Y":
            cond_mandatory_edsfrms.add('MM9950')

    if 'MM9951' in cond_mandatory_edsfrms and 'MM9917' in cond_mandatory_edsfrms:
        cond_mandatory_edsfrms.remove('MM9951')

    # Update mandatory forms
    query = f"SELECT EDSFRM, MNDFLG, INTCOV, CDDESC, EDITDT, SINLIM FROM {config['library1']}.DWXF081 WHERE ((MNDFLG = 'M' AND INTCOV = '   ') OR (MNDFLG = 'M' AND INTCOV in ({intcov_set})) OR (MNDFLG = 'M' AND INTCV02 in ({intcov_set})) OR (MNDFLG = 'M' AND INTCV03 in ({intcov_set})) OR (MNDFLG = 'M' AND INTCV04 in ({intcov_set})) OR (MNDFLG = 'M' AND INTCV05 in ({intcov_set})) OR (MNDFLG = 'M' AND INTCV06 in ({intcov_set})) OR (INTCOV != '   ' AND EDSFRM in ({cond_mandatory_edsfrms}))) AND PROD = '{DWXP110PY['PROD']}' AND PRMSTE = '{DMBPRATPY['MCA_PRMSTE']}' AND PROGRM = '{DMBPRATPY['PROGRM']}' AND ((EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE = 0) OR (EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE >= {DWXP110PY['RATE_DATE']}))"
    cursor.execute(query)
    data = cursor.fetchall()
    DWXF081 = [dict(zip([col[0] for col in cursor.description], row)) for row in data]
    for i in range(len(DWXF081)):
        INSERT_RCDTYP_3 = False
        UPDATE_RCDTYP_2 = False

        # if INTCOV space and already on policy - no action needed; if form deleted update RCDTYP 2 to a 3; if frm not deleted insert RCDTYP 3
        if DWXF081[i]['INTCOV'].strip() == '':
            if DWXF081[i]['EDSFRM'] not in policy_edsfrms:
                if DWXF081[i]['EDSFRM'] in policy_edsfrms_deleted:
                    UPDATE_RCDTYP_2 = True
                else:
                    INSERT_RCDTYP_3 = True

        # if (INTCOV not space and not in cond_mandatory_edsfrms or stat records) and not on policy - no action needed;if form deleted update RCDTYP 2 to a 3; if frm not deleted insert RCDTYP 3
        if DWXF081[i]['INTCOV'].strip() != '':
            if (DWXF081[i]['EDSFRM'].strip() in cond_mandatory_edsfrms or DWXF081[i]['INTCOV'] in intcov_set) and \
                    DWXF081[i]['EDSFRM'] not in policy_edsfrms:
                if DWXF081[i]['EDSFRM'] in policy_edsfrms_deleted:
                    UPDATE_RCDTYP_2 = True
                else:
                    INSERT_RCDTYP_3 = True

        if DWXF081[i]['EDSFRM'] in policy_edsfrms:
            policy_edsfrms.remove(DWXF081[i]['EDSFRM'])

        if DWXF081[i]['EDSFRM'] in policy_edsfrms_deleted:
            policy_edsfrms_deleted.remove(DWXF081[i]['EDSFRM'])

        if INSERT_RCDTYP_3:
            DMBP121P = DMBP121_DUMMY
            DMBP121P['TRANS'] = DWXP110PY['TRANS']
            DMBP121P['POLICY'] = DWXP110PY['POLICY']
            DMBP121P['EFFDTE'] = DWXP110PY['EFFDTE']
            DMBP121P['EDSFRM'] = DWXF081[i]['EDSFRM']
            DMBP121P['EDSDTE'] = DWXP110PY['EDSDTE']
            DMBP121P['RCDTYP'] = '3'
            DMBP121P['COVEND'] = 0
            DMBP121P['MNDFLG'] = DWXF081[i]['MNDFLG']
            DMBP121P['CDDESC'] = DWXF081[i]['CDDESC']
            DMBP121P['EDITDT'] = DWXF081[i]['EDITDT']
            DMBP121P['INTCOV'] = DWXF081[i]['INTCOV']
            DMBP121P['SINLIM'] = DWXF081[i]['SINLIM']
            query = f"INSERT INTO {config['library']}.DMBP121P (" + ','.join(
                '{}'.format(k) for k in DMBP121P.keys()) + ') Values (' + ','.join(
                "'{}'".format(v) for v in DMBP121P.values()) + ')'
            cursor.execute(query)
        elif UPDATE_RCDTYP_2:
            DMBP121P['RCDTYP'] = '3'
            query = f"UPDATE {config['library']}.DMBP121P SET " + ', '.join("{}='{}'".format(k, v) for k, v in
                                                                            DMBP121P.items()) + f" WHERE TRANS ='{DWXP110PY['TRANS']}' AND POLICY= '{DWXP110PY['POLICY']}' AND EDSFRM = DWXF081[i]['EDSFRM'] AND RCDTYP = '2'"
            cursor.execute(query)

    # Delete mandatory forms that no longer apply
    if len(policy_edsfrms) > 0:
        for i in range(len(policy_edsfrms)):
            HLD_EDSFRM = policy_edsfrms.pop()
            if DWXP110PY['TRANS'] != '40':
                query = f"DELETE FROM {config['library']}.DMBP121P WHERE TRANS = '{DWXP110PY['TRANS']}' AND POLICY = '{DWXP110PY['POLICY']}' AND EFFDTE = {DWXP110PY['RATE_DATE']} AND EDSFRM = '{HLD_EDSFRM}'"
                cursor.execute(query)
                continue
            else:
                query = f"SELECT EDSFRM,RCDTYP FROM {config['library']}.DMBP121P WHERE TRANS = '{DWXP110PY['TRANS']}' AND POLICY = '{DWXP110PY['POLICY']}' AND EFFDTE = '{DWXP110PY['EFFDTE']}' AND EDSFRM = '{HLD_EDSFRM}'"
                cursor.execute(query)
                data = cursor.fetchall()
                if not data:
                    DMBPRATPY['RATING_ERROR_DESC'] = "DMBP121 not Found"
                    DMBPRATPY['RATING_STATUS'] = "E"
                    return
                else:
                    DMBP121P = [dict(zip([col[0] for col in cursor.description], row)) for row in data]
                    for k in range(len(DMBP121P)):
                        if DMBP121P[k]['RCDTYP'] == 3:
                            query = f"DELETE FROM {config['library']}.DMBP121P WHERE TRANS = '{DWXP110PY['TRANS']}' AND POLICY = '{DWXP110PY['POLICY']}' AND EFFDTE = {DWXP110PY['RATE_DATE']} AND EDSFRM = '{HLD_EDSFRM}'"
                            cursor.execute(query)
                        else:
                            DMBP121P[k]['RCDTYP'] = '2'
                            query = f"UPDATE {config['library']}.DMBP121P SET " + ', '.join(
                                "{}='{}'".format(k, v) for k, v in DMBP121P[
                                    k].items()) + f" WHERE TRANS ='{DWXP110PY['TRANS']}' AND POLICY= '{DWXP110PY['POLICY']}' AND EDSFRM = '{HLD_EDSFRM}'"
                            cursor.execute(query)
