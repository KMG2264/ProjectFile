# ************************************************************
# *    MCA RATING - CALCULATE COLLISION                      *
# *    PROGRAM-ID - CMBPCOL01.py                             *
# ************************************************************
# * 260187 secondary factor error               03/03/26|kaa *
# ************************************************************
from settings import config, cursor, connection, get_round, get_round_3, truncate, get_round_2
from decimal import Decimal


def run(DWXP110PY, DMBPRATPY, DMBP130P, DMBPSTATPY, STAT_END):

    base_prem = {}
    experience_mod = {}

    def get_base_premium_query(HOLD_SECCLS, HOLD_VEHAGE, HOLD_COST):
        query = f"SELECT BASPRM, CSTFRM, CSTTO FROM {config['library']}.DMBF81001 WHERE CO = '{DWXP110PY['CO']}' AND PROD = '{DWXP110PY['PROD']}' AND PRMSTE = '{DMBPRATPY['MCA_PRMSTE']}' AND PROGRM = '{DMBPRATPY['MCA_PROGRM']}' AND INTCOV = 'COL' AND TERR = '{DMBP130P[i]['TERR']}' AND FLEET = '{DMBPRATPY['FLEET']}' AND VHTYPE = '{DMBP130P[i]['TYPE_OF_VEH']}' AND SECCLS = '{HOLD_SECCLS}' AND VEHAGE = '{HOLD_VEHAGE}' AND ((EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE = 0) OR (EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE >= {DWXP110PY['RATE_DATE']}))"
        cursor.execute(query)
        data = cursor.fetchall()

        if not data:
            DMBPRATPY['RATING_ERROR_DESC'] = "CMBPCOL01 - FAILED TO FETCH BASE_PREMIUM."
            DMBPRATPY['RATING_STATUS'] = "E"
            return
        else:
            DMBF81001 = [dict(zip([col[0] for col in cursor.description], row)) for row in data]
            for b in range(len(DMBF81001)):
                if HOLD_COST >= DMBF81001[b]['CSTFRM'] and HOLD_COST <= DMBF81001[b]['CSTTO']: # For COST_ABOVE_90K
                    BASE_PREMIUM = DMBF81001[b]['BASPRM']
                    base_prem['BASE_PREMIUM'] = get_round_3(BASE_PREMIUM)
                    break
                elif not COST_ABOVE_90K and (HOLD_COST >= 90000 and DMBF81001[b]['CSTTO'] == 90000): # Not for COST_ABOVE_90K
                    BASE_PREMIUM = DMBF81001[b]['BASPRM']
                    base_prem['BASE_PREMIUM'] = get_round_3(BASE_PREMIUM)
                    break

    for i in range(len(DMBP130P)):
        if DMBP130P[i]['COLDED'].strip() == "":
            continue

        if DMBP130P[i]['LOCNUM'].strip() >= "500":
            continue

        HOLD_VEHAGE = DMBP130P[i]['AGE']
        HOLD_SECCLS = DMBP130P[i]['CLASX'][-3:]
        HOLD_COST = DMBP130P[i]['NEWCST']
        COST_ABOVE_90K = False

        if DMBP130P[i]['BODTYP'].strip() == "DUMP":
            HOLD_SECCLS = "790"

        ACV_RATING = True

        # RETRIEVE COLD WAIVER
        if DMBP130P[i]['COLDWV'] == "Y":
            query = f"SELECT MISRT1 FROM {config['library']}.DWAF22801 WHERE CO = '{DWXP110PY['CO']}' AND PROD = '{DWXP110PY['PROD']}' AND PRMSTE = '{DMBPRATPY['MCA_PRMSTE']}' AND PROGRM = '{DMBPRATPY['MCA_PROGRM']}'  AND MISID = 'COL WAIVER' AND MISVR1 = '{DMBP130P[i]['TERR']}' AND MISVR2 = '{DMBP130P[i]['COLDED']}' AND MISVR3 = '{DMBP130P[i]['TYPE_OF_VEH']} {DMBPRATPY['FLEET']}' AND ((EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE = 0) OR (EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE >= {DWXP110PY['RATE_DATE']}))"

            cursor.execute(query)
            data = cursor.fetchone()
            if not data:
                DMBPRATPY['RATING_ERROR_DESC'] = "CMBPCOL01 - COLDWV_CHARGE NOT FOUND"
                DMBPRATPY['RATING_STATUS'] = "E"
                return
            else:
                DWAF22801 = dict(zip([col[0] for col in cursor.description], data))
                COLDWV_CHARGE = DWAF22801['MISRT1']

        # RETRIEVE TERR DEV
        query = f"SELECT MISRT1 FROM {config['library']}.DWAF22801 WHERE CO = '{DWXP110PY['CO']}' AND PROD = '{DWXP110PY['PROD']}' AND PRMSTE = '{DMBPRATPY['MCA_PRMSTE']}' AND PROGRM = '{DMBPRATPY['MCA_PROGRM']}'  AND MISID = 'TERR DEV' AND MISVR1 = '{DMBP130P[i]['TERR']}' AND MISVR2 = 'COL' AND MISVR3 = '{DMBP130P[i]['TYPE_OF_VEH']}' AND ((EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE = 0) OR (EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE >= {DWXP110PY['RATE_DATE']}))"
        cursor.execute(query)
        data = cursor.fetchone()
        if not data:
            DMBPRATPY['RATING_ERROR_DESC'] = "CMBPCOL01 - TERR_DEV NOT FOUND"
            DMBPRATPY['RATING_STATUS'] = "E"
            return
        else:
            DWAF22801 = dict(zip([col[0] for col in cursor.description], data))
            TERR_DEV = DWAF22801['MISRT1']

        if HOLD_SECCLS == "790":
            get_base_premium_query(HOLD_SECCLS, HOLD_VEHAGE, HOLD_COST)
        else:
            HOLD_SECCLS = ""
            get_base_premium_query(HOLD_SECCLS, HOLD_VEHAGE, HOLD_COST)
        BASE_PREMIUM = base_prem['BASE_PREMIUM']
        TEMP_PREMIUM = BASE_PREMIUM

        if int(DMBP130P[i]['NEWCST']) > 90000:
            COST_ABOVE_90K = True
            HOLD_COST = 90001

            if HOLD_SECCLS == "790":
                get_base_premium_query(HOLD_SECCLS, HOLD_VEHAGE, HOLD_COST)
            elif DMBP130P[i]['TYPE_OF_VEH'] == "PP":
                HOLD_SECCLS = ""
                get_base_premium_query(HOLD_SECCLS, HOLD_VEHAGE, HOLD_COST)
            else:
                HOLD_SECCLS = ""
                HOLD_VEHAGE = ""
                get_base_premium_query(HOLD_SECCLS, HOLD_VEHAGE, HOLD_COST)
            BASE_PREMIUM = base_prem['BASE_PREMIUM']

        if DMBP130P[i]['COLDED'].strip() == "300" and DMBP130P[i]['TYPE_OF_VEH'] == "PP":
            query = f"SELECT MISRT1 FROM {config['library']}.DWAF22801 WHERE CO = '{DWXP110PY['CO']}' AND PROD = '{DWXP110PY['PROD']}' AND PRMSTE = '{DMBPRATPY['MCA_PRMSTE']}' AND PROGRM = '{DMBPRATPY['MCA_PROGRM']}' AND MISID = 'COL300' AND MISVR1 = '{DMBP130P[i]['TERR']}' AND MISVR2 = '{str(DMBP130P[i]['TYPE_OF_VEH'] + ' ' + DMBPRATPY['FLEET'])}' AND ((EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE = 0) OR (EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE >= {DWXP110PY['RATE_DATE']}))"
            cursor.execute(query)
            data = cursor.fetchone()
            if not data:
                DMBPRATPY['RATING_ERROR_DESC'] = "CMBPCOL01 - FAILED TO FETCH ADDL_PREMIUM"
                DMBPRATPY['RATING_STATUS'] = "E"
                return
            else:
                DWAF22801 = dict(zip([col[0] for col in cursor.description], data))
                ADDL_PREMIUM = DWAF22801['MISRT1']
                BASE_PREMIUM = get_round(BASE_PREMIUM + ADDL_PREMIUM)

        if COST_ABOVE_90K:
            BASE_DIFFERENCE = get_round(DMBP130P[i]['NEWCST'] - 90000)
            BASE_PREMIUM = truncate((BASE_PREMIUM * (BASE_DIFFERENCE / 1000)) + TEMP_PREMIUM, 3)

        if DMBP130P[i]['TYPE_OF_VEH'] == "TT":
            query = f"SELECT PCLFAC FROM {config['library']}.DMBF21501 WHERE CO = '{DWXP110PY['CO']}' AND PROD = '{DWXP110PY['PROD']}' AND PRMSTE = '{DMBPRATPY['MCA_PRMSTE']}' AND PROGRM = '{DMBPRATPY['MCA_PROGRM']}' AND SIZCLS = '{DMBP130P[i]['CLASX'][0]}' AND BUSCLS = '{DMBP130P[i]['CLASX'][1]}' AND RADCLS = '{DMBP130P[i]['CLASX'][2]}' AND ((EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE = 0) OR (EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE >= {DWXP110PY['RATE_DATE']}))"
            cursor.execute(query)
            data = cursor.fetchone()
            if not data:
                DMBPRATPY['RATING_ERROR_DESC'] = "CMBPCOL01 - FAILED TO FETCH PRIMRY_FAC"
                DMBPRATPY['RATING_STATUS'] = "E"
                return
            else:
                DMBF21501 = dict(zip([col[0] for col in cursor.description], data))
                PRIMRY_FAC = DMBF21501['PCLFAC']

        HOLD_DEDTPE = "WW" if DMBP130P[i]['COLDWV'] != "Y" else ""

        # RETRIEVING DEDUCT-FACTOR
        query = f"SELECT DEDFAC, DEDCOD FROM {config['library']}.DMBF22601 WHERE CO = '{DWXP110PY['CO']}' AND PROD = '{DWXP110PY['PROD']}' AND PRMSTE = '{DMBPRATPY['MCA_PRMSTE']}' AND PROGRM = '{DMBPRATPY['MCA_PROGRM']}' AND INTCOV = 'COL' AND PAPDED = '{DMBP130P[i]['COLDED']}' AND VHTYPE = '{DMBP130P[i]['TYPE_OF_VEH']}' AND DEDTPE = '{HOLD_DEDTPE}' AND ((EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE = 0) OR (EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE >= {DWXP110PY['RATE_DATE']}))"
        cursor.execute(query)
        data = cursor.fetchone()
        if not data:
            DMBPRATPY['RATING_ERROR_DESC'] = "CMBPCOL01 - FAILED TO FETCH DEDUCT FACTOR OR ISO CODE"
            DMBPRATPY['RATING_STATUS'] = "E"
            return
        else:
            DMBF22601 = dict(zip([col[0] for col in cursor.description], data))
            DEDUCT_FACTOR = DMBF22601['DEDFAC']
            ISO_CODE = DMBF22601['DEDCOD']

        if DMBPRATPY['FLEET'] == "Y":
            AUTO_PLUS = 1.01
        else:
            AUTO_PLUS = 1.03

        SECONDARY_FAC = Decimal(0)
        if DMBP130P[i]['CLASX'][0] > '1' and DMBP130P[i]['CLASX'][0] < '7':
            HOLD_SECCLS = DMBP130P[i]['CLASX'][3:5]

#260187     if not ("21" > HOLD_SECCLS  > "29"):
            if ("20" < HOLD_SECCLS < "30"):
                HOLD_RADCLS = DMBP130P[i]['CLASX'][2]
            else:
                HOLD_RADCLS = ""

            if DMBP130P[i]['CLASX'][3] == "7":
                HOLD_DMPFLG = "Y"
            else:
                HOLD_DMPFLG = "N"

            query = f"SELECT LIAFTR FROM {config['library']}.DMBF21601 WHERE CO = '{DWXP110PY['CO']}' AND PROD = '{DWXP110PY['PROD']}' AND PRMSTE = '{DMBPRATPY['MCA_PRMSTE']}' AND PROGRM = '{DMBPRATPY['MCA_PROGRM']}' AND SECCLS = '{HOLD_SECCLS}' AND RADCLS = '{HOLD_RADCLS}' AND DMPFLG = '{HOLD_DMPFLG}' AND ((EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE = 0) OR (EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE >= {DWXP110PY['RATE_DATE']}))"
            cursor.execute(query)
            data = cursor.fetchone()
            if not data:
                DMBPRATPY['RATING_ERROR_DESC'] = "CMBPCOL01 - FAILED TO FETCH SECONDARY FAC"
                DMBPRATPY['RATING_STATUS'] = "E"
                return
            else:
                DMBF21601 = dict(zip([col[0] for col in cursor.description], data))
                SECONDARY_FAC = DMBF21601['LIAFTR']

        # EXPERIENCE MOD SECTION
        if not experience_mod:
            if DWXP110PY['LOCZIP'] == "BASLIMPRM":
                COMBINED_FACTOR1 = 1
            else:
                COMBINED_FACTOR1 = DMBPRATPY['EXPMD2']
            COMBINED_FACTOR = get_round_2(COMBINED_FACTOR1)

            # Extract whole number and remainder
            WHOLE_NUMBER = int(str(COMBINED_FACTOR).split('.')[0])
            REMAINDER_NUMBER = int(str(COMBINED_FACTOR).split('.')[1])

            if WHOLE_NUMBER >= 1:
                RTEMOD_NUMERIC = str(WHOLE_NUMBER)[-1]
                RTEMOD_NUMERIC += str(REMAINDER_NUMBER).zfill(2)
            else:
                RTEMOD_NUMERIC = str(WHOLE_NUMBER)[-1]
                RTEMOD_NUMERIC += str(REMAINDER_NUMBER).zfill(2)

            COMBINED_FACTOR1 = DMBPRATPY['IRPM2']
            COMBINED_FACTOR = get_round_2(COMBINED_FACTOR1)

            WHOLE_NUMBER = int(str(COMBINED_FACTOR).split('.')[0])
            REMAINDER_NUMBER = int(str(COMBINED_FACTOR).split('.')[1])

            if WHOLE_NUMBER >= 1:
                RTEDEP_NUMERIC = str(WHOLE_NUMBER)[-1]
                RTEDEP_NUMERIC += str(REMAINDER_NUMBER).zfill(2)
            else:
                RTEDEP_NUMERIC = str(WHOLE_NUMBER)[-1]
                RTEDEP_NUMERIC += str(REMAINDER_NUMBER).zfill(2)

            # Insert into experience_mod values dictionary
            experience_mod["RTEMOD_CODE"] = RTEMOD_NUMERIC
            experience_mod["RTEDEP_CODE"] = RTEDEP_NUMERIC

        # COMPUTE PREMIUM
        if DMBP130P[i]['TYPE_OF_VEH'] == "TT" and ACV_RATING:
            BASE_PREMIUM = get_round_3(BASE_PREMIUM * DEDUCT_FACTOR)
            BASE_PREMIUM = get_round_3(BASE_PREMIUM * (PRIMRY_FAC + SECONDARY_FAC))

            if DMBP130P[i]['COLDWV'] == "Y":
                BASE_PREMIUM = get_round_3(BASE_PREMIUM + COLDWV_CHARGE)

            if DMBP130P[i]['ENHCOV'] == "Y":
                BASE_PREMIUM = get_round_3(BASE_PREMIUM * TERR_DEV)

                if DMBPRATPY['ACCOUNT'] == "Y":
                    BASE_PREMIUM = get_round_3(BASE_PREMIUM * Decimal(0.95))
                BASE_PREMIUM = get_round_3(BASE_PREMIUM * DMBPRATPY['RMF2'] * Decimal(AUTO_PLUS))
            else:
                BASE_PREMIUM = get_round_3(BASE_PREMIUM * TERR_DEV)
                if DMBPRATPY['ACCOUNT'] == "Y":
                    BASE_PREMIUM = get_round_3(BASE_PREMIUM * Decimal(0.95))
                BASE_PREMIUM = get_round_3(BASE_PREMIUM * DMBPRATPY['RMF2'])

        elif ACV_RATING:
            BASE_PREMIUM = get_round_3(BASE_PREMIUM * DEDUCT_FACTOR)
            if DMBP130P[i]['COLDWV'] == "Y":
                BASE_PREMIUM += COLDWV_CHARGE

            if DMBP130P[i]['ENHCOV'] == "Y":
                BASE_PREMIUM = get_round_3(BASE_PREMIUM * TERR_DEV)

                if DMBPRATPY['ACCOUNT'] == "Y":
                    BASE_PREMIUM = get_round_3(BASE_PREMIUM * Decimal(0.95))
                BASE_PREMIUM = get_round_3(BASE_PREMIUM * DMBPRATPY['RMF2'] * Decimal(AUTO_PLUS))
            else:
                BASE_PREMIUM = get_round_3(BASE_PREMIUM * TERR_DEV)

                if DMBPRATPY['ACCOUNT'] == "Y":
                    BASE_PREMIUM = get_round_3(BASE_PREMIUM * Decimal(0.95))
                BASE_PREMIUM = get_round_3(BASE_PREMIUM * DMBPRATPY['RMF2'])

        BASE_PREMIUM_CAL = get_round(BASE_PREMIUM)
        for s in range(int(DMBP130P[i]['MCA_STAT_CTR']), STAT_END):
            if DMBPSTATPY[s]['INTCOV'] == 'COL' and DMBPSTATPY[s]['LOCNUM'] == DMBP130P[i]['LOCNUM']:
                DMBPSTATPY[s]['PREMO'] = BASE_PREMIUM_CAL
                DMBPSTATPY[s]['COLCOV'] = ISO_CODE
                DMBPSTATPY[s]['CURR_STATUS'] = "Y"
                DMBPSTATPY[s]['RTEMOD'] = experience_mod["RTEMOD_CODE"]
                DMBPSTATPY[s]['RTEDEP'] = experience_mod["RTEDEP_CODE"]
                break

    