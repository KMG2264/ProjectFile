# ************************************************************
# *    MCA rating - Calculate Liability                      *
# *    PROGRAM-ID - CMBPLIA01.py                             *
# ************************************************************
# *   SIR |  Description of change           |  Date  |PGMR  *
# * 260243  Mulitply OBILMD by 1000 when      03/20/26 CJS   *
#*          comparing to DWAF228/MISVR2 and                  *
#*          MISVR3 (single limit discount factor)
# ************************************************************

from settings import config, cursor, connection, get_round, get_round_3, truncate, get_round_2
from decimal import Decimal


def run(DWXP110PY, DMBPRATPY, DMBP130P, DMBPSTATPY, STAT_END):

    experience_mod = {}

    for i in range(len(DMBP130P)):

        # Temporarily holding the value of COM_BASE_PREMIUM and BIL_BASE_PREMIUM
        base_prem_hold_temp = {}

        def c100(DWXP110PY, DMBPRATPY, DMBP130P, DMBPSTATPY, STAT_END, HOLD_INTCOV, HOLD_COVLIM, HOLD_TERR, HOLD_SIZCLS, HOLD_VHTYPE, HOLD_FLEET, HOLD_VEHCLS, SPLIT_LIAB, CSL_LIAB, PROCESS_BIL, PDLLMD, OBILMD, PROCESS_OBI, PROCESS_PDL, PROCESS_CSL):

            # RETRIEVING BASE_PREMIUM
            query = f"SELECT BASPRM FROM {config['library']}.DMBF21701 WHERE CO = '{DWXP110PY['CO']}' AND PROD = '{DWXP110PY['PROD']}' AND PRMSTE = '{DMBPRATPY['MCA_PRMSTE']}' AND PROGRM = '{DMBPRATPY['MCA_PROGRM']}' AND INTCOV = '{HOLD_INTCOV}' AND TERR = '{HOLD_TERR}' AND FLEET = '{HOLD_FLEET}' AND VHTYPE = '{HOLD_VHTYPE}' AND SIZCLS = '{HOLD_SIZCLS}' AND ((EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE = 0) OR (EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE >= {DWXP110PY['RATE_DATE']}))"
            cursor.execute(query)
            data = cursor.fetchone()
            if not data:
                DMBPRATPY['RATING_ERROR_DESC'] = "CMBPLIA01A - BIL BASEPREM Failed"
                DMBPRATPY['RATING_STATUS'] = "E"
                return
            else:
                DMBF21701_BIL = dict(zip([col[0] for col in cursor.description], data))
                BASE_PREMIUM = DMBF21701_BIL['BASPRM']
                if not base_prem_hold_temp:
                    base_prem_hold_temp['COM_BASE_PREMIUM'] = BASE_PREMIUM

            if PROCESS_BIL:
                # HOLD_COVLIM = "20/40"
                HOLD_COVLIM = "25/50" #SIR250155
                HOLD_SIZCLS = ' '
                HOLD_VHTYPE = ' '

            if PROCESS_OBI or PROCESS_CSL:
                HOLD_COVLIM = HOLD_COVLIM
                HOLD_SIZCLS = ' '
                HOLD_VHTYPE = ' '
                BASE_PREMIUM = BASE_PREMIUM + base_prem_hold_temp['COM_BASE_PREMIUM']

            # RETRIEVING INCREASE LIMITS (C320-INCR-LIMITS-LF02)
            query = f"SELECT INCRT1, INCCD1, INCCD2 FROM {config['library']}.DMBF22501 WHERE CO = '{DWXP110PY['CO']}' AND PROD = '{DWXP110PY['PROD']}' AND PRMSTE = '{DMBPRATPY['MCA_PRMSTE']}' AND PROGRM = '{DMBPRATPY['MCA_PROGRM']}' AND INTCOV = '{HOLD_INTCOV}' AND TRIM(SIZCLS) = '{HOLD_SIZCLS}' AND TRIM(VHTYPE) = '{HOLD_VHTYPE}' AND COVLIM = '{HOLD_COVLIM}' AND ((EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE = 0) OR (EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE >= {DWXP110PY['RATE_DATE']}))"
            cursor.execute(query)
            data = cursor.fetchone()
            if not data:
                DMBPRATPY['RATING_ERROR_DESC'] = "CMBPLIA01A - ISO CODE Failed"
                DMBPRATPY['RATING_STATUS'] = "E"
                return
            else:
                DMBF22501 = dict(zip([col[0] for col in cursor.description], data))
                INCR_FACTOR = DMBF22501['INCRT1']
                ISO_CODE = DMBF22501['INCCD1']

                # SIR 250155
                if HOLD_INTCOV == 'BIL':
                    INCR_BILILF = DMBF22501['INCRT1']

                # SIR 250155
                if HOLD_INTCOV == 'OBI':
                    INCR_OBIILF = DMBF22501['INCRT1']

                if CSL_LIAB:
                    ISO_CODE = DMBF22501['INCCD2']

            # In COBOL, the ISO-CODE for BIL will be substituted with either the INTCOV from CSL or the SPLIT LIMIT from OBI.
            if PROCESS_BIL and CSL_LIAB or PROCESS_BIL and SPLIT_LIAB:
                if SPLIT_LIAB:
                    HOLD_COVLIM = OBILMD
                else:
                    WORK_CSL_LMT = OBILMD.strip()
                    HOLD_COVLIM = WORK_CSL_LMT + "/" + WORK_CSL_LMT

                query = f"SELECT INCRT1, INCCD1, INCCD2 FROM {config['library']}.DMBF22501 WHERE CO = '{DWXP110PY['CO']}' AND PROD = '{DWXP110PY['PROD']}' AND PRMSTE = '{DMBPRATPY['MCA_PRMSTE']}' AND PROGRM = '{DMBPRATPY['MCA_PROGRM']}' AND INTCOV = 'OBI' AND TRIM(SIZCLS) = '{HOLD_SIZCLS}' AND TRIM(VHTYPE) = '{HOLD_VHTYPE}' AND COVLIM = '{HOLD_COVLIM}' AND ((EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE = 0) OR (EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE >= {DWXP110PY['RATE_DATE']}))"
                cursor.execute(query)
                data = cursor.fetchone()
                if not data:
                    DMBPRATPY['RATING_ERROR_DESC'] = "CMBPLIA01A - ISO CODE Failed"
                    DMBPRATPY['RATING_STATUS'] = "E"
                    return
                else:
                    DMBF22501 = dict(zip([col[0] for col in cursor.description], data))
                    if PROCESS_BIL and SPLIT_LIAB:
                        ISO_CODE = DMBF22501['INCCD1']
                    else:
                        ISO_CODE = DMBF22501['INCCD2']


            if PROCESS_BIL or PROCESS_OBI or PROCESS_CSL:
                HOLD_SIZCLS = HOLD_VEHCLS[0]
                HOLD_VHTYPE = DMBP130P[i]['TYPE_OF_VEH']


            # RETRIEVING SINGLE LIMIT
            if PROCESS_PDL and CSL_LIAB:
#260243         query = f"SELECT MISRT1 FROM {config['library']}.DWAF22801 WHERE CO = '{DWXP110PY['CO']}' AND PROD = '{DWXP110PY['PROD']}' AND PRMSTE = '{DMBPRATPY['MCA_PRMSTE']}' AND PROGRM = '{DMBPRATPY['MCA_PROGRM']}'  AND MISID = 'CSL' AND MISVR1 = 'ALL' AND ((EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE = 0) OR (EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE >= {DWXP110PY['RATE_DATE']}))"
                HOLD_LIMIT = int(DMBP130P[i]['OBILMD'].strip()) * 1000
                query = f"SELECT MISVR2, MISVR3, MISRT1 FROM {config['library']}.DWAF22801 WHERE CO = '{DWXP110PY['CO']}' AND PROD = '{DWXP110PY['PROD']}' AND PRMSTE = '{DMBPRATPY['MCA_PRMSTE']}' AND PROGRM = '{DMBPRATPY['MCA_PROGRM']}'  AND MISID = 'CSL' AND MISVR1 = 'ALL' AND ((EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE = 0) OR (EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE >= {DWXP110PY['RATE_DATE']}))"
                cursor.execute(query)
#260243         data = cursor.fetchone()
                data = cursor.fetchall()
                if not data:
                    DMBPRATPY['RATING_ERROR_DESC'] = "CMBPLIA01A - WORK LIMITS Failed"
                    DMBPRATPY['RATING_STATUS'] = "E"
                    return
                else:
#260243     #        DWAF22801 = dict(zip([col[0] for col in cursor.description], data))
                     DWAF22801 = [dict(zip([col[0] for col in cursor.description], row)) for row in data]
                     for k in range(len(DWAF22801)):
                         if HOLD_LIMIT >= int(DWAF22801[k]['MISVR2']) and HOLD_LIMIT <= int(DWAF22801[k]['MISVR3']):
                             SING_LMT_DSC = DWAF22801[k]['MISRT1']


            if HOLD_VHTYPE == "TT":
                HOLD_BUSCLS = HOLD_VEHCLS[1]
                HOLD_RADCLS = HOLD_VEHCLS[2]
                query = f"SELECT PBIFAC, PPDFAC FROM {config['library']}.DMBF21501 WHERE CO = '{DWXP110PY['CO']}' AND PROD = '{DWXP110PY['PROD']}' AND PRMSTE = '{DMBPRATPY['MCA_PRMSTE']}' AND PROGRM = '{DMBPRATPY['MCA_PROGRM']}' AND SIZCLS = '{HOLD_SIZCLS}' AND BUSCLS = '{HOLD_BUSCLS}' AND RADCLS = '{HOLD_RADCLS}' AND ((EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE = 0) OR (EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE >= {DWXP110PY['RATE_DATE']}))"
                cursor.execute(query)
                data = cursor.fetchone()
                if not data:
                    DMBPRATPY['RATING_ERROR_DESC'] = "CMBPLIA01A - PPD PRI FACTOR Failed"
                    DMBPRATPY['RATING_STATUS'] = "E"
                    return
                else:
                    DMBF21501 = dict(zip([col[0] for col in cursor.description], data))
                    PBI_PRI_FACTOR = DMBF21501['PBIFAC']
                    if PROCESS_PDL:
                        PPD_PRI_FACTOR = DMBF21501['PPDFAC']

            # RETRIVING TERR DEV
            if PROCESS_BIL:
                HOLD_MISVR2 = "BIL"
            if PROCESS_OBI or PROCESS_CSL:
                HOLD_MISVR2 = "OBI"
            if PROCESS_PDL:
                HOLD_MISVR2 = "PDL"
            query = f"SELECT MISRT1 FROM {config['library']}.DWAF22801 WHERE CO = '{DWXP110PY['CO']}' AND PROD = '{DWXP110PY['PROD']}' AND PRMSTE = '{DMBPRATPY['MCA_PRMSTE']}' AND PROGRM = '{DMBPRATPY['MCA_PROGRM']}'  AND MISID = 'TERR DEV' AND MISVR1 = '{HOLD_TERR}' AND MISVR2 = '{HOLD_MISVR2}' AND MISVR3 = '{HOLD_VHTYPE}' AND ((EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE = 0) OR (EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE >= {DWXP110PY['RATE_DATE']}))"
            cursor.execute(query)
            data = cursor.fetchone()
            if not data:
                DMBPRATPY['RATING_ERROR_DESC'] = "CMBPLIA01A - TERR DEV Factor Failed"
                DMBPRATPY['RATING_STATUS'] = "E"
                return
            else:
                DWAF22801 = dict(zip([col[0] for col in cursor.description], data))
                TERR_DEV_FAC = truncate(DWAF22801['MISRT1'], 3)

            AUTOPLUS_FACTOR = 1.010
            if HOLD_FLEET == "N":
                AUTOPLUS_FACTOR = 1.030

            if '1' < HOLD_VEHCLS[0] < '7':
                HOLD_SECCLS = HOLD_VEHCLS[3:5]

                if "21" > HOLD_SECCLS > "29":
                    HOLD_RADCLS = HOLD_VEHCLS[2]
                else:
                    HOLD_RADCLS = ""

                if HOLD_VEHCLS[3] == "7":
                    HOLD_DMPFLG = "Y"
                else:
                    HOLD_DMPFLG = "N"

                query = f"SELECT LIAFTR, PDFTR FROM {config['library']}.DMBF21601 WHERE CO = '{DWXP110PY['CO']}' AND PROD = '{DWXP110PY['PROD']}' AND PRMSTE = '{DMBPRATPY['MCA_PRMSTE']}' AND PROGRM = '{DMBPRATPY['MCA_PROGRM']}' AND SECCLS = '{HOLD_SECCLS}' AND TRIM(RADCLS) = '{HOLD_RADCLS}' AND DMPFLG = '{HOLD_DMPFLG}' AND ((EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE = 0) OR (EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE >= {DWXP110PY['RATE_DATE']}))"
                cursor.execute(query)
                data = cursor.fetchone()
                if not data:
                    DMBPRATPY['RATING_ERROR_DESC'] = "CMBPLIA01A - PBI SEC Factor Failed"
                    DMBPRATPY['RATING_STATUS'] = "E"
                    return
                else:
                    DMBF21601 = dict(zip([col[0] for col in cursor.description], data))
                    PBI_SEC_FACTOR = DMBF21601['LIAFTR']
                    PPD_SEC_FACTOR = DMBF21601['PDFTR']
            else:
                PBI_SEC_FACTOR = PPD_SEC_FACTOR = 0

            ##### EXPERIENCE MOD SECTION #####
            if not experience_mod:
                if DWXP110PY['LOCZIP'] == "BASLIMPRM":
                    COMBINED_FACTOR1 = 1
                else:
                    COMBINED_FACTOR1 = DMBPRATPY['EXPMD1']
                COMBINED_FACTOR = get_round_2(COMBINED_FACTOR1)

                # Extract whole number and remainder
                WHOLE_NUMBER = int(str(COMBINED_FACTOR).split('.')[0])
                REMAINDER_NUMBER = int(str(COMBINED_FACTOR).split('.')[1])

                if WHOLE_NUMBER >= 1:
                    RTEMOD_NUMERIC = str(WHOLE_NUMBER)[-1]
                    RTEMOD_NUMERIC += str(REMAINDER_NUMBER).zfill(2)
                else:
                    RTEMOD_NUMERIC = str(WHOLE_NUMBER)[-1]
                    RTEMOD_NUMERIC += str(REMAINDER_NUMBER).zfill(2)

                COMBINED_FACTOR1 = DMBPRATPY['IRPM1']
                COMBINED_FACTOR = get_round_2(COMBINED_FACTOR1)

                WHOLE_NUMBER = int(str(COMBINED_FACTOR).split('.')[0])
                REMAINDER_NUMBER = int(str(COMBINED_FACTOR).split('.')[1])

                if WHOLE_NUMBER >= 1:
                    RTEDEP_NUMERIC = str(WHOLE_NUMBER)[-1]
                    RTEDEP_NUMERIC += str(REMAINDER_NUMBER).zfill(2)
                else:
                    RTEDEP_NUMERIC = str(WHOLE_NUMBER)[-1]
                    RTEDEP_NUMERIC += str(REMAINDER_NUMBER).zfill(2)

                # Insert into experience_mod values dictionary
                experience_mod["RTEMOD_CODE"] = RTEMOD_NUMERIC
                experience_mod["RTEDEP_CODE"] = RTEDEP_NUMERIC

            ##### COMPUTE PREMIUM SECTION  -  C400-COMPUTE-PREMIUM. #####

            # SIR 250155
            if PROCESS_BIL:
                BIL_BASE_PREMIUM = truncate(base_prem_hold_temp['COM_BASE_PREMIUM'] * INCR_BILILF)
                base_prem_hold_temp['BIL_BASE_PREMIUM'] = BIL_BASE_PREMIUM
                BASE_PREMIUM = BIL_BASE_PREMIUM

            if PROCESS_PDL or PROCESS_CSL:
                BASE_PREMIUM = get_round_3(BASE_PREMIUM * INCR_FACTOR)

            # SIR 250155
            if PROCESS_CSL:
                BASE_PREMIUM = BASE_PREMIUM - base_prem_hold_temp['BIL_BASE_PREMIUM']

            # SIR 250155
            if PROCESS_OBI:
                BASE_PREMIUM = (BASE_PREMIUM * INCR_OBIILF) - base_prem_hold_temp['BIL_BASE_PREMIUM']

            if PROCESS_PDL and CSL_LIAB:
                BASE_PREMIUM = get_round_3(BASE_PREMIUM * SING_LMT_DSC)

            # SIR 250155
            ALL_TTT_PREM = 0

            if HOLD_VHTYPE == "TT":
                if PROCESS_BIL:
                    BASE_PREMIUM = get_round_3(BIL_BASE_PREMIUM * (PBI_PRI_FACTOR + PBI_SEC_FACTOR))
                    ALL_TTT_PREM = truncate(BASE_PREMIUM)
                elif PROCESS_OBI or PROCESS_CSL:
                    BASE_PREMIUM = get_round_3(BASE_PREMIUM * (PBI_PRI_FACTOR + PBI_SEC_FACTOR))
                    ALL_TTT_PREM = truncate(BASE_PREMIUM)
                elif PROCESS_PDL:
                    BASE_PREMIUM = get_round_3(BASE_PREMIUM * (PPD_PRI_FACTOR + PPD_SEC_FACTOR))

            # if PROCESS_BIL:
            BASE_PREMIUM = get_round_3(BASE_PREMIUM * TERR_DEV_FAC)

            # SIR 250155
            if HOLD_VHTYPE == "TT" and (PROCESS_OBI or PROCESS_CSL):
                BASE_PREMIUM = get_round_3(ALL_TTT_PREM * TERR_DEV_FAC)

            if DMBP130P[i]['LNLSCOV'] == "Y":
                BASE_PREMIUM = get_round_3(BASE_PREMIUM * Decimal(1.04))

            if DMBPRATPY['ACCOUNT'] == "Y":
                BASE_PREMIUM = get_round_3(BASE_PREMIUM * Decimal('0.95'))

            BASE_PREMIUM = get_round_3(BASE_PREMIUM * DMBPRATPY['RMF1'])

            if DMBP130P[i]['ENHCOV'] == "Y":
                BASE_PREMIUM = get_round_3(BASE_PREMIUM * Decimal(AUTOPLUS_FACTOR))

            BASE_PREMIUM_CAL = get_round(BASE_PREMIUM)

            return BASE_PREMIUM_CAL, ISO_CODE

        if int(DMBP130P[i]['LOCNUM']) > 499:
            return

        if DMBP130P[i]['VEHTYP'] == 'U' and str(DMBP130P[i]['CLASX'])[1] != '8':
            continue

        SPLIT_LIAB = CSL_LIAB = PROCESS_OBI = PROCESS_PDL = PROCESS_CSL = False
        PROCESS_BIL = True

        HOLD_VEHCLS = str(DMBP130P[i]['CLASX'])

        HOLD_TERR = DMBP130P[i]['TERR']
        PDLLMD = DMBP130P[i]['PDLLMD']
        OBILMD = str(DMBP130P[i]['OBILMD'])

        HOLD_SIZCLS = HOLD_VEHCLS[0]
        HOLD_VHTYPE = DMBP130P[i]['TYPE_OF_VEH']
        HOLD_FLEET = DMBPRATPY['FLEET']

        if OBILMD.count('/') >= 1:
            SPLIT_LIAB = True
        else:
            CSL_LIAB = True

        if PROCESS_BIL:
            HOLD_INTCOV = 'BIL'
            HOLD_COVLIM = ' '
            BASE_PREMIUM_CAL, ISO_CODE = c100(DWXP110PY, DMBPRATPY, DMBP130P, DMBPSTATPY, STAT_END, HOLD_INTCOV, HOLD_COVLIM, HOLD_TERR, HOLD_SIZCLS, HOLD_VHTYPE, HOLD_FLEET, HOLD_VEHCLS, SPLIT_LIAB, CSL_LIAB, PROCESS_BIL, PDLLMD, OBILMD, PROCESS_OBI, PROCESS_PDL, PROCESS_CSL)
            for s in range(int(DMBP130P[i]['MCA_STAT_CTR']), STAT_END):
                if DMBPSTATPY[s]['INTCOV'] == "BIL" and DMBPSTATPY[s]['LOCNUM'] == DMBP130P[i]['LOCNUM']:
                    DMBPSTATPY[s]['PREMO'] = BASE_PREMIUM_CAL
                    DMBPSTATPY[s]['BILIM'] = ISO_CODE
                    DMBPSTATPY[s]['CURR_STATUS'] = "Y"
                    DMBPSTATPY[s]['RTEMOD'] = experience_mod["RTEMOD_CODE"]
                    DMBPSTATPY[s]['RTEDEP'] = experience_mod["RTEDEP_CODE"]
                    break

        if SPLIT_LIAB and OBILMD != ' ':
            HOLD_COVLIM = OBILMD
            HOLD_INTCOV = 'OBI'
            PROCESS_OBI = True
            PROCESS_BIL = False
            BASE_PREMIUM_CAL, ISO_CODE = c100(DWXP110PY, DMBPRATPY, DMBP130P, DMBPSTATPY, STAT_END, HOLD_INTCOV, HOLD_COVLIM, HOLD_TERR, HOLD_SIZCLS, HOLD_VHTYPE, HOLD_FLEET, HOLD_VEHCLS, SPLIT_LIAB, CSL_LIAB, PROCESS_BIL, PDLLMD, OBILMD, PROCESS_OBI, PROCESS_PDL, PROCESS_CSL)
            for s in range(int(DMBP130P[i]['MCA_STAT_CTR']), STAT_END):
                if DMBPSTATPY[s]['INTCOV'] == "OBI" and DMBPSTATPY[s]['LOCNUM'] == DMBP130P[i]['LOCNUM']:
                    DMBPSTATPY[s]['INTCOV'] = HOLD_INTCOV
                    DMBPSTATPY[s]['PREMO'] = BASE_PREMIUM_CAL
                    DMBPSTATPY[s]['BILIM'] = ISO_CODE
                    DMBPSTATPY[s]['CURR_STATUS'] = "Y"
                    DMBPSTATPY[s]['RTEMOD'] = experience_mod["RTEMOD_CODE"]
                    DMBPSTATPY[s]['RTEDEP'] = experience_mod["RTEDEP_CODE"]
                    break

        if CSL_LIAB and OBILMD != ' ':
            WORK_CSL_LMT = OBILMD.strip()
            HOLD_COVLIM = WORK_CSL_LMT + "/" + WORK_CSL_LMT
            HOLD_INTCOV = 'OBI'
            PROCESS_CSL = True
            PROCESS_BIL = False
            BASE_PREMIUM_CAL, ISO_CODE = c100(DWXP110PY, DMBPRATPY, DMBP130P, DMBPSTATPY, STAT_END, HOLD_INTCOV, HOLD_COVLIM, HOLD_TERR, HOLD_SIZCLS, HOLD_VHTYPE, HOLD_FLEET, HOLD_VEHCLS, SPLIT_LIAB, CSL_LIAB, PROCESS_BIL, PDLLMD, OBILMD, PROCESS_OBI, PROCESS_PDL, PROCESS_CSL)
            for s in range(int(DMBP130P[i]['MCA_STAT_CTR']), STAT_END):
                if DMBPSTATPY[s]['INTCOV'] == "CSL" and DMBPSTATPY[s]['LOCNUM'] == DMBP130P[i]['LOCNUM']:
                    DMBPSTATPY[s]['INTCOV'] = 'CSL'
                    DMBPSTATPY[s]['PREMO'] = BASE_PREMIUM_CAL
                    DMBPSTATPY[s]['BILIM'] = ISO_CODE
                    DMBPSTATPY[s]['CURR_STATUS'] = "Y"
                    DMBPSTATPY[s]['RTEMOD'] = experience_mod["RTEMOD_CODE"]
                    DMBPSTATPY[s]['RTEDEP'] = experience_mod["RTEDEP_CODE"]
                    break

        if PDLLMD != ' ' or OBILMD != ' ':
            if CSL_LIAB:
                HOLD_COVLIM = OBILMD
            else:
                HOLD_COVLIM = PDLLMD

            HOLD_INTCOV = 'PDL'
            PROCESS_PDL = True
            PROCESS_BIL = False
            PROCESS_OBI = False
            PROCESS_CSL = False
            BASE_PREMIUM_CAL, ISO_CODE = c100(DWXP110PY, DMBPRATPY, DMBP130P, DMBPSTATPY, STAT_END, HOLD_INTCOV, HOLD_COVLIM, HOLD_TERR, HOLD_SIZCLS, HOLD_VHTYPE, HOLD_FLEET, HOLD_VEHCLS, SPLIT_LIAB, CSL_LIAB, PROCESS_BIL, PDLLMD, OBILMD, PROCESS_OBI, PROCESS_PDL, PROCESS_CSL)
            for s in range(int(DMBP130P[i]['MCA_STAT_CTR']), STAT_END):
                if DMBPSTATPY[s]['INTCOV'] == "PDL" and DMBPSTATPY[s]['LOCNUM'] == DMBP130P[i]['LOCNUM']:
                    DMBPSTATPY[s]['INTCOV'] = HOLD_INTCOV
                    DMBPSTATPY[s]['PREMO'] = BASE_PREMIUM_CAL
                    if CSL_LIAB:
                        DMBPSTATPY[s]["PDLIM"] = "00"
                    else:
                        DMBPSTATPY[s]['PDLIM'] = ISO_CODE
                    DMBPSTATPY[s]['CURR_STATUS'] = "Y"
                    DMBPSTATPY[s]['RTEMOD'] = experience_mod["RTEMOD_CODE"]
                    DMBPSTATPY[s]['RTEDEP'] = experience_mod["RTEDEP_CODE"]
                    break
