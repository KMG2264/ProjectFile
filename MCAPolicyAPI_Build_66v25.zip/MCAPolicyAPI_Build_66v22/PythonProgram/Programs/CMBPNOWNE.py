# ************************************************************
# *    MCA RATING - CALCULATE EXTENDED NON-OWNED LIABILITY   *
# *    PROGRAM-ID - CMBPNOWNE.py                             *
# ************************************************************

from settings import config, cursor, connection, get_round, get_round_3, get_round_2
from decimal import Decimal


def run(DWXP110PY, DMBPRATPY, DMBP130P, DMBPSTATPY, STAT_END):

    incr_factor = {}
    base_prem = {}
    experience_mod = {}

    # This function is used to get the INCREASE factor value
    def get_increased_limit(HOLD_COVLIM, HOLD_INTCOV, HOLD_SIZCLS, HOLD_VHTYPE):
        query = f"SELECT INCRT1, INCCD1, INCCD2 FROM {config['library']}.DMBF22501 WHERE CO = '{DWXP110PY['CO']}' AND PROD = '{DWXP110PY['PROD']}' AND PRMSTE = '{DMBPRATPY['MCA_PRMSTE']}' AND PROGRM = '{DMBPRATPY['MCA_PROGRM']}' AND INTCOV = '{HOLD_INTCOV}' AND SIZCLS = '{HOLD_SIZCLS}' AND VHTYPE = '{HOLD_VHTYPE}' AND COVLIM = '{HOLD_COVLIM}' AND ((EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE = 0) OR (EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE >= {DWXP110PY['RATE_DATE']}))"

        cursor.execute(query)
        data = cursor.fetchone()
        if not data:
            DMBPRATPY['RATING_ERROR_DESC'] = "CMBPNOWNE - FAILED TO FETCH INCR_FACTOR OR ISO_CODE"
            DMBPRATPY['RATING_STATUS'] = "E"
            return
        else:
            DMBF22501 = dict(zip([col[0] for col in cursor.description], data))
            INCR_FACTOR = DMBF22501["INCRT1"]
            ISO_CODE = DMBF22501["INCCD1"]

            if CSL_LIABILITY:
                ISO_CODE = DMBF22501["INCCD2"]

            incr_factor['INCR_FACTOR'] = INCR_FACTOR
            incr_factor['ISO_CODE'] = ISO_CODE

    # This function is used to get the BASE PREMIUM value factor value
    def get_base_premium(HOLD_MISVR3, HOLD_MISID):
        query = f"SELECT MISRT1, MISRT2 FROM {config['library']}.DWAF22801 WHERE CO = '{DWXP110PY['CO']}' AND PROD = '{DWXP110PY['PROD']}' AND PRMSTE = '{DMBPRATPY['MCA_PRMSTE']}' AND PROGRM = '{DMBPRATPY['MCA_PROGRM']}' AND MISID = '{HOLD_MISID}' AND MISVR1 = 'ALL' AND MISVR2 = 'NON-OWN' AND MISVR3 = '{HOLD_MISVR3}' AND ((EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE = 0) OR (EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE >= {DWXP110PY['RATE_DATE']}))"

        cursor.execute(query)
        data = cursor.fetchone()
        if not data:
            DMBPRATPY['RATING_ERROR_DESC'] = "CMBPNOWNE - FAILED TO FETCH BASE_PREMIUM."
            DMBPRATPY['RATING_STATUS'] = "E"
            return
        else:
            DWAF22801 = dict(zip([col[0] for col in cursor.description], data))
            BASE_PREMIUM = DWAF22801['MISRT1']
            base_prem['BASE_PREMIUM'] = BASE_PREMIUM

        # EXPERIENE MOD SECTION
        if not experience_mod:
            if DWXP110PY['LOCZIP'] == "BASLIMPRM":
                COMBINED_FACTOR1 = 1
            else:
                COMBINED_FACTOR1 = DMBPRATPY['EXPMD1']

            COMBINED_FACTOR = get_round_2(COMBINED_FACTOR1)

            # Extract whole number and remainder
            WHOLE_NUMBER = int(str(COMBINED_FACTOR).split('.')[0])
            REMAINDER_NUMBER = int(str(COMBINED_FACTOR).split('.')[1])

            if WHOLE_NUMBER >= 1:
                RTEMOD_NUMERIC = str(WHOLE_NUMBER)[-1]
                RTEMOD_NUMERIC += str(REMAINDER_NUMBER).zfill(2)
            else:
                RTEMOD_NUMERIC = str(WHOLE_NUMBER)[-1]
                RTEMOD_NUMERIC += str(REMAINDER_NUMBER).zfill(2)

            COMBINED_FACTOR1 = DMBPRATPY['IRPM1']
            COMBINED_FACTOR = get_round_2(COMBINED_FACTOR1)

            WHOLE_NUMBER = int(str(COMBINED_FACTOR).split('.')[0])
            REMAINDER_NUMBER = int(str(COMBINED_FACTOR).split('.')[1])

            if WHOLE_NUMBER >= 1:
                RTEDEP_NUMERIC = str(WHOLE_NUMBER)[-1]
                RTEDEP_NUMERIC += str(REMAINDER_NUMBER).zfill(2)
            else:
                RTEDEP_NUMERIC = str(WHOLE_NUMBER)[-1]
                RTEDEP_NUMERIC += str(REMAINDER_NUMBER).zfill(2)

            # Insert to experience_mod values dictionary
            experience_mod["RTEMOD_CODE"] = RTEMOD_NUMERIC
            experience_mod["RTEDEP_CODE"] = RTEDEP_NUMERIC

    for i in range(len(DMBP130P)):

        if DMBP130P[i]['LOCNUM'] != "501":
            continue

        SPLIT_LIABILITY = CSL_LIABILITY = False
        WS_CNT = DMBP130P[i]['OBILMD'].count('/')
        if WS_CNT >= 1:
            SPLIT_LIABILITY = True
        else:
            CSL_LIABILITY = True

        if DMBP130P[i]['OBILMD'].strip() != "":
            HOLD_INTCOV = "OBI"
            if SPLIT_LIABILITY:
                HOLD_COVLIM = DMBP130P[i]['OBILMD']
            else:
                HOLD_COVLIM = f"{DMBP130P[i]['OBILMD'].strip()}/{DMBP130P[i]['OBILMD']}"

        # RETRIEVE-INCREASED-LIMITS
        get_increased_limit(HOLD_COVLIM, HOLD_INTCOV, HOLD_SIZCLS="", HOLD_VHTYPE="")

        HOLD_MISVR3 = DMBP130P[i]['CLASX'].strip()
        if HOLD_MISVR3 == "667100":
            if DMBP130P[i]['FUTDIS1'] < 26:
                HOLD_MISVR3 = "660100"
            elif DMBP130P[i]['FUTDIS1'] < 101:
                HOLD_MISVR3 = "660200"
            elif DMBP130P[i]['FUTDIS1'] < 501:
                HOLD_MISVR3 = "660300"
            elif DMBP130P[i]['FUTDIS1'] < 1001:
                HOLD_MISVR3 = "660400"
            elif DMBP130P[i]['FUTDIS1'] > 1000:
                HOLD_MISVR3 = "660500"

        # PERFORM C320-RETRIEVE-BASEPREMIUM
        if DMBP130P[i]['OBILMD'].strip() != "":
            HOLD_INTCOV = HOLD_MISID = "BIL"

        get_base_premium(HOLD_MISVR3, HOLD_MISID)
        BASE_PREMIUM = base_prem['BASE_PREMIUM']

        BASE_PREMIUM = get_round_3(BASE_PREMIUM * incr_factor['INCR_FACTOR'])

        if DMBPRATPY['ACCOUNT'] == "Y":
            BASE_PREMIUM = get_round(BASE_PREMIUM * Decimal(0.95))

        BASE_PREMIUM = get_round_3(BASE_PREMIUM * DMBPRATPY['RMF1'])

        if DMBP130P[i]['EMPADDL'] == "Y":
            BASE_PREMIUM = get_round(BASE_PREMIUM * Decimal(1.25))

        BASE_PREMIUM_CAL = get_round(BASE_PREMIUM)

        if HOLD_INTCOV == "BIL" and CSL_LIABILITY:
            HOLD_INTCOV = "CSL"

        if HOLD_INTCOV == "BIL" and SPLIT_LIABILITY:
            HOLD_INTCOV = "OBI"

        for s in range(int(DMBP130P[i]['MCA_STAT_CTR']), STAT_END):
            if DMBPSTATPY[s]['INTCOV'] == HOLD_INTCOV and DMBPSTATPY[s]['LOCNUM'] == DMBP130P[i]['LOCNUM']:
                DMBPSTATPY[s]['PREMO'] = BASE_PREMIUM_CAL
                if DMBPSTATPY[s]['INTCOV'] in ("BIL", "CSL", "OBI"):
                    DMBPSTATPY[s]['BILIM'] = incr_factor['ISO_CODE']
                DMBPSTATPY[s]['CURR_STATUS'] = "Y"
                DMBPSTATPY[s]['RTEMOD'] = experience_mod['RTEMOD_CODE']
                DMBPSTATPY[s]['RTEDEP'] = experience_mod['RTEDEP_CODE']
                break

        if DMBP130P[i]["OBILMD"].strip() != "" or DMBP130P[i]["PDLLMD"].strip() != "":
            if CSL_LIABILITY:
                HOLD_COVLIM = DMBP130P[i]["OBILMD"]
            else:
                HOLD_COVLIM = DMBP130P[i]["PDLLMD"]

            # RETRIEVE-INCREASED-LIMITS
            get_increased_limit(HOLD_COVLIM, HOLD_INTCOV="PDL", HOLD_SIZCLS="*", HOLD_VHTYPE="**")

            if CSL_LIABILITY:
                HOLD_MISID = "CSL"
                HOLD_MISVR1 = "ALL"
                NUM_LIMIT_H = 0  # NUM_LIMIT_H redefines to WORK_LIMIT_H

                # RETRIEVE SING_LMT_DSC
                query = f"SELECT MISRT1, MISVR2, MISVR3 FROM {config['library']}.DWAF22801 WHERE CO = '{DWXP110PY['CO']}' AND PROD = '{DWXP110PY['PROD']}' AND PRMSTE = '{DMBPRATPY['MCA_PRMSTE']}' AND PROGRM = '{DMBPRATPY['MCA_PROGRM']}' AND MISID = 'CSL' AND MISVR1 = 'ALL' AND ((EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE = 0) OR (EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE >= {DWXP110PY['RATE_DATE']}))"

                cursor.execute(query)
                data = cursor.fetchone()
                if not data:
                    DMBPRATPY['RATING_ERROR_DESC'] = "CMBPNOWE - FAILED TO FETCH NUM_LIMIT_L OR NUM_LIMIT_U OR SING_LMT_DSC"
                    DMBPRATPY['RATING_STATUS'] = "E"
                    return
                else:
                    DWAF22801 = dict(zip([col[0] for col in cursor.description], data))
                    if HOLD_MISID == "CSL" and HOLD_MISVR1 == "ALL":
                        NUM_LIMIT_G = HOLD_COVLIM
                        NUM_LIMIT_L = DWAF22801['MISVR2']
                        NUM_LIMIT_U = DWAF22801['MISVR3']

                    if int(NUM_LIMIT_H) == 0 and NUM_LIMIT_G < NUM_LIMIT_L:
                        SING_LMT_DSC = get_round_3(DWAF22801['MISRT1'])

                    if NUM_LIMIT_G >= NUM_LIMIT_L and NUM_LIMIT_G <= NUM_LIMIT_U:
                        SING_LMT_DSC = DWAF22801['MISRT1']

            HOLD_MISVR3 = DMBP130P[i]['CLASX'].strip()
            if HOLD_MISVR3 == "667100":
                if DMBP130P[i]['FUTDIS1'] < 26:
                    HOLD_MISVR3 = "660100"
                elif DMBP130P[i]['FUTDIS1'] < 101:
                    HOLD_MISVR3 = "660200"
                elif DMBP130P[i]['FUTDIS1'] < 501:
                    HOLD_MISVR3 = "660300"
                elif DMBP130P[i]['FUTDIS1'] < 1001:
                    HOLD_MISVR3 = "660400"
                elif DMBP130P[i]['FUTDIS1'] > 1000:
                    HOLD_MISVR3 = "660500"

            # RETRIEVE-BASEPREMIUM
            get_base_premium(HOLD_MISVR3, HOLD_MISID="PDL")

            # COMPUTE PREMIUM
            BASE_PREMIUM = base_prem['BASE_PREMIUM']
            BASE_PREMIUM = get_round_3(BASE_PREMIUM * incr_factor['INCR_FACTOR'])

            if CSL_LIABILITY:
                BASE_PREMIUM = get_round_3(BASE_PREMIUM * SING_LMT_DSC)

            if DMBPRATPY['ACCOUNT'] == "Y":
                BASE_PREMIUM = get_round(BASE_PREMIUM * Decimal(0.95))

            BASE_PREMIUM = get_round_3(BASE_PREMIUM * DMBPRATPY['RMF1'])

            if DMBP130P[i]['EMPADDL'] == "Y":
                BASE_PREMIUM = get_round(BASE_PREMIUM * Decimal(1.25))

            BASE_PREMIUM_CAL = get_round(BASE_PREMIUM)
            for s in range(int(DMBP130P[i]['MCA_STAT_CTR']), STAT_END):
                if DMBPSTATPY[s]['INTCOV'] == "PDL" and DMBPSTATPY[s]['LOCNUM'] == DMBP130P[i]['LOCNUM']:
                    if CSL_LIABILITY:
                        DMBPSTATPY[s]["PDLIM"] = "00"
                    else:
                        DMBPSTATPY[s]["PDLIM"] = incr_factor['ISO_CODE']
                    DMBPSTATPY[s]['PREMO'] = BASE_PREMIUM_CAL
                    DMBPSTATPY[s]['CURR_STATUS'] = "Y"
                    DMBPSTATPY[s]['RTEMOD'] = experience_mod['RTEMOD_CODE']
                    DMBPSTATPY[s]['RTEDEP'] = experience_mod['RTEDEP_CODE']
                    break
