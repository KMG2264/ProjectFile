# ************************************************************
# *    MPA RATING - APPLY ANTI-THEFT DISCOUNT                     *
# *    PROGRAM-ID. CMBPATH01.                           *
# ************************************************************

from settings import config, cursor, connection, get_round, get_round_3
from decimal import Decimal

def run(DWXP110PY, DMBPRATPY, DMBP130P, DMBPSTATPY, STAT_END):

    for i in range(len(DMBP130P)):
        if DMBP130P[i]['ANTTFT'].strip() == '' or DMBP130P[i]['CMPDED'].strip() == '' or (DMBP130P[i]['VEHCLS'][0] != '7' and DMBP130P[i]['VEHCLS'][0] != '0'):
            return

        HOLD_ANTTFT = DMBP130P[i]['ANTTFT']
        HOLD_ACCOUNT = DMBPRATPY['ACCOUNT']

        # Retrieve ANTTFT    
        query = f"SELECT DISPCT FROM {config['library']}.DWXF171 WHERE CDKEY1 = '{DWXP110PY['CDKEY1']}' AND CDKEY2 = '{DMBPRATPY['CDKEY2']}' AND CDKEY3 = '{HOLD_ANTTFT}' AND ((EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE = 0) OR (EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE >= {DWXP110PY['RATE_DATE']}))"

        cursor.execute(query)
        data = cursor.fetchone()

        if not data:
            DMBPRATPY['RATING_ERROR_DESC'] = "CMBPATH01 - FAILED TO FETCH ANTTFT_FACTOR."
            DMBPRATPY['RATING_STATUS'] = "E"
            return
        else:
            DWXF171 = dict(zip([col[0] for col in cursor.description], data))
            ANTTFT_FACTOR = DWXF171['DISPCT']


        # COMPUTE PREMIUM
        DMBP130P[i]['ATHPCT'] = ANTTFT_FACTOR
        ANTTFT_FACTOR = 100 - ANTTFT_FACTOR
        NO_DISCOUNT_PREMIUM = DMBPSTATPY['PREMO']

        BASE_PREMIUM = get_round(DMBPSTATPY['PREMO'] * ANTTFT_FACTOR / 100)

        if HOLD_ACCOUNT == 'Y':
            BASE_PREMIUM = get_round(BASE_PREMIUM * 0.95)

        BASE_PREMIUM_CAL = get_round(BASE_PREMIUM)

        NO_DISCOUNT_PREMIUM = NO_DISCOUNT_PREMIUM - BASE_PREMIUM
        DMBP130P[i]['ATHDIS'] = DMBP130P[i]['ATHDIS'] + NO_DISCOUNT_PREMIUM

        BASE_PREMIUM = BASE_PREMIUM - NO_DISCOUNT_PREMIUM

        for s in range(int(DMBP130P[i]['MCA_STAT_CTR']), STAT_END):
            if DMBPSTATPY[s]['INTCOV'] == "TOW" and DMBPSTATPY[s]['LOCNUM'] == DMBP130P[i]['LOCNUM']:
                DMBPSTATPY[s]['PREMO'] = BASE_PREMIUM_CAL
                DMBPSTATPY[s]['CURR_STATUS'] = 'Y'
                DMBPSTATPY[s]['RTEMOD'] = ''
                DMBPSTATPY[s]['RTEDEP'] = ''
                break
