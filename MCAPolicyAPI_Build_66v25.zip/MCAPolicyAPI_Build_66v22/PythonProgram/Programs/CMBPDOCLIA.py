# ************************************************************
# *    MCA RATING - CALCULATE DOC LIABILITY                  *
# *    PROGRAM-ID. CMBPDOCLIA.py                             *
# ************************************************************


from settings import config, cursor, connection, get_round, get_round_3, get_round_2
from decimal import Decimal


def run(DWXP110PY, DMBPRATPY, DMBP130P, DMBPSTATPY, STAT_END):
    base_prem = {}
    incr_factor = {}
    experience_mod = {}

    def get_base_premium_query(HOLD_MISID):
        query = f"SELECT MISRT1 FROM {config['library']}.DWAF22801 WHERE CO = '{DWXP110PY['CO']}' AND PROD = '{DWXP110PY['PROD']}' AND PRMSTE = '{DMBPRATPY['MCA_PRMSTE']}' AND PROGRM = '{DMBPRATPY['MCA_PROGRM']}' AND MISID = '{HOLD_MISID}' AND MISVR1 = 'ALL' AND MISVR2 = 'DOC' AND MISVR3 = '' AND ((EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE = 0) OR (EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE >= {DWXP110PY['RATE_DATE']}))"

        cursor.execute(query)
        data = cursor.fetchone()
        if not data:
            DMBPRATPY['RATING_ERROR_DESC'] = "CMBPDOCLIA - BIL HOLD_PREMIUM FAILED TO FETCH."
            DMBPRATPY['RATING_STATUS'] = "E"
            return
        else:
            DWAF22801 = dict(zip([col[0] for col in cursor.description], data))
            HOLD_PREMIUM = DWAF22801['MISRT1']
            base_prem['HOLD_PREMIUM'] = HOLD_PREMIUM

        # EXPERIENCE MOD SECTION
        if not experience_mod:
            if DWXP110PY['LOCZIP'] == "BASLIMPRM":
                COMBINED_FACTOR1 = 1
            else:
                COMBINED_FACTOR1 = DMBPRATPY['EXPMD2']
            COMBINED_FACTOR = get_round_2(COMBINED_FACTOR1)

            # Extract whole number and remainder
            WHOLE_NUMBER = int(str(COMBINED_FACTOR).split('.')[0])
            REMAINDER_NUMBER = int(str(COMBINED_FACTOR).split('.')[1])

            if WHOLE_NUMBER >= 1:
                RTEMOD_NUMERIC = str(WHOLE_NUMBER)[-1]
                RTEMOD_NUMERIC += str(REMAINDER_NUMBER).zfill(2)
            else:
                RTEMOD_NUMERIC = str(WHOLE_NUMBER)[-1]
                RTEMOD_NUMERIC += str(REMAINDER_NUMBER).zfill(2)

            COMBINED_FACTOR1 = DMBPRATPY['IRPM2']
            COMBINED_FACTOR = get_round_2(COMBINED_FACTOR1)

            WHOLE_NUMBER = int(str(COMBINED_FACTOR).split('.')[0])
            REMAINDER_NUMBER = int(str(COMBINED_FACTOR).split('.')[1])

            if WHOLE_NUMBER >= 1:
                RTEDEP_NUMERIC = str(WHOLE_NUMBER)[-1]
                RTEDEP_NUMERIC += str(REMAINDER_NUMBER).zfill(2)
            else:
                RTEDEP_NUMERIC = str(WHOLE_NUMBER)[-1]
                RTEDEP_NUMERIC += str(REMAINDER_NUMBER).zfill(2)

            # Insert into experience_mod values dictionary
            experience_mod["RTEMOD_CODE"] = RTEMOD_NUMERIC
            experience_mod["RTEDEP_CODE"] = RTEDEP_NUMERIC

    def get_increase_fac_query(HOLD_COVLIM, HOLD_INTCOV, HOLD_SIZCLS, HOLD_VHTYPE):
        query = f"SELECT INCRT1, INCCD1, INCCD2 FROM {config['library']}.DMBF22501 WHERE CO = '{DWXP110PY['CO']}' AND PROD = '{DWXP110PY['PROD']}' AND PRMSTE = '{DMBPRATPY['MCA_PRMSTE']}' AND PROGRM = '{DMBPRATPY['MCA_PROGRM']}' AND INTCOV = '{HOLD_INTCOV}' AND SIZCLS = '{HOLD_SIZCLS}' AND VHTYPE = '{HOLD_VHTYPE}' AND COVLIM = '{HOLD_COVLIM}' AND ((EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE = 0) OR (EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE >= {DWXP110PY['RATE_DATE']}))"

        cursor.execute(query)
        data = cursor.fetchone()

        if not data:
            DMBPRATPY['RATING_ERROR_DESC'] = "CMBPDOCLIA - BIL OR OBI FAILED TO FETCH INCR_FACTOR OR ISO_CODE"
            DMBPRATPY['RATING_STATUS'] = "E"
            return
        else:
            DMBF22501 = dict(zip([col[0] for col in cursor.description], data))
            INCR_FACTOR = DMBF22501["INCRT1"]
            ISO_CODE = DMBF22501["INCCD1"]

            if CSL_LIABILITY:
                ISO_CODE = DMBF22501["INCCD2"]

            incr_factor['INCR_FACTOR'] = INCR_FACTOR
            incr_factor['ISO_CODE'] = ISO_CODE

    for i in range(len(DMBP130P)):
        if DMBP130P[i]['BILLMD'].strip() == "" and DMBP130P[i]['PDLLMD'].strip() == "":
            return

        if DMBP130P[i]['CLASX'].strip() != "902000":
            continue

        DISCOUNT_APPLIES = True

        SPLIT_LIABILITY = CSL_LIABILITY = False
        WS_CNT = DMBP130P[i]['OBILMD'].count('/')
        if WS_CNT >= 1:
            SPLIT_LIABILITY = True
        else:
            CSL_LIABILITY = True

        # C200-RETRIEVE-BASE-PREMIUM
        get_base_premium_query(HOLD_MISID="BIL")
        BASE_PREMIUM = get_round_3(base_prem['HOLD_PREMIUM'] * DMBP130P[i]['NINDIV'])

        HOLD_INTCOV = "OBI"

        if SPLIT_LIABILITY:
            HOLD_COVLIM = DMBP130P[i]['OBILMD']
        else:
            HOLD_COVLIM = DMBP130P[i]['OBILMD'].strip() + '/' + DMBP130P[i]['OBILMD']

        #  C300-RETRIEVE-INCREASED-LIMITS.
        get_increase_fac_query(HOLD_COVLIM, HOLD_INTCOV, HOLD_SIZCLS="", HOLD_VHTYPE="")

        HOLD_INTCOV = "BIL"

        # COMPUTE BASE PREMIUM
        BASE_PREMIUM = get_round_3(BASE_PREMIUM * incr_factor['INCR_FACTOR'])

        if DMBPRATPY['ACCOUNT'] == "Y":
            BASE_PREMIUM = get_round_3(BASE_PREMIUM * Decimal(0.95))

        BASE_PREMIUM = get_round(BASE_PREMIUM * DMBPRATPY['RMF1'])
        BASE_PREMIUM_CAL = get_round(BASE_PREMIUM)

        if HOLD_INTCOV == "BIL" and CSL_LIABILITY:
            HOLD_INTCOV = "CSL"

        if HOLD_INTCOV == "BIL" and SPLIT_LIABILITY:
            HOLD_INTCOV = "OBI"

        for s in range(int(DMBP130P[i]['MCA_STAT_CTR']), STAT_END):
            if DMBPSTATPY[s]['INTCOV'] == HOLD_INTCOV and DMBPSTATPY[s]['LOCNUM'] == DMBP130P[i]['LOCNUM']:
                DMBPSTATPY[s]['PREMO'] = BASE_PREMIUM_CAL
                if DMBPSTATPY[s]['INTCOV'] in ("BIL", "CSL", "OBI"):
                    DMBPSTATPY[s]['BILIM'] = incr_factor['ISO_CODE']
                DMBPSTATPY[s]['CURR_STATUS'] = 'Y'
                DMBPSTATPY[s]['RTEMOD'] = experience_mod["RTEMOD_CODE"]
                DMBPSTATPY[s]['RTEDEP'] = experience_mod["RTEDEP_CODE"]
                break

        if DMBP130P[i]["OBILMD"].strip() != "" or DMBP130P[i]["PDLLMD"].strip() != "":
            if CSL_LIABILITY:
                HOLD_COVLIM = DMBP130P[i]["OBILMD"]
            else:
                HOLD_COVLIM = DMBP130P[i]["PDLLMD"]

            HOLD_INTCOV = "PDL"
            PROCESS_PDL = True

            if PROCESS_PDL:
                # RETRIEVE-BASE-PREMIUM
                get_base_premium_query(HOLD_MISID="PDL")

                BASE_PREMIUM = get_round_3(base_prem['HOLD_PREMIUM'] * DMBP130P[i]['NINDIV'])

                # RETRIEVE-INCREASED-LIMITS
                get_increase_fac_query(HOLD_COVLIM, HOLD_INTCOV, HOLD_SIZCLS="*", HOLD_VHTYPE="**")

                BASE_PREMIUM = get_round_3(BASE_PREMIUM * incr_factor['INCR_FACTOR'])

                SING_LMT_DSC = Decimal(1)
                if PROCESS_PDL and CSL_LIABILITY:
                    if DISCOUNT_APPLIES:
                        HOLD_MISID = "CSL"
                        HOLD_MISVR1 = "ALL"
                        NUM_LIMIT_H = 0  # NUM_LIMIT_H redefines to WORK_LIMIT_H

                        # RETRIEVE SING_LMT_DSC
                        query = f"SELECT MISRT1, MISVR2, MISVR3 FROM {config['library']}.DWAF22801 WHERE CO = '{DWXP110PY['CO']}' AND PROD = '{DWXP110PY['PROD']}' AND PRMSTE = '{DMBPRATPY['MCA_PRMSTE']}' AND PROGRM = '{DMBPRATPY['MCA_PROGRM']}' AND MISID = 'CSL' AND MISVR1 = 'ALL' AND ((EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE = 0) OR (EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE >= {DWXP110PY['RATE_DATE']}))"

                        cursor.execute(query)
                        data = cursor.fetchone()
                        if not data:
                            DMBPRATPY['RATING_ERROR_DESC'] = "CMBPDOCLIA - FAILED TO FETCH NUM_LIMIT_L OR NUM_LIMIT_U OR SING_LMT_DSC"
                            DMBPRATPY['RATING_STATUS'] = "E"
                            return
                        else:
                            DWAF22801 = dict(zip([col[0] for col in cursor.description], data))
                            if HOLD_MISID == "CSL" and HOLD_MISVR1 == "ALL":  # This line can be removed
                                NUM_LIMIT_G = HOLD_COVLIM
                                NUM_LIMIT_L = DWAF22801['MISVR2']
                                NUM_LIMIT_U = DWAF22801['MISVR3']

                            if int(NUM_LIMIT_H) == 0 and NUM_LIMIT_G < NUM_LIMIT_L:
                                SING_LMT_DSC = get_round_3(DWAF22801['MISRT1'])

                            if NUM_LIMIT_G >= NUM_LIMIT_L and NUM_LIMIT_G <= NUM_LIMIT_U:
                                SING_LMT_DSC = DWAF22801['MISRT1']

                        BASE_PREMIUM = get_round_3(BASE_PREMIUM * SING_LMT_DSC)

                if DMBPRATPY['ACCOUNT'] == "Y":
                    BASE_PREMIUM = get_round_3(BASE_PREMIUM * Decimal(0.95))

                BASE_PREMIUM = get_round(BASE_PREMIUM * DMBPRATPY['RMF1'])
                BASE_PREMIUM_CAL = get_round(BASE_PREMIUM)

                for s in range(int(DMBP130P[i]['MCA_STAT_CTR']), STAT_END):
                    if DMBPSTATPY[s]['INTCOV'] == "PDL" and DMBPSTATPY[s]['LOCNUM'] == DMBP130P[i]['LOCNUM']:
                        DMBPSTATPY[s]['PREMO'] = BASE_PREMIUM_CAL
                        if CSL_LIABILITY:
                            DMBPSTATPY[s]["PDLIM"] = "00"
                        else:
                            DMBPSTATPY[s]["PDLIM"] = incr_factor['ISO_CODE']
                        DMBPSTATPY[s]['CURR_STATUS'] = "Y"
                        DMBPSTATPY[s]['RTEMOD'] = experience_mod["RTEMOD_CODE"]
                        DMBPSTATPY[s]['RTEDEP'] = experience_mod["RTEDEP_CODE"]
                        break
