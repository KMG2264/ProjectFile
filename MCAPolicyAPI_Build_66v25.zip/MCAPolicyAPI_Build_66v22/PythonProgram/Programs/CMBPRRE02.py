# ************************************************************
# *    MPA RATING - CALCULATE RENTAL REIMBURSEMENT(SUBST TRN)*
# *    PROGRAM-ID. CMBPRRE02.py                              *
# ************************************************************

from settings import config, cursor, connection, get_round, get_round_3, get_round_2
from decimal import Decimal

def run(DWXP110PY, DMBPRATPY, DMBP130P, DMBPSTATPY, STAT_END):

    experience_mod = {}

    for i in range(len(DMBP130P)):
        if DMBP130P[i]['RRECOV'] != 'Y':
            continue

        BASE_PREMIUM = 7
        # HOLD_PAPDED =DMBP130P[i]['STMAXD']

        # RETRIEVE TERR_DEV
        query = f"SELECT MISRT1 FROM {config['library']}.DWAF22801 WHERE CO = '{DWXP110PY['CO']}' AND PROD = '{DWXP110PY['PROD']}' AND PRMSTE = '{DMBPRATPY['MCA_PRMSTE']}' AND PROGRM = '{DMBPRATPY['MCA_PROGRM']}' AND MISID = 'TERR DEV' AND MISVR1 = '{DMBP130P[i]['TERR']}' AND MISVR2 = 'RENTALREIM' AND MISVR3 = '{DMBP130P[i]['TYPE_OF_VEH']}' AND ((EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE = 0) OR (EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE >= {DWXP110PY['RATE_DATE']}))"

        cursor.execute(query)
        data = cursor.fetchone()
        if not data:
            DMBPRATPY['RATING_ERROR_DESC'] = "CMBPRRE02 - TEER DEV FAILED TO FETCH TERR_DEV"
            DMBPRATPY['RATING_STATUS'] = "E"
            return
        else:
            DWAF22801 = dict(zip([col[0] for col in cursor.description], data)) 
            TERR_DEV = DWAF22801['MISRT1']

        # EXPERIENE MOD SECTION
        if not experience_mod:
            if DWXP110PY['LOCZIP'] == "BASLIMPRM":
                COMBINED_FACTOR1 = 1
            else:
                COMBINED_FACTOR1 = DMBPRATPY['EXPMD2']
            COMBINED_FACTOR = get_round_2(COMBINED_FACTOR1)

            # Extract whole number and remainder
            WHOLE_NUMBER = int(str(COMBINED_FACTOR).split('.')[0])
            REMAINDER_NUMBER = int(str(COMBINED_FACTOR).split('.')[1])

            if WHOLE_NUMBER >= 1:
                RTEMOD_NUMERIC = str(WHOLE_NUMBER)[-1]
                RTEMOD_NUMERIC += str(REMAINDER_NUMBER).zfill(2)
            else:
                RTEMOD_NUMERIC = str(WHOLE_NUMBER)[-1]
                RTEMOD_NUMERIC += str(REMAINDER_NUMBER).zfill(2)

            COMBINED_FACTOR1 = DMBPRATPY['IRPM2']
            COMBINED_FACTOR = get_round_2(COMBINED_FACTOR1)

            WHOLE_NUMBER = int(str(COMBINED_FACTOR).split('.')[0])
            REMAINDER_NUMBER = int(str(COMBINED_FACTOR).split('.')[1])

            if WHOLE_NUMBER >= 1:
                RTEDEP_NUMERIC = str(WHOLE_NUMBER)[-1]
                RTEDEP_NUMERIC += str(REMAINDER_NUMBER).zfill(2)
            else:
                RTEDEP_NUMERIC = str(WHOLE_NUMBER)[-1]
                RTEDEP_NUMERIC += str(REMAINDER_NUMBER).zfill(2)

            # Insert to experience_mod values dictionary
            experience_mod["RTEMOD_CODE"] = RTEMOD_NUMERIC
            experience_mod["RTEDEP_CODE"] = RTEDEP_NUMERIC

        if DMBPRATPY['FLEET'] == "Y":
            AUTO_PLUS = 1.01
        else:
            AUTO_PLUS = 1.03

        BASE_PREMIUM = get_round_3(BASE_PREMIUM * int(DMBP130P[i]['STMAXT']) * TERR_DEV / 100)

        if DMBPRATPY['ACCOUNT'] == "Y":
            BASE_PREMIUM = get_round_3(BASE_PREMIUM * Decimal(0.95))

        if DMBP130P[i]["ENHCOV"] == "Y":
            BASE_PREMIUM = get_round_3(BASE_PREMIUM * Decimal(AUTO_PLUS))

        BASE_PREMIUM_CAL = get_round(BASE_PREMIUM * DMBPRATPY['RMF2'])
        for s in range(int(DMBP130P[i]['MCA_STAT_CTR']), STAT_END):
            if DMBPSTATPY[s]['INTCOV'] == "RRE" and DMBPSTATPY[s]['LOCNUM'] == DMBP130P[i]['LOCNUM']:
                DMBPSTATPY[s]['PREMO'] = BASE_PREMIUM_CAL
                DMBPSTATPY[s]['CURR_STATUS'] = 'Y'
                DMBPSTATPY[s]['RTEMOD'] = experience_mod['RTEMOD_CODE']
                DMBPSTATPY[s]['RTEDEP'] = experience_mod['RTEDEP_CODE']
                break