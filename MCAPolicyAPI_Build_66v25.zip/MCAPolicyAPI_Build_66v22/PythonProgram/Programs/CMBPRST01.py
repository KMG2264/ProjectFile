#****************************************************************
#*    MCA RATING - Read Stat                                    *
#*    PROGRAM-ID. CMBPRST01                                     *
#****************************************************************

from settings import config, cursor,connection, get_round, get_round_3,querylog


def run(DWXP110PY, DMBPRATPY, DMBP130P, DMBPSTATPY, STAT_END):

    if DWXP110PY['TRANS'] != "40":
        return

    query = f"SELECT LOCNUM, INTCOV, CLASX, PREMO, EXPOSE FROM {config['library1']}.DWXP150 WHERE TRANS = '{DWXP110PY['TRANS']}' AND POLICY = '{DWXP110PY['POLICY']}' AND EFFDTE = '{DWXP110PY['EFFDTE']}'"
    qstr="SELECT LOCNUM, INTCOV, CLASX, PREMO, EXPOSE FROM {config['library1']}.DWXP150 WHERE TRANS = '{DWXP110PY['TRANS']}' AND POLICY = '{DWXP110PY['POLICY']}' AND EFFDTE = '{DWXP110PY['EFFDTE']}'"
    querylog(f"QueryStr:\t\t{qstr}\n=======")
    querylog(f"\t\t{query}\n=======")
    cursor.execute(query)
    data = cursor.fetchall()
    if data:
        DWXP150 = [dict(zip([col[0] for col in cursor.description], row)) for row in data]
        for i in range(len(DWXP150)):
            for s in range(0, STAT_END):
                if DWXP150[i]['LOCNUM'] == DMBPSTATPY[s]['LOCNUM']:
                    if DMBPSTATPY[s]['INTCOV'] in ("BIL", "PIP", "UMB", "PDL", "OBI", "MED", "COL", "LCL", "CMP", "RRE", "TOW", "UNB", "SRT", "SRE", "ACM", "ACL", "MRB", "MRP", "MRC", "MRI", "PTD", "CTD", "AEC", "AEO", "CSL"):
                        DMBPSTATPY[s]['ORIG_CLASX'] = DWXP150[i]['CLASX']
                        DMBPSTATPY[s]['ORIG_STATUS'] = 'Y'

            if s == STAT_END:
                STAT_END = STAT_END + 1
                DMBPSTATPY[STAT_END]['ORIG_CLASX'] = DWXP150[i]['CLASX']
                DMBPSTATPY[STAT_END]['ORIG_STATUS'] = 'Y'