import sys
import time
from datetime import datetime, date
from pathlib import Path
import pandas as pd
import importlib
import json
from decimal import Decimal

from settings import config, cursor, connection

_loaded_modules = {}

# ============================================================
# QUERY LOGGER
# ============================================================

def querylog(query, flag=True):

    log_file = Path("Dev/Raters/Logs/queries.log")
    log_file.parent.mkdir(parents=True, exist_ok=True)

    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    with open(log_file, "a", encoding="utf-8") as f:
        f.write(f"[{timestamp}] {query}\n")


# ============================================================
# CLEAN JSON
# ============================================================

def clean(data):

    if isinstance(data, dict):
        return {k: clean(v) for k, v in data.items()}

    elif isinstance(data, list):
        return [clean(i) for i in data]

    elif isinstance(data, Decimal):
        return float(data)

    elif isinstance(data, (datetime, date)):
        return data.isoformat()

    return data


# ============================================================
# LOAD MODULE CACHE
# ============================================================

def load_module(module_name):

    if module_name not in _loaded_modules:
        _loaded_modules[module_name] = importlib.import_module(module_name)

    return _loaded_modules[module_name]


# ============================================================
# MAIN FUNCTION
# ============================================================

def run_rating(trans, policy, effdte):

    premiumdict = {}

    DMBPRATPY = {}
    DWXP110PY = {}
    DMBPSTATPY = []
    DMBP130P = []

    try:

        # ================= DWXP110PY =================

        query = f"""
        SELECT *
        FROM {config['library']}.DWXP110PY
        WHERE TRANS = '{trans}'
        AND POLICY = '{policy}'
        AND EFFDTE = {effdte}
        """

        querylog(query)
        cursor.execute(query)

        data = cursor.fetchall()

        DWXP110PY = dict(zip([c[0] for c in cursor.description], data[0]))


        # ================= DMBPRATPY =================

        query = f"""
        SELECT *
        FROM {config['library']}.DMBPRATPY
        WHERE TRANS = '{trans}'
        AND POLICY = '{policy}'
        AND EFFDTE = {effdte}
        """

        querylog(query)
        cursor.execute(query)

        data = cursor.fetchall()

        DMBPRATPY = dict(zip([c[0] for c in cursor.description], data[0]))

        DMBPRATPY["RATING_ERROR_DESC"] = ""
        DMBPRATPY["RATING_STATUS"] = ""


        # ================= DMBPSTATPY =================

        query = f"""
        SELECT *
        FROM {config['library']}.DMBPSTATPY
        WHERE TRANS = '{trans}'
        AND POLICY = '{policy}'
        AND EFFDTE = {effdte}
        """

        querylog(query)
        cursor.execute(query)

        data = cursor.fetchall()

        DMBPSTATPY = [
            dict(zip([c[0] for c in cursor.description], r))
            for r in data
        ]

        STAT_END = len(DMBPSTATPY)


        # ================= DMBP130P =================

        query = f"""
        SELECT *
        FROM {config['library']}.DMBP130P
        WHERE TRANS = '{trans}'
        AND POLICY = '{policy}'
        AND EFFDTE = {effdte}
        """

        querylog(query)
        cursor.execute(query)

        data = cursor.fetchall()

        DMBP130P = [
            dict(zip([c[0] for c in cursor.description], r))
            for r in data
        ]


        # ================= DWXF213 =================

        query = f"""
        SELECT CBLPGM
        FROM {config['library']}.DWXF213
        WHERE CO = '{DWXP110PY['CO']}'
        AND PROD = '{DWXP110PY['PROD']}'
        AND PRMSTE = '{DMBPRATPY['MCA_PRMSTE']}'
        AND PROGRM = '{DMBPRATPY['MCA_PROGRM']}'
        """

        querylog(query)
        cursor.execute(query)

        data = cursor.fetchall()

        DWXF213 = [
            dict(zip([c[0] for c in cursor.description], r))
            for r in data
        ]


        if not DWXF213:
            DMBPRATPY["RATING_ERROR_DESC"] = "NO RATE MODULES FOUND"
            DMBPRATPY["RATING_STATUS"] = "E"
            raise Exception("NO RATE MODULES FOUND")


        # ================= CALL MODULES =================

        for row in DWXF213:

            module_name = row["CBLPGM"].strip()

            PGM3 = module_name[-3:]   # FIXED

            if (
                DMBPRATPY["RATING_STATUS"] != "E"
                and PGM3 in DMBPRATPY.get("CALL_PGM", "")
            ):

                try:

                    module = load_module(module_name)

                    module.run(
                        DWXP110PY,
                        DMBPRATPY,
                        DMBP130P,
                        DMBPSTATPY,
                        STAT_END
                    )

                except Exception as e:

                    DMBPRATPY["RATING_STATUS"] = "E"
                    DMBPRATPY["RATING_ERROR_DESC"] = str(e)
                    raise


        # ================= PREMIUM =================

        df = pd.DataFrame(DMBP130P)

        totalpre = pd.to_numeric(df.get("APRP", 0), errors="coerce").sum()

        premiumdict = {
            "RatingData": {
                "TOTALPREMIUM": totalpre,
                "DMBPRATPY": DMBPRATPY,
                "DWXP110PY": DWXP110PY,
                "DMBPSTATPY": DMBPSTATPY,
                "DMBP130P": DMBP130P
            }
        }

        connection.commit()

        return json.dumps(clean([premiumdict]), default=str)

    except Exception as e:
        connection.rollback()
        raise Exception(str(e))