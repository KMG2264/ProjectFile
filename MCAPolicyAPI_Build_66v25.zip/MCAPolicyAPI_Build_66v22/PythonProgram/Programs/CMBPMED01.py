# ************************************************************
# *    MCA RATING - CALCULATE MEDICAL PAYMENTS               *
# *    PROGRAM-ID. CMBPMED01.py                             *
# ************************************************************

from settings import config, cursor, connection, get_round, get_round_3, get_round_2, truncate
from decimal import Decimal

def run(DWXP110PY, DMBPRATPY, DMBP130P, DMBPSTATPY, STAT_END):

    experience_mod = {}

    for i in range(len(DMBP130P)):

        if DMBP130P[i]['MEDLMD'].strip() == '':
            continue

        if DMBP130P[i]['CLASX'][1] != "8" and DMBP130P[i]['VEHTYP'] == 'U':
            continue

        if DMBP130P[i]['LOCNUM'].strip() >= "500":
            continue

        # RETRIEVE TERR
        query = f"SELECT MISRT1 FROM {config['library']}.DWAF22801 WHERE CO = '{DWXP110PY['CO']}' AND PROD = '{DWXP110PY['PROD']}' AND PRMSTE = '{DMBPRATPY['MCA_PRMSTE']}' AND PROGRM = '{DMBPRATPY['MCA_PROGRM']}' AND MISID = 'TERR DEV' AND MISVR1 = '{DMBP130P[i]['TERR']}' AND MISVR2 = 'MED' AND MISVR3 = '{DMBP130P[i]['TYPE_OF_VEH']}' AND ((EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE = 0) OR (EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE >= {DWXP110PY['RATE_DATE']}))"
        cursor.execute(query)
        data = cursor.fetchone()
        if not data:
            DMBPRATPY['RATING_ERROR_DESC'] = "CMBPMED01 - FAILED TO FETCH TERR_DEV"
            DMBPRATPY['RATING_STATUS'] = "E"
            return
        else:
            DWAF22801 = dict(zip([col[0] for col in cursor.description], data))
            TERR_DEV = truncate((DWAF22801['MISRT1']), 3)


        # Retrive MEDLMD Base Premium
        query = f"SELECT BASPRM FROM {config['library']}.DMBF21701 WHERE CO = '{DWXP110PY['CO']}' AND PROD = '{DWXP110PY['PROD']}' AND PRMSTE = '{DMBPRATPY['MCA_PRMSTE']}' AND PROGRM = '{DMBPRATPY['MCA_PROGRM']}' AND TERR = 'ALL' AND INTCOV = 'MED' AND COVLIM = '{DMBP130P[i]['MEDLMD']}' AND FLEET = '{DMBPRATPY['FLEET']}' AND SIZCLS = '{DMBP130P[i]['CLASX'][0]}' AND VHTYPE = '{DMBP130P[i]['TYPE_OF_VEH']}' AND ((EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE = 0) OR (EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE >= {DWXP110PY['RATE_DATE']}))"
        cursor.execute(query)
        data = cursor.fetchone()
        if not data:
            DMBPRATPY['RATING_ERROR_DESC'] = "CMBPMED01 - FAILED TO FETCH BASE PREM."
            DMBPRATPY['RATING_STATUS'] = "E"
            return
        else:
            DMBF21701 = dict(zip([col[0] for col in cursor.description], data))
            BASE_PREM = DMBF21701['BASPRM']

        #AUTO PLUS
        if DMBP130P[i]['ENHCOV'] == 'Y':
            if DMBPRATPY['FLEET'] == 'Y':
                AUTO_PLUS = Decimal(1.01)
            else:
                AUTO_PLUS = Decimal(1.03)
        else:
            AUTO_PLUS = Decimal(1.00)

        #Retrive Increased Limit ISO CODE
        query = f"SELECT INCCD1 FROM {config['library']}.DMBF22501 WHERE CO = '{DWXP110PY['CO']}' AND PROD = '{DWXP110PY['PROD']}' AND PRMSTE = '{DMBPRATPY['MCA_PRMSTE']}' AND PROGRM = '{DMBPRATPY['MCA_PROGRM']}' AND INTCOV = 'MED' AND COVLIM = '{DMBP130P[i]['MEDLMD']}' AND ((EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE = 0) OR (EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE >= {DWXP110PY['RATE_DATE']}))"
        cursor.execute(query)
        data = cursor.fetchone()
        if not data:
            DMBPRATPY['RATING_ERROR_DESC'] = "CMBPMED01 - FAILED TO FETCH ISO CODE"
            DMBPRATPY['RATING_STATUS'] = "E"
            return
        else:
            DMBF22501 = dict(zip([col[0] for col in cursor.description], data))
            ISO_CODE = DMBF22501['INCCD1']

        # EXPERIENCE MOD SECTION
        if not experience_mod:
            if DWXP110PY['LOCZIP'] == "BASLIMPRM":
                COMBINED_FACTOR1 = 1
            else:
                COMBINED_FACTOR1 = DMBPRATPY['EXPMD1']
            COMBINED_FACTOR = get_round_2(COMBINED_FACTOR1)

            # Extract whole number and remainder
            WHOLE_NUMBER = int(str(COMBINED_FACTOR).split('.')[0])
            REMAINDER_NUMBER = int(str(COMBINED_FACTOR).split('.')[1])

            if WHOLE_NUMBER >= 1:
                RTEMOD_NUMERIC = str(WHOLE_NUMBER)[-1]
                RTEMOD_NUMERIC += str(REMAINDER_NUMBER).zfill(2)
            else:
                RTEMOD_NUMERIC = str(WHOLE_NUMBER)[-1]
                RTEMOD_NUMERIC += str(REMAINDER_NUMBER).zfill(2)

            COMBINED_FACTOR1 = DMBPRATPY['IRPM1']
            COMBINED_FACTOR = get_round_2(COMBINED_FACTOR1)

            WHOLE_NUMBER = int(str(COMBINED_FACTOR).split('.')[0])
            REMAINDER_NUMBER = int(str(COMBINED_FACTOR).split('.')[1])

            if WHOLE_NUMBER >= 1:
                RTEDEP_NUMERIC = str(WHOLE_NUMBER)[-1]
                RTEDEP_NUMERIC += str(REMAINDER_NUMBER).zfill(2)
            else:
                RTEDEP_NUMERIC = str(WHOLE_NUMBER)[-1]
                RTEDEP_NUMERIC += str(REMAINDER_NUMBER).zfill(2)

            # Add experience_mod values to dictionary
            experience_mod["RTEMOD_CODE"] = RTEMOD_NUMERIC
            experience_mod["RTEDEP_CODE"] = RTEDEP_NUMERIC

        # COMPUTE PREMIUM
        if DMBP130P[i]['ENHCOV'] == 'Y':
            BASE_PREMIUM2 = get_round_2(BASE_PREM * TERR_DEV)

            if DMBPRATPY['ACCOUNT'] == 'Y':
                BASE_PREMIUM2 = get_round_2(BASE_PREMIUM2 * Decimal(0.95))

            BASE_PREMIUM1 = get_round_2(BASE_PREMIUM2 * AUTO_PLUS)
        else:
            BASE_PREMIUM1 = get_round_2(BASE_PREM * TERR_DEV)
            if DMBPRATPY['ACCOUNT'] == 'Y':
                BASE_PREMIUM1= get_round_2(BASE_PREMIUM1 * Decimal(0.95))

        BASE_PREMIUM_CAL = get_round(BASE_PREMIUM1)
        for s in range(int(DMBP130P[i]['MCA_STAT_CTR']), STAT_END):
            if DMBPSTATPY[s]['INTCOV'] == 'MED' and DMBPSTATPY[s]['LOCNUM'] == DMBP130P[i]['LOCNUM']:
                DMBPSTATPY[s]['PREMO'] = BASE_PREMIUM_CAL
                DMBPSTATPY[s]['DEDSIZ'] = ISO_CODE
                DMBPSTATPY[s]['CURR_STATUS'] = "Y"
                DMBPSTATPY[s]['RTEMOD'] = experience_mod["RTEMOD_CODE"]
                DMBPSTATPY[s]['RTEDEP'] = experience_mod["RTEDEP_CODE"]
                break


