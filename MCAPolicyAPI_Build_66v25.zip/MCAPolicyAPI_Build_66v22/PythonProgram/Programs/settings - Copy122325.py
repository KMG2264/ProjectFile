import pyodbc
import json
import logging
import time
import os
import decimal
import datetime
from decimal import Decimal, ROUND_HALF_UP, ROUND_DOWN

# Loading configuratons
with open(os.path.join(os.path.dirname(__file__), '..', 'Config', 'config.json')) as f:
    config = json.load(f)

# database connection
connection = pyodbc.connect('DSN=*LOCAL')
cursor = connection.cursor()

#  Rounding function
def get_round(n):
    return decimal.Decimal(n).quantize(decimal.Decimal('1'), 
    rounding=decimal.ROUND_HALF_UP)

#  Rounding function X Positions
def get_round_x(n):
    return decimal.Decimal(n).quantize(decimal.Decimal('.0001'),
    rounding=decimal.ROUND_HALF_UP)

def get_round_3(n):
    return decimal.Decimal(n).quantize(decimal.Decimal('.001'),
    rounding=decimal.ROUND_HALF_UP)

def get_round_2(n):
    return decimal.Decimal(n).quantize(decimal.Decimal('.01'),
    rounding=decimal.ROUND_HALF_UP)

#  Truncate function
def truncate(number, decimals=0):
    factor = 10 ** decimals
#return  decimal.Decimal(int(number * factor) / factor)
    number1 = decimal.Decimal(int(number * factor))
    number2 = decimal.Decimal(number1 / factor)
    return number2
	
def premium_round(n, decimals=4):
    n = Decimal(str(n))
    quant = Decimal('0.' + '0'*(decimals-1) + '1')

    # Extract digits
    shifted = n * (10 ** (decimals + 1))
    fifth_digit = int(abs(shifted)) % 10

    # If 5th digit > 5 → ROUND
    if fifth_digit > 5:
        return n.quantize(quant, rounding=ROUND_HALF_UP)

    # If 5th digit < 5 → TRUNCATE
    if fifth_digit <= 5:
        return n.quantize(quant, rounding=ROUND_DOWN)
