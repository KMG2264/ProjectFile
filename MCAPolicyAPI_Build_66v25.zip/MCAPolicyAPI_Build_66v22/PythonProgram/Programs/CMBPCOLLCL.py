# ************************************************************
# *    MCA RATING - CALCULATE COLLISION                      *
# *    PROGRAM-ID - CMBPCOLLCL.py                            *
# ************************************************************

from settings import config, cursor, connection, get_round, get_round_3, get_round_2
from decimal import Decimal


def run(DWXP110PY, DMBPRATPY, DMBP130P, DMBPSTATPY, STAT_END):

    base_prem = {}
    misc_rate = {}
    deduct_factor = {}
    experience_mod = {}

    # GETTING BASE PREMIUM QUERY
    def get_base_premium_query(HOLD_SECCLS, HOLD_VEHAGE, HOLD_COST, HOLD_INTCOV):
        query = f"SELECT BASPRM, CSTFRM, CSTTO FROM {config['library']}.DMBF81001 WHERE CO = '{DWXP110PY['CO']}' AND PROD = '{DWXP110PY['PROD']}' AND PRMSTE = '{DMBPRATPY['MCA_PRMSTE']}' AND PROGRM = '{DMBPRATPY['MCA_PROGRM']}' AND INTCOV = '{HOLD_INTCOV}' AND TERR = '{DMBP130P[i]['TERR']}' AND FLEET = '{DMBPRATPY['FLEET']}' AND VHTYPE = '{DMBP130P[i]['TYPE_OF_VEH']}' AND SECCLS = '{HOLD_SECCLS}' AND VEHAGE = '{HOLD_VEHAGE}' AND ((EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE = 0) OR (EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE >= {DWXP110PY['RATE_DATE']}))"
        cursor.execute(query)
        data = cursor.fetchall()

        if not data:
            DMBPRATPY['RATING_ERROR_DESC'] = "CMBPCOLLCL - FAILED TO FETCH BASE_PREMIUM."
            DMBPRATPY['RATING_STATUS'] = "E"
            return
        else:
            DMBF81001 = [dict(zip([col[0] for col in cursor.description], row)) for row in data]
            for b in range(len(DMBF81001)):
                if HOLD_COST >= DMBF81001[b]['CSTFRM'] and HOLD_COST <= DMBF81001[b]['CSTTO']:
                    base_prem['BASE_PREMIUM'] = DMBF81001[b]['BASPRM']
                    break
                # else:
                #     continue

    # GETTING MISC RATE QUERY
    def get_misc_rate_query(HOLD_PAPDED, HOLD_MISID):
        if HOLD_MISID == "COL WAIVER":
            HOLD_MISVR3 = f"{DMBP130P[i]['TYPE_OF_VEH']} {DMBPRATPY['FLEET']}"
        if HOLD_MISID == "TERR DEV":
            HOLD_MISVR3 = DMBP130P[i]['TYPE_OF_VEH']
        if HOLD_MISID == "LCL":
            HOLD_MISVR3 = ""

        query = f"SELECT MISRT1 FROM {config['library']}.DWAF22801 WHERE CO = '{DWXP110PY['CO']}' AND PROD = '{DWXP110PY['PROD']}' AND PRMSTE = '{DMBPRATPY['MCA_PRMSTE']}' AND PROGRM = '{DMBPRATPY['MCA_PROGRM']}' AND MISID = '{HOLD_MISID}' AND MISVR1 = '{DMBP130P[i]['TERR']}' AND MISVR2 = '{HOLD_PAPDED}' AND MISVR3 = '{HOLD_MISVR3}' AND ((EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE = 0) OR (EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE >= {DWXP110PY['RATE_DATE']}))"
        cursor.execute(query)
        data = cursor.fetchone()
        if not data:
            DMBPRATPY['RATING_ERROR_DESC'] = f"CMBPCOLLCL - {HOLD_MISID} NOT FOUND"
            DMBPRATPY['RATING_STATUS'] = "E"
            return
        else:
            DWAF22801 = dict(zip([col[0] for col in cursor.description], data))
            if HOLD_MISID == "COL WAIVER":
                misc_rate['COLDWV_CHARGE'] = DWAF22801['MISRT1']
            if HOLD_MISID == "TERR DEV":
                misc_rate['TERR_DEV'] = DWAF22801['MISRT1']
            if HOLD_MISID == "LCL":
                misc_rate['LCL_AMOUNT'] = DWAF22801['MISRT1']

    #GETTING DEDUCT FACTOR QUERY
    def get_deduct_factor_query(HOLD_PAPDED, HOLD_INTCOV):
        query = f"SELECT DEDFAC, DEDCOD, DEDFC2 FROM {config['library']}.DMBF22601 WHERE CO = '{DWXP110PY['CO']}' AND PROD = '{DWXP110PY['PROD']}' AND PRMSTE = '{DMBPRATPY['MCA_PRMSTE']}' AND PROGRM = '{DMBPRATPY['MCA_PROGRM']}' AND INTCOV = '{HOLD_INTCOV}' AND PAPDED = '{HOLD_PAPDED}' AND VHTYPE = '{DMBP130P[i]['TYPE_OF_VEH']}'  AND ((EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE = 0) OR (EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE >= {DWXP110PY['RATE_DATE']}))"

        cursor.execute(query)
        data = cursor.fetchone()
        if not data:
            DMBPRATPY['RATING_ERROR_DESC'] = "CMBPCOLLCL - DEDUCT_FACTOR OR ISO CODE OR LCL_MINAMT_TT NOT FOUND"
            DMBPRATPY['RATING_STATUS'] = "E"
            return
        else:
            DMBF22601 = dict(zip([col[0] for col in cursor.description], data))
            if HOLD_INTCOV == "COL":
                deduct_factor['DEDUCT_FACTOR'] = DMBF22601['DEDFAC']
                deduct_factor['ISO_CODE'] = DMBF22601['DEDCOD']

            if HOLD_INTCOV == "LCL":
                deduct_factor['LCL_DEDUCT_FACTOR'] = DMBF22601['DEDFAC']

                if DMBP130P[i]['TYPE_OF_VEH'] == "TT":
                    deduct_factor['LCL_MINAMT_TT'] = DMBF22601['DEDFC2']

    for i in range(len(DMBP130P)):
        if DMBP130P[i]['LOCNUM'].strip() > "500":
            continue
        
        if DMBP130P[i]['LCLDED'].strip() == "":
            continue

        HOLD_VEHAGE = DMBP130P[i]['AGE']
        HOLD_PAPDED = DMBP130P[i]['LCLDED']
        HOLD_COST = DMBP130P[i]['NEWCST']
        HOLD_SECCLS = DMBP130P[i]['CLASX'][3:6]
        COST_ABOVE_90K = False

        if HOLD_SECCLS != "790":
            HOLD_SECCLS = "   "

        if DMBP130P[i]['NEWCST'] > 90000:
            COST_ABOVE_90K = True
            get_base_premium_query(HOLD_SECCLS, HOLD_VEHAGE, HOLD_COST, HOLD_INTCOV='COL')
            BASE_PREMIUM = base_prem['BASE_PREMIUM']

            TEMP_PREMIUM = BASE_PREMIUM
            if DMBP130P[i]['TYPE_OF_VEH'] == "TT":
                HOLD_VEHAGE = " "
            HOLD_COST = 99999

        # RETRIEVE BASE PREMIUM
        get_base_premium_query(HOLD_SECCLS, HOLD_VEHAGE, HOLD_COST, HOLD_INTCOV='COL')
        BASE_PREMIUM = base_prem['BASE_PREMIUM']

        if COST_ABOVE_90K:
            BASE_DIFFERENCE = DMBP130P[i]['NEWCST'] - 90000
            BASE_PREMIUM = TEMP_PREMIUM + ((BASE_PREMIUM * BASE_DIFFERENCE) / 1000)
        
        if DMBP130P[i]['LCLDED'].strip() in ("", "300"):
            # RETRIEVE COL DEDUCT FACTOR
            get_deduct_factor_query(HOLD_PAPDED="300", HOLD_INTCOV="COL")
            DEDUCT_FACTOR = deduct_factor['DEDUCT_FACTOR']
            ISO_CODE = deduct_factor['ISO_CODE']

        # RETRIEVE LCL DEDUCT FACTOR
        get_deduct_factor_query(HOLD_PAPDED, HOLD_INTCOV="LCL")
        LCL_DEDUCT_FACTOR = deduct_factor['LCL_DEDUCT_FACTOR']

        if DMBP130P[i]['TYPE_OF_VEH'] == "TT":
            LCL_MINAMT_TT = deduct_factor['LCL_MINAMT_TT']


        if DMBP130P[i]['LCLDED'].strip() == "":
            HOLD_PAPDED = "300"
        else:
            HOLD_PAPDED = DMBP130P[i]['LCLDED']

        if DMBP130P[i]['COLDWV'] == "Y":
            # RETRIEVE COL WAIVER MISC RATE
            get_misc_rate_query(HOLD_PAPDED, HOLD_MISID="COL WAIVER")
            COLDWV_CHARGE = misc_rate['COLDWV_CHARGE']

        # RETRIEVE TERR_DEV MISC RATE
        get_misc_rate_query(HOLD_PAPDED='COL', HOLD_MISID='TERR DEV')
        TERR_DEV = misc_rate['TERR_DEV']

        # RETRIEVE LCL MISC RATE "LCL_AMOUNT"
        get_misc_rate_query(HOLD_PAPDED=f"{DMBP130P[i]['TYPE_OF_VEH']} {DMBPRATPY['FLEET']}", HOLD_MISID='LCL')
        LCL_AMOUNT = misc_rate['LCL_AMOUNT']

        if DMBP130P[i]['TYPE_OF_VEH'] == "TT":
            query = f"SELECT PCLFAC FROM {config['library']}.DMBF21501 WHERE CO = '{DWXP110PY['CO']}' AND PROD = '{DWXP110PY['PROD']}' AND PRMSTE = '{DMBPRATPY['MCA_PRMSTE']}' AND PROGRM = '{DMBPRATPY['MCA_PROGRM']}' AND SIZCLS = '{DMBP130P[i]['CLASX'][0]}' AND BUSCLS = '{DMBP130P[i]['CLASX'][1]}' AND RADCLS = '{DMBP130P[i]['CLASX'][2]}' AND ((EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE = 0) OR (EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE >= {DWXP110PY['RATE_DATE']}))"
            cursor.execute(query)
            data = cursor.fetchone()
            if not data:
                DMBPRATPY['RATING_ERROR_DESC'] = "CMBPCOLLCL - FAILED TO FETCH PRIMRY FAC"
                DMBPRATPY['RATING_STATUS'] = "E"
                return
            else:
                DMBF21501 = dict(zip([col[0] for col in cursor.description], data))
                PRIMRY_FAC = DMBF21501['PCLFAC']

        if DMBPRATPY['FLEET'] == "Y":
            AUTO_PLUS = Decimal(1.01)
        else:
            AUTO_PLUS = Decimal(1.03)

        SECONDARY_FAC = 0

        if DMBP130P[i]['CLASX'][0] < '7':
            HOLD_SECCLS = DMBP130P[i]['CLASX'][3:-1]

            if not HOLD_SECCLS < "21" and not HOLD_SECCLS > "29":
                HOLD_RADCLS = DMBP130P[i]['CLASX'][2]
            else:
                HOLD_RADCLS = ''

            if DMBP130P[i]['CLASX'][3] == '7':
                HOLD_DMPFLG = 'Y'
            else:
                HOLD_DMPFLG = 'N'

            query = f"SELECT LIAFTR FROM {config['library']}.DMBF21601 WHERE CO = '{DWXP110PY['CO']}' AND PROD = '{DWXP110PY['PROD']}' AND PRMSTE = '{DMBPRATPY['MCA_PRMSTE']}' AND PROGRM = '{DMBPRATPY['MCA_PROGRM']}' AND SECCLS = '{HOLD_SECCLS}' AND RADCLS = '{HOLD_RADCLS}' AND DMPFLG = '{HOLD_DMPFLG}' AND ((EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE = 0) OR (EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE >= {DWXP110PY['RATE_DATE']}))"
            cursor.execute(query)
            data = cursor.fetchone()
            if not data:
                DMBPRATPY['RATING_ERROR_DESC'] = "CMBPCOLLCL - FAILED TO FETCH SECONDARY FAC"
                DMBPRATPY['RATING_STATUS'] = "E"
                return
            else:
                DMBF21601 = dict(zip([col[0] for col in cursor.description], data))
                SECONDARY_FAC = DMBF21601['LIAFTR']


        # EXPERIENCE MOD SECTION
        if not experience_mod:  # By inserting RTEMOD values into a dictionary, the EXPERIENCE MOD no longer needs to run for each individual vehicle.
            if DWXP110PY['LOCZIP'] == "BASLIMPRM":
                COMBINED_FACTOR1 = 1
            else:
                COMBINED_FACTOR1 = DMBPRATPY['EXPMD2']
            COMBINED_FACTOR = get_round_2(COMBINED_FACTOR1)

            # Extract whole number and remainder
            WHOLE_NUMBER = int(str(COMBINED_FACTOR).split('.')[0])
            REMAINDER_NUMBER = int(str(COMBINED_FACTOR).split('.')[1])

            if WHOLE_NUMBER >= 1:
                RTEMOD_NUMERIC = str(WHOLE_NUMBER)[-1]
                RTEMOD_NUMERIC += str(REMAINDER_NUMBER).zfill(2)
            else:
                RTEMOD_NUMERIC = str(WHOLE_NUMBER)[-1]
                RTEMOD_NUMERIC += str(REMAINDER_NUMBER).zfill(2)

            COMBINED_FACTOR1 = DMBPRATPY['IRPM1']
            COMBINED_FACTOR = get_round_2(COMBINED_FACTOR1)

            WHOLE_NUMBER = int(str(COMBINED_FACTOR).split('.')[0])
            REMAINDER_NUMBER = int(str(COMBINED_FACTOR).split('.')[1])

            if WHOLE_NUMBER >= 1:
                RTEDEP_NUMERIC = str(WHOLE_NUMBER)[-1]
                RTEDEP_NUMERIC += str(REMAINDER_NUMBER).zfill(2)
            else:
                RTEDEP_NUMERIC = str(WHOLE_NUMBER)[-1]
                RTEDEP_NUMERIC += str(REMAINDER_NUMBER).zfill(2)

            # Insert into experience_mod values dictionary
            experience_mod["RTEMOD_CODE"] = RTEMOD_NUMERIC
            experience_mod["RTEDEP_CODE"] = RTEDEP_NUMERIC

        # COMPUTE PREMIUM
        if DMBP130P[i]['TYPE_OF_VEH'] == "TT":
            if DMBP130P[i]['LCLDED'].strip() == '':
                BASE_PREMIUM = get_round_3(BASE_PREMIUM * DEDUCT_FACTOR)
                BASE_PREMIUM = get_round_3(BASE_PREMIUM + LCL_AMOUNT)
            else:
                BASE_PREMIUM = get_round_3(BASE_PREMIUM * DEDUCT_FACTOR)

            BASE_PREMIUM = get_round_3(BASE_PREMIUM * (PRIMRY_FAC + SECONDARY_FAC))
            BASE_PREMIUM = get_round_3(BASE_PREMIUM * LCL_DEDUCT_FACTOR)

            if DMBP130P[i]['COLDWV'] == "Y":
                BASE_PREMIUM = get_round_3(BASE_PREMIUM + COLDWV_CHARGE)

            if DMBP130P[i]['ENHCOV'] == "Y":
                BASE_PREMIUM = get_round_3(BASE_PREMIUM * TERR_DEV)

                if DMBPRATPY['ACCOUNT'] == "Y":
                    BASE_PREMIUM = get_round_3(BASE_PREMIUM * Decimal(0.95))
                BASE_PREMIUM = get_round_3(BASE_PREMIUM * DMBPRATPY['RMF2'] * AUTO_PLUS)
            else:
                BASE_PREMIUM = get_round(BASE_PREMIUM * TERR_DEV)

                if DMBPRATPY['ACCOUNT'] == "Y":
                    BASE_PREMIUM = get_round_3(BASE_PREMIUM * Decimal(0.95))
                BASE_PREMIUM = get_round_3(BASE_PREMIUM * DMBPRATPY['RMF2'])
        else:
            if DMBP130P[i]['LCLDED'].strip() == '':
                BASE_PREMIUM = get_round_3(BASE_PREMIUM * DEDUCT_FACTOR)
                BASE_PREMIUM = get_round_3(BASE_PREMIUM + LCL_AMOUNT)
            else:
                BASE_PREMIUM = get_round_3(BASE_PREMIUM * LCL_DEDUCT_FACTOR)
            BASE_PREMIUM = get_round_3(BASE_PREMIUM * PRIMRY_FAC)

            if DMBP130P[i]['COLDWV'] == "Y":
                BASE_PREMIUM = get_round_3(BASE_PREMIUM + COLDWV_CHARGE)

            if DMBP130P[i]['ENHCOV'] == "Y":
                BASE_PREMIUM = get_round_3(BASE_PREMIUM * TERR_DEV)

                if DMBPRATPY['ACCOUNT'] == "Y":
                    BASE_PREMIUM = get_round_3(BASE_PREMIUM * Decimal(0.95))
                BASE_PREMIUM = get_round_3(BASE_PREMIUM * DMBPRATPY['RMF2'] * AUTO_PLUS)
            else:
                BASE_PREMIUM = get_round_3(BASE_PREMIUM * TERR_DEV)

                if DMBPRATPY['ACCOUNT'] == "Y":
                    BASE_PREMIUM = get_round_3(BASE_PREMIUM * Decimal(0.95))
                BASE_PREMIUM = get_round_3(BASE_PREMIUM * DMBPRATPY['RMF2'])

        if BASE_PREMIUM < LCL_MINAMT_TT:
            BASE_PREMIUM = LCL_MINAMT_TT
        
        BASE_PREMIUM_CAL = get_round(BASE_PREMIUM)
        for s in range(int(DMBP130P[i]['MCA_STAT_CTR']), STAT_END):
            if DMBPSTATPY[s]['INTCOV'] == 'LCL' and DMBPSTATPY[s]['LOCNUM'] == DMBP130P[i]['LOCNUM']:
                DMBPSTATPY[s]['PREMO'] = BASE_PREMIUM_CAL
                DMBPSTATPY[s]['COLCOV'] = ISO_CODE
                DMBPSTATPY[s]['CURR_STATUS'] = "Y"
                DMBPSTATPY[s]['RTEMOD'] = experience_mod["RTEMOD_CODE"]
                DMBPSTATPY[s]['RTEDEP'] = experience_mod["RTEDEP_CODE"]
                break

