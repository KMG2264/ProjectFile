# ************************************************************
# *    MCA RATING - CALCULATE DOC COLLISION                     *
# *    PROGRAM-ID. CMBPDOCCOL.py                             *
# ************************************************************


from settings import config, cursor, connection, get_round, get_round_2, get_round_3
from decimal import Decimal


def run(DWXP110PY, DMBPRATPY, DMBP130P, DMBPSTATPY, STAT_END):

    experience_mod = {}

    for i in range(len(DMBP130P)):
        if DMBP130P[i]["COLDED"].strip() == "": 
            continue
        
        if DMBP130P[i]["CLASX"] != "902000":
            continue

        # RETRIEVE-BASE-PREMIUM
        query = f"SELECT MISRT1 FROM {config['library']}.DWAF22801 WHERE CO = '{DWXP110PY['CO']}' AND PROD = '{DWXP110PY['PROD']}' AND PRMSTE = '{DMBPRATPY['MCA_PRMSTE']}' AND PROGRM = '{DMBPRATPY['MCA_PROGRM']}' AND MISID = 'COL' AND MISVR1 = 'ALL' AND MISVR2 = 'DOC' AND MISVR3 = '500' AND ((EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE = 0) OR (EFFDTE <= {DWXP110PY['RATE_DATE']} AND ENDDTE >= {DWXP110PY['RATE_DATE']}))"
        cursor.execute(query)
        data = cursor.fetchone()
        if not data:
            DMBPRATPY['RATING_ERROR_DESC'] = "CMBPDOCCOL - COL FAILED TO FETCH HOLD_PREMIUM."
            DMBPRATPY['RATING_STATUS'] = "E"
            return
        else:
            DWAF22801 = dict(zip([col[0] for col in cursor.description], data))
            HOLD_PREMIUM = DWAF22801['MISRT1']

        BASE_PREMIUM = HOLD_PREMIUM * DMBP130P[i]["NINDIV"]

        # EXPERIENCE MOD SECTION
        if not experience_mod:
            if DWXP110PY['LOCZIP'] == "BASLIMPRM":
                COMBINED_FACTOR1 = 1
            else:
                COMBINED_FACTOR1 = DMBPRATPY['EXPMD2']
            COMBINED_FACTOR = get_round_2(COMBINED_FACTOR1)

            # Extract whole number and remainder
            WHOLE_NUMBER = int(str(COMBINED_FACTOR).split('.')[0])
            REMAINDER_NUMBER = int(str(COMBINED_FACTOR).split('.')[1])

            if WHOLE_NUMBER >= 1:
                RTEMOD_NUMERIC = str(WHOLE_NUMBER)[-1]
                RTEMOD_NUMERIC += str(REMAINDER_NUMBER).zfill(2)
            else:
                RTEMOD_NUMERIC = str(WHOLE_NUMBER)[-1]
                RTEMOD_NUMERIC += str(REMAINDER_NUMBER).zfill(2)

            COMBINED_FACTOR1 = DMBPRATPY['IRPM2']
            COMBINED_FACTOR = get_round_2(COMBINED_FACTOR1)

            WHOLE_NUMBER = int(str(COMBINED_FACTOR).split('.')[0])
            REMAINDER_NUMBER = int(str(COMBINED_FACTOR).split('.')[1])

            if WHOLE_NUMBER >= 1:
                RTEDEP_NUMERIC = str(WHOLE_NUMBER)[-1]
                RTEDEP_NUMERIC += str(REMAINDER_NUMBER).zfill(2)
            else:
                RTEDEP_NUMERIC = str(WHOLE_NUMBER)[-1]
                RTEDEP_NUMERIC += str(REMAINDER_NUMBER).zfill(2)

            # Insert into experience_mod values dictionary
            experience_mod["RTEMOD_CODE"] = RTEMOD_NUMERIC
            experience_mod["RTEDEP_CODE"] = RTEDEP_NUMERIC

        # C400-COMPUTE-PREMIUM.
        if DMBPRATPY['ACCOUNT'] == "Y":
            BASE_PREMIUM = get_round_3(BASE_PREMIUM * Decimal(0.95))

        BASE_PREMIUM = get_round(BASE_PREMIUM * DMBPRATPY['RMF2'])
        BASE_PREMIUM_CAL = get_round(BASE_PREMIUM)
        for s in range(int(DMBP130P[i]['MCA_STAT_CTR']), STAT_END):
            if DMBPSTATPY[s]['INTCOV'] == "COL" and DMBPSTATPY[s]['LOCNUM'] == DMBP130P[i]['LOCNUM']:
                DMBPSTATPY[s]['PREMO'] = BASE_PREMIUM_CAL
                DMBPSTATPY[s]['COLCOV'] = ''
                DMBPSTATPY[s]['CURR_STATUS'] = 'Y'
                DMBPSTATPY[s]['RTEMOD'] = experience_mod["RTEMOD_CODE"]
                DMBPSTATPY[s]['RTEDEP'] = experience_mod["RTEDEP_CODE"]
                break