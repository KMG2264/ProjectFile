import pyodbc
import json
import logging
import datetime
import time
import os
import decimal
from decimal import Decimal, ROUND_HALF_UP, ROUND_DOWN
from pathlib import Path

base_dir = Path(__file__).resolve().parent.parent

# Loading configuratons
#with open('C:\Dev\Config\config.json')) as f:
#os.path.dirname(__file__), '..', 'Config', 'config.json'
file_path=f"{base_dir}\\Config\\Config\\config.json"
# print(file_path)
#with open(file_path) as json_file:
with open(file_path) as f:
    config = json.load(f)

# database connection
# connection = db2.pconnect()
connection = pyodbc.connect(f"DSN={config['database']['dsn']};UID={config['database']['user']};PWD={config['database']['password']}")
cursor = connection.cursor()




#  logging
_log_format = config['logging']['format']
file_name = config['logging']['file_path']+time.strftime("%Y%m%d_%H%M%S")+'.log'


#  Rounding function
#  Rounding function
def get_round(n):
    return decimal.Decimal(n).quantize(decimal.Decimal('1'),
    rounding=decimal.ROUND_HALF_UP)

#  Rounding function X Positions
def get_round_x(n):
    return decimal.Decimal(n).quantize(decimal.Decimal('.0001'),
    rounding=decimal.ROUND_HALF_UP)

def get_round_3(n):
    return decimal.Decimal(n).quantize(decimal.Decimal('.001'),
    rounding=decimal.ROUND_HALF_UP)

def get_round_2(n):
    return decimal.Decimal(n).quantize(decimal.Decimal('.01'),
    rounding=decimal.ROUND_HALF_UP)

#  Truncate function
def truncate(number, decimals=0):
    factor = 10 ** decimals
    #return  decimal.Decimal(int(number * factor) / factor)
    number1 = decimal.Decimal(int(number * factor))
    number2 = decimal.Decimal(number1 / factor)
    return number2

def premium_round(n, decimals=4):
    n = Decimal(str(n))
    quant = Decimal('0.' + '0'*(decimals-1) + '1')

    # Extract digits
    shifted = n * (10 ** (decimals + 1))
    fifth_digit = int(abs(shifted)) % 10

    # If 5th digit > 5 → ROUND
    if fifth_digit > 5:
        return n.quantize(quant, rounding=ROUND_HALF_UP)

    # If 5th digit < 5 → TRUNCATE
    if fifth_digit <= 5:
        return n.quantize(quant, rounding=ROUND_DOWN)


#  Sorting function
def custom_sort(data, fixed_indexes):
    """
    Sort a list of dictionaries while keeping specified indexes fixed.
    
    Args:
        data (list): List of dictionaries to sort.
        fixed_indexes (list): List of indexes to keep fixed.

    Returns:
        list: A new list with the sorted elements, keeping fixed indexes unchanged.
    """
    # Store the fixed items
    fixed_items = {i: data[i] for i in fixed_indexes}

    # Remove the fixed items from the original list
    items_to_sort = [item for i, item in enumerate(data) if i not in fixed_indexes]

    # Sort the remaining items by the value of key 'a'
    sorted_items = sorted(items_to_sort, key=lambda x: int(x["a"]))

    # Reinsert the fixed items at their original positions
    result = []
    for i in range(len(data)):
        if i in fixed_indexes:
            result.append(fixed_items[i])
        else:
            result.append(sorted_items.pop(0))

    return result

def factor_round(value):
    s = f"{value:.12f}"           # keep enough precision
    integer, decimal = s.split('.')

    # first 4 digits after decimal → main part
    d0 = decimal[:4]

    # 4th decimal digit → rounding digit and 5th digit
    d4 = int(decimal[3])
    d5 = int(decimal[4])

    # COBOL rule
    if d4 <= 5 and d5 >= 5:
        rounded = int(d0) + 1
    else:
        rounded = int(d0)

    return Decimal(f"{integer}.{rounded:04d}")

def querylog(query ,flag=True):


    log_file = Path("Dev/Raters/Logs/queries.log")
    log_file.parent.mkdir(parents=True, exist_ok=True)

    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    with open(log_file, "a", encoding="utf-8") as f:
        f.write(f"[{timestamp}] {query}\n")

    print("Logged.")
